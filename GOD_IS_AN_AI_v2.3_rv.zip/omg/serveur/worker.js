// OH MY GOD! — relais IA pour la version commerciale (Cloudflare Workers).
// Le jeu n'embarque AUCUNE clé : il parle à ce relais, qui ajoute la clé
// Anthropic (secret ANTHROPIC_KEY) et protège ton budget :
//   - modèle et longueur de réponse imposés côté serveur
//   - limite par joueur et par adresse IP (KV « LIMITS »)
//   - plafond global de requêtes par jour (DAILY_CAP)
//   - signature HMAC légère (CLIENT_SECRET, même valeur dans le jeu)
//
// Routes :
//   POST /v1/chat   {system, messages, player, lang}  -> réponse Anthropic (JSON)
//   POST /v1/tts    {input, voice, instructions}      -> audio/mpeg (si OPENAI_KEY)
//   POST /v1/stt    multipart (fichier audio)          -> transcription (si OPENAI_KEY)
//   GET  /health                                       -> "ok"

const MODEL = "claude-sonnet-4-6";
const MAX_TOKENS = 700;      // l'extraction Reality Echo renvoie jusqu'a 3 idees en JSON
const MAX_SYSTEM = 6000;       // caractères
const MAX_MESSAGES_CHARS = 9000;
// limites par joueur et par 10 minutes, PAR ROUTE (un joueur qui parle beaucoup
// au micro ne doit pas couper l'IA des appels) :
const PER_PLAYER_10MIN = { "/v1/chat": 120, "/v1/tts": 150, "/v1/stt": 240 };
const PER_IP_FACTOR = 4;       // 4 joueurs derrière la même box
const MARKER = "G.O.D.";       // le prompt système du jeu contient toujours ceci

export default {
  async fetch(request, env, ctx) {
    const url = new URL(request.url);
    if (request.method === "GET" && url.pathname === "/health") return text("ok", 200);
    if (request.method !== "POST") return text("method", 405);

    const bytes = new Uint8Array(await request.arrayBuffer());
    const isStt = url.pathname === "/v1/stt";
    if (bytes.length > (isStt ? 2500000 : 20000)) return text("too big", 413);
    if (env.CLIENT_SECRET) {
      const sig = request.headers.get("x-omg-sig") || "";
      const want = await hmac(env.CLIENT_SECRET, bytes);
      if (sig !== want) return text("bad signature", 401);
    }
    let body = {};
    if (!isStt) {
      try { body = JSON.parse(new TextDecoder().decode(bytes)); } catch { return text("bad json", 400); }
    }
    const player = String(isStt ? request.headers.get("x-omg-player") || "" : body.player || "").slice(0, 64);
    const ip = request.headers.get("cf-connecting-ip") || "local";
    if (!player) return text("player", 400);

    const lim = PER_PLAYER_10MIN[url.pathname] || 60;
    const limited = await rateLimit(env, [`p:${url.pathname}:${player}`, lim], [`ip:${url.pathname}:${ip}`, lim * PER_IP_FACTOR]);
    if (limited) return json({ error: "rate_limited" }, 429);

    if (url.pathname === "/v1/chat") return chat(body, env);
    if (url.pathname === "/v1/tts") return tts(body, env);
    if (isStt) return stt(bytes, request.headers.get("content-type") || "", env);
    return text("not found", 404);
  },
};

async function chat(body, env) {
  const system = String(body.system || "");
  if (system.length > MAX_SYSTEM || !system.includes(MARKER)) return text("bad system", 400);
  const messages = Array.isArray(body.messages) ? body.messages.slice(-4) : [];
  let size = 0;
  const clean = [];
  for (const m of messages) {
    const role = m && m.role === "assistant" ? "assistant" : "user";
    const content = String((m && m.content) || "");
    size += content.length;
    clean.push({ role, content });
  }
  if (!clean.length || size > MAX_MESSAGES_CHARS) return text("bad messages", 400);
  const r = await fetch(env.ANTHROPIC_URL || "https://api.anthropic.com/v1/messages", {
    method: "POST",
    headers: {
      "content-type": "application/json",
      "x-api-key": env.ANTHROPIC_KEY,
      "anthropic-version": "2023-06-01",
    },
    body: JSON.stringify({ model: env.MODEL || MODEL, max_tokens: MAX_TOKENS, system, messages: clean, stream: body.stream === true }),
  });
  // streaming (SSE) : on relaie les octets au fur et a mesure -> le fidele parle plus vite
  if (body.stream === true && r.ok) return new Response(r.body, { status: 200, headers: { "content-type": "text/event-stream", "cache-control": "no-cache" } });
  return new Response(await r.text(), { status: r.status, headers: { "content-type": "application/json" } });
}

async function tts(body, env) {
  if (!env.OPENAI_KEY) return text("tts off", 404);
  const r = await fetch(env.OPENAI_TTS_URL || "https://api.openai.com/v1/audio/speech", {
    method: "POST",
    headers: { "content-type": "application/json", authorization: "Bearer " + env.OPENAI_KEY },
    body: JSON.stringify({
      model: "gpt-4o-mini-tts",
      input: String(body.input || "").slice(0, 600),
      voice: String(body.voice || "alloy").slice(0, 20),
      instructions: String(body.instructions || "").slice(0, 400),
      response_format: body.response_format === "pcm" ? "pcm" : "mp3",
    }),
  });
  // pcm = audio brut 24 kHz qui joue des le premier morceau recu
  return new Response(r.body, { status: r.status, headers: { "content-type": body.response_format === "pcm" ? "audio/pcm" : "audio/mpeg" } });
}

// Reality Echo : la voix des joueurs devient du texte (la simulation ecoute)
async function stt(bytes, contentType, env) {
  if (!env.OPENAI_KEY) return text("stt off", 404);
  if (!contentType.startsWith("multipart/form-data")) return text("bad type", 400);
  const r = await fetch(env.OPENAI_STT_URL || "https://api.openai.com/v1/audio/transcriptions", {
    method: "POST",
    headers: { "content-type": contentType, authorization: "Bearer " + env.OPENAI_KEY },
    body: bytes,
  });
  return new Response(await r.text(), { status: r.status, headers: { "content-type": "application/json" } });
}

async function rateLimit(env, ...rules) {
  if (!env.LIMITS) return false;
  const win = Math.floor(Date.now() / 600000);
  const day = new Date().toISOString().slice(0, 10);
  if (env.DAILY_CAP) {
    const k = `day:${day}`;
    const n = parseInt((await env.LIMITS.get(k)) || "0") + 1;
    if (n > parseInt(env.DAILY_CAP)) return true;
    await env.LIMITS.put(k, String(n), { expirationTtl: 172800 });
  }
  for (const [key, max] of rules) {
    const k = `${key}:${win}`;
    const n = parseInt((await env.LIMITS.get(k)) || "0") + 1;
    if (n > max) return true;
    await env.LIMITS.put(k, String(n), { expirationTtl: 1200 });
  }
  return false;
}

async function hmac(secret, msg) {
  const key = await crypto.subtle.importKey("raw", new TextEncoder().encode(secret), { name: "HMAC", hash: "SHA-256" }, false, ["sign"]);
  const data = typeof msg === "string" ? new TextEncoder().encode(msg) : msg;
  const sig = await crypto.subtle.sign("HMAC", key, data);
  return [...new Uint8Array(sig)].map((b) => b.toString(16).padStart(2, "0")).join("");
}

const text = (t, s) => new Response(t, { status: s });
const json = (o, s) => new Response(JSON.stringify(o), { status: s, headers: { "content-type": "application/json" } });
