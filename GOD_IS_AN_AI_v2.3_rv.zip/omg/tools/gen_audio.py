#!/usr/bin/env python3
"""Generateur du pack audio de OH MY GOD! (100 % synthese, libre de droits).

    python3 tools/gen_audio.py          -> ecrit audio/*.ogg

Chaque son est fabrique a partir d'oscillateurs, de bruit, de filtres
et d'une reverb a convolution. Rien n'est echantillonne.
"""
import os
import subprocess
import tempfile

import numpy as np
from scipy import signal
from scipy.io import wavfile

SR = 44100
OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "audio")
rng = np.random.default_rng(1234)


# ------------------------------------------------------------------ outils
def t_axis(d):
    return np.arange(int(d * SR)) / SR


def sine(f, d, ph=0.0):
    t = t_axis(d)
    if callable(f):
        f = f(t)
    if np.ndim(f) == 0:
        return np.sin(2 * np.pi * f * t + ph)
    return np.sin(2 * np.pi * np.cumsum(f) / SR + ph)


def saw(f, d):
    t = t_axis(d)
    fa = np.full_like(t, f) if np.ndim(f) == 0 else f
    ph = np.cumsum(fa) / SR
    return 2.0 * (ph - np.floor(ph + 0.5))


def square(f, d, duty=0.5):
    t = t_axis(d)
    fa = np.full_like(t, f) if np.ndim(f) == 0 else f
    ph = np.cumsum(fa) / SR
    return np.where((ph % 1.0) < duty, 1.0, -1.0)


def noise(d):
    return rng.uniform(-1, 1, int(d * SR))


def brown(d):
    w = rng.normal(0, 1, int(d * SR))
    b = hp(np.cumsum(w), 20.0)
    return b / (np.max(np.abs(b)) + 1e-9)


def env(n, a=0.005, dcy=0.1, s=0.0, r=0.1, hold=0.0):
    a_n, d_n, h_n, r_n = int(a * SR), int(dcy * SR), int(hold * SR), int(r * SR)
    e = np.concatenate([
        np.linspace(0, 1, max(a_n, 1)),
        np.linspace(1, s, max(d_n, 1)),
        np.full(h_n, s),
        np.linspace(s, 0, max(r_n, 1)),
    ])
    if len(e) < n:
        e = np.concatenate([e, np.zeros(n - len(e))])
    return e[:n]


def expdec(n, tau):
    return np.exp(-np.arange(n) / (tau * SR))


def lp(x, fc, order=2):
    b, a = signal.butter(order, min(fc / (SR / 2), 0.99), "low")
    return signal.lfilter(b, a, x)


def hp(x, fc, order=2):
    b, a = signal.butter(order, min(fc / (SR / 2), 0.99), "high")
    return signal.lfilter(b, a, x)


def bp(x, lo, hi, order=2):
    b, a = signal.butter(order, [lo / (SR / 2), min(hi / (SR / 2), 0.99)], "band")
    return signal.lfilter(b, a, x)


def reverb(x, decay=1.8, mix=0.35, pre=0.02, bright=6000):
    n = int(decay * SR)
    ir = rng.normal(0, 1, n) * np.exp(-np.arange(n) / (decay * SR / 6.9))
    ir = lp(ir, bright)
    ir = np.concatenate([np.zeros(int(pre * SR)), ir])
    ir /= np.sqrt(np.sum(ir ** 2)) + 1e-9
    wet = signal.fftconvolve(x, ir)[: len(x) + n]
    dry = np.concatenate([x, np.zeros(len(wet) - len(x))])
    return dry * (1 - mix) + wet * mix * 0.6


def norm(x, peak=0.89):
    m = np.max(np.abs(x)) + 1e-9
    return x / m * peak


def pad(x, d):
    n = int(d * SR)
    if len(x) >= n:
        return x[:n]
    return np.concatenate([x, np.zeros(n - len(x))])


def place(buf, x, at):
    i = int(at * SR)
    j = min(len(buf), i + len(x))
    if i < len(buf):
        buf[i:j] += x[: j - i]


def loopify(x, xf=1.5):
    """fond enchaine : la fin se fond dans le debut (boucle sans clic)"""
    n = int(xf * SR)
    head, body, tail = x[:n], x[n:-n], x[-n:]
    fade = np.linspace(0, 1, n)
    mixed = tail * (1 - fade) + head * fade
    return np.concatenate([body, mixed])


def note_hz(n):
    """n = demi-tons depuis A4"""
    return 440.0 * 2 ** (n / 12.0)


def save(name, x, q=4, peak=0.89):
    os.makedirs(OUT, exist_ok=True)
    x = norm(np.nan_to_num(x), peak)
    with tempfile.NamedTemporaryFile(suffix=".wav", delete=False) as f:
        wavfile.write(f.name, SR, (x * 32767).astype(np.int16))
        tmp = f.name
    dst = os.path.join(OUT, name + ".ogg")
    subprocess.run(["ffmpeg", "-y", "-loglevel", "error", "-i", tmp, "-c:a", "libvorbis", "-q:a", str(q), dst], check=True)
    os.unlink(tmp)
    print("ok", name, round(len(x) / SR, 2), "s")


# ------------------------------------------------------------------ sons
def murmur(d):
    """voix etouffees au loin (bruit filtre module en syllabes)"""
    out = np.zeros(int(d * SR))
    for _ in range(int(d * 0.8)):
        dur = rng.uniform(0.8, 2.5)
        n = noise(dur)
        f0 = rng.uniform(380, 900)
        v = bp(n, f0 * 0.7, f0 * 1.6)
        syl = 0.5 + 0.5 * np.sin(2 * np.pi * rng.uniform(3.5, 6.0) * t_axis(dur)) ** 2
        v *= syl * env(len(v), 0.2, 0.1, 1.0, 0.4, dur - 0.7)
        place(out, v * rng.uniform(0.2, 0.5), rng.uniform(0, d - dur))
    return lp(out, 1500)


def amb_office():
    d = 48.0
    t = t_axis(d)
    room = lp(brown(d), 260) * 0.35
    hum = (np.sin(2 * np.pi * 60 * t) * 0.05 + np.sin(2 * np.pi * 120 * t) * 0.03 + np.sin(2 * np.pi * 180 * t) * 0.01)
    choir = np.zeros_like(t)
    for semi in [-19, -16, -12, -7, -4]:          # accord de re mineur grave
        f = note_hz(semi)
        for det in (-0.2, 0.0, 0.25):
            vib = f * (1 + 0.004 * np.sin(2 * np.pi * 5.1 * t + rng.uniform(0, 6)))
            choir += saw(vib * (1 + det / 100), d)
    choir = bp(choir, 300, 1400) * (0.5 + 0.5 * np.sin(2 * np.pi * t / 24.0 - 1.5) ** 2)
    choir = reverb(choir / 15.0, 3.5, 0.6)[: len(t)]
    voices = murmur(d) * 0.5
    x = room + hum + choir * 0.55 + voices
    save("amb_office", loopify(x, 3.0), peak=0.55)


def amb_menu():
    d = 40.0
    t = t_axis(d)
    drone = np.zeros_like(t)
    for semi, a in [(-33, 1.0), (-26, 0.6), (-21, 0.5), (-14, 0.25)]:
        f = note_hz(semi)
        drone += a * (saw(f * (1 + 0.003 * np.sin(2 * np.pi * 0.11 * t)), d) + saw(f * 1.004, d))
    drone = lp(drone, 500) * (0.6 + 0.4 * np.sin(2 * np.pi * t / 20.0) ** 2)
    bells = np.zeros_like(t)
    for k in range(9):
        b = church_bell(note_hz(rng.choice([-2, 1, 3, 5, 8, 10])), 4.0) * 0.25
        place(bells, b, k * 4.4 + rng.uniform(0, 1.0))
    x = reverb(drone * 0.15 + bells, 4.0, 0.55)[: len(t)]
    x += lp(brown(d), 200) * 0.08
    save("music_menu", loopify(x, 3.0), peak=0.6)


def church_bell(f0, d):
    t = t_axis(d)
    x = np.zeros_like(t)
    for ratio, amp, tau in [(0.5, 0.6, 2.5), (1.0, 1.0, 1.8), (1.19, 0.5, 1.2), (1.56, 0.4, 0.9), (2.0, 0.5, 0.8),
                            (2.51, 0.25, 0.5), (3.01, 0.2, 0.4), (4.1, 0.1, 0.25)]:
        x += amp * np.sin(2 * np.pi * f0 * ratio * t) * np.exp(-t / tau)
    x *= env(len(t), 0.002, 0.01, 1.0, 0.05, d - 0.07)
    return x


def phone_ring():
    # vieux telephone a cloche : 2 s de sonnerie, 4 s de silence
    d = 6.0
    out = np.zeros(int(d * SR))
    r = 2.0
    t = t_axis(r)
    strike = (np.sign(np.sin(2 * np.pi * 20 * t)) + 1) / 2
    tone = np.zeros_like(t)
    for f, a in [(1180, 1.0), (1440, 0.8), (2960, 0.3), (3600, 0.2), (5200, 0.1)]:
        tone += a * np.sin(2 * np.pi * f * t)
    rattle = bp(noise(r), 2500, 7000) * 0.3
    x = (tone + rattle) * (0.35 + 0.65 * lp(strike, 120)) * env(len(t), 0.01, 0.05, 1.0, 0.25, r - 0.3)
    place(out, reverb(x, 0.6, 0.2)[: len(t) + 4000], 0.0)
    save("phone_ring", out, peak=0.7)


def click(strength=1.0):
    d = 0.06
    n = noise(d) * expdec(int(d * SR), 0.004)
    body = np.sin(2 * np.pi * rng.uniform(1800, 3200) * t_axis(d)) * expdec(int(d * SR), 0.006)
    thump = np.sin(2 * np.pi * 180 * t_axis(d)) * expdec(int(d * SR), 0.01) * 0.6
    return (hp(n, 1500) * 0.7 + body * 0.25 + thump) * strength


def typing_loop():
    d = 8.0
    out = np.zeros(int(d * SR))
    tt = 0.1
    while tt < d - 0.2:
        place(out, click(rng.uniform(0.5, 1.0)), tt)
        tt += rng.uniform(0.06, 0.2)
        if rng.random() < 0.08:
            place(out, click(1.4) * 1.2, tt)
            tt += rng.uniform(0.3, 0.9)
    save("typing", reverb(out, 0.3, 0.15)[: len(out)], peak=0.6)


def footsteps():
    for k in range(4):
        d = 0.35
        t = t_axis(d)
        thump = np.sin(2 * np.pi * rng.uniform(70, 95) * t) * expdec(len(t), 0.03)
        tick = hp(noise(d), 2500) * expdec(len(t), 0.008) * 0.5
        scuff = bp(noise(d), 800, 3000) * env(len(t), 0.02, 0.06, 0.0, 0.01) * 0.15
        x = reverb(thump + tick + scuff, 0.9, 0.25)
        save("step%d" % k, x, peak=0.6)


def sale():
    d = 1.6
    t = t_axis(d)
    x = np.zeros_like(t)
    for f, a, tau in [(2093, 1.0, 0.5), (2637, 0.7, 0.45), (3136, 0.6, 0.4), (4186, 0.3, 0.3)]:
        x += a * np.sin(2 * np.pi * f * t) * np.exp(-np.maximum(t - 0.12, 0) / tau) * (t > 0.12)
    drawer = bp(noise(d), 400, 2500) * env(len(t), 0.005, 0.1, 0.0, 0.02) * 0.8
    coins = np.zeros_like(t)
    for _ in range(12):
        c = np.sin(2 * np.pi * rng.uniform(4000, 7000) * t_axis(0.08)) * expdec(int(0.08 * SR), 0.015)
        place(coins, c * 0.3, rng.uniform(0.2, 0.7))
    save("sale", reverb(drawer + x + coins, 1.0, 0.25))


def god_speak():
    d = 2.6
    t = t_axis(d)
    rumble = lp(brown(d), 90) * 1.5 + np.sin(2 * np.pi * 41 * t) * 0.6
    ch = np.zeros_like(t)
    for semi in [-21, -14, -9, -2, 3]:
        f = note_hz(semi)
        ch += saw(f * (1 + 0.006 * np.sin(2 * np.pi * 5.5 * t)), d)
    ch = bp(ch, 500, 1300) * 0.2
    x = (rumble + ch) * env(len(t), 0.3, 0.4, 0.7, 1.0, 0.8)
    save("god_speak", reverb(x, 3.0, 0.5))


def buzz_error():
    d = 0.6
    t = t_axis(d)
    x = square(110, d) * 0.5 + square(116.5, d) * 0.5
    x = lp(x, 1800) * (0.6 + 0.4 * np.sign(np.sin(2 * np.pi * 9 * t))) * env(len(t), 0.005, 0.05, 0.9, 0.08, 0.4)
    save("error", x, peak=0.6)


def power():
    d = 1.8
    t = t_axis(d)
    sweep = np.zeros_like(t)
    n = noise(d)
    for i in range(0, len(t), 2048):
        seg = n[i:i + 2048]
        fc = 300 + 3500 * (i / len(t)) ** 1.5
        sweep[i:i + len(seg)] = bp(seg, fc * 0.7, fc * 1.3)
    sweep *= env(len(t), 0.6, 0.3, 0.6, 0.8, 0.1)
    arp = np.zeros_like(t)
    for k, semi in enumerate([0, 4, 7, 12, 16, 19, 24]):
        nt = np.sin(2 * np.pi * note_hz(semi + 3) * t_axis(0.5)) * expdec(int(0.5 * SR), 0.12)
        place(arp, nt * 0.4, 0.35 + k * 0.07)
    save("power", reverb(sweep * 0.8 + arp, 1.5, 0.4))


def thunder():
    d = 4.0
    t = t_axis(d)
    crack = hp(noise(d), 1500) * expdec(len(t), 0.06) * 1.2
    rumble = lp(brown(d), 120) * env(len(t), 0.05, 0.4, 0.6, 2.5, 0.8) * 2.0
    save("thunder", reverb(crack + rumble, 2.5, 0.4))


def frogs():
    d = 2.2
    out = np.zeros(int(d * SR))
    for k in range(5):
        dur = 0.32
        t = t_axis(dur)
        pulses = (np.sin(2 * np.pi * rng.uniform(28, 40) * t) > 0.6).astype(float)
        v = bp(saw(rng.uniform(140, 220), dur) * pulses, 400, 1600)
        v *= env(len(t), 0.01, 0.05, 1.0, 0.08, 0.15)
        place(out, v, k * 0.4 + rng.uniform(0, 0.1))
    save("frogs", reverb(out, 0.8, 0.25))


def meow():
    d = 0.9
    t = t_axis(d)
    f = np.interp(t, [0, 0.25, 0.6, 0.9], [480, 720, 640, 420])
    v = saw(f, d)
    out = np.zeros_like(v)
    step = 1024
    for i in range(0, len(v), step):
        tc = i / SR
        fc = np.interp(tc, [0, 0.3, 0.9], [900, 1700, 800])
        out[i:i + step] = bp(v[i:i + step], fc * 0.7, fc * 1.4)
    out *= env(len(t), 0.05, 0.1, 0.8, 0.25, 0.45)
    save("meow", reverb(out, 0.5, 0.2))


def coffee():
    d = 3.5
    t = t_axis(d)
    grind = bp(noise(d), 1500, 5000) * (0.6 + 0.4 * np.sin(2 * np.pi * 38 * t)) * env(len(t), 0.05, 0.1, 1.0, 0.1, 1.1)
    hiss = hp(noise(d), 3000) * np.clip((t - 1.4) * 2, 0, 1) * np.clip((3.4 - t) * 3, 0, 1) * 0.5
    drips = np.zeros_like(t)
    for k in range(6):
        dr = np.sin(2 * np.pi * np.linspace(1400, 700, int(0.05 * SR)) * t_axis(0.05)) * expdec(int(0.05 * SR), 0.01)
        place(drips, dr * 0.4, 2.0 + k * 0.22)
    save("coffee", reverb(grind + hiss + drips, 0.6, 0.2), peak=0.7)


def ui():
    d = 0.06
    t = t_axis(d)
    save("ui_click", np.sin(2 * np.pi * 1900 * t) * expdec(len(t), 0.012), peak=0.5)
    save("ui_hover", np.sin(2 * np.pi * 2600 * t) * expdec(len(t), 0.006), peak=0.25)


def bells():
    save("bell_shift", reverb(church_bell(196.0, 5.0) + church_bell(246.9, 5.0) * 0.6, 3.0, 0.4))


def power_down():
    d = 1.6
    t = t_axis(d)
    f = 220 * np.exp(-t * 2.2) + 30
    x = lp(saw(f, d), 900) * env(len(t), 0.005, 0.1, 0.8, 0.6, 0.8)
    clunk = np.sin(2 * np.pi * 60 * t) * expdec(len(t), 0.08)
    save("power_down", x + clunk)
    f2 = 30 + 200 * (1 - np.exp(-t * 2.2))
    x2 = lp(saw(f2, d), 900) * env(len(t), 0.3, 0.2, 0.7, 0.4, 0.6)
    save("power_up", x2)


def beeps():
    t = t_axis(0.12)
    b = np.sin(2 * np.pi * 880 * t) * env(len(t), 0.005, 0.02, 0.8, 0.02, 0.07)
    out = np.zeros(int(0.5 * SR))
    place(out, b, 0.0)
    place(out, b * 0.9, 0.2)
    save("call_connect", out, peak=0.5)
    t2 = t_axis(0.25)
    tut = np.sin(2 * np.pi * 425 * t2) * env(len(t2), 0.005, 0.02, 0.8, 0.02, 0.2)
    out2 = np.zeros(int(1.6 * SR))
    for k in range(3):
        place(out2, tut, k * 0.5)
    save("call_end", out2, peak=0.45)


def paper():
    d = 0.4
    t = t_axis(d)
    sw = bp(noise(d), 600, 4000) * env(len(t), 0.05, 0.1, 0.4, 0.2, 0.05)
    save("swish", sw, peak=0.5)
    th = (np.sin(2 * np.pi * 140 * t) * expdec(len(t), 0.03) + bp(noise(d), 300, 2000) * expdec(len(t), 0.02))
    save("paper_hit", th, peak=0.5)
    # panier marque : petit jingle
    out = np.zeros(int(1.0 * SR))
    for k, semi in enumerate([7, 11, 14, 19]):
        nt = square(note_hz(semi), 0.12, 0.25) * env(int(0.12 * SR), 0.003, 0.05, 0.5, 0.05, 0.02)
        place(out, lp(nt, 4000) * 0.5, k * 0.09)
    save("score", out, peak=0.55)


def heartbeat():
    d = 1.0
    out = np.zeros(int(d * SR))
    t = t_axis(0.2)
    beat = np.sin(2 * np.pi * 55 * t) * expdec(len(t), 0.04)
    place(out, beat, 0.0)
    place(out, beat * 0.7, 0.22)
    save("heartbeat", lp(out, 200), peak=0.8)


def shimmer():
    d = 1.4
    out = np.zeros(int(d * SR))
    for k in range(10):
        nt = np.sin(2 * np.pi * note_hz(rng.choice([12, 15, 19, 22, 24, 27, 31])) * t_axis(0.6)) * expdec(int(0.6 * SR), 0.15)
        place(out, nt * 0.3, rng.uniform(0, 0.8))
    save("shimmer", reverb(out, 1.5, 0.5))


# ------------------------------------------------------------------ musique (radio)
def epiano(f, d):
    t = t_axis(d)
    mod = np.sin(2 * np.pi * f * 2.0 * t) * 1.2 * np.exp(-t / 0.4)
    car = np.sin(2 * np.pi * f * t + mod)
    return car * np.exp(-t / 1.2) * env(len(t), 0.004, 0.05, 1.0, 0.1, d - 0.16)


def music_lounge():
    bpm = 104
    beat = 60.0 / bpm
    bars = 16
    d = bars * 4 * beat
    out = np.zeros(int(d * SR) + SR)
    # Fmaj7 - Dm7 - Gm7 - C7 (semi-tons depuis A4)
    prog = [[-16, -12, -9, -5], [-19, -16, -12, -7], [-14, -11, -7, -2], [-21, -17, -14, -11]]
    roots = [-28, -31, -26, -33]
    for bar in range(bars):
        ch = prog[bar % 4]
        t0 = bar * 4 * beat
        for hit in (0.0, 1.5, 2.5):
            for semi in ch:
                place(out, epiano(note_hz(semi + 12), beat * 1.4) * 0.16, t0 + hit * beat)
        for k in range(4):
            semi = roots[bar % 4] + [0, 7, 12, 7][k]
            bs = lp(saw(note_hz(semi), beat * 0.9), 500) * env(int(beat * 0.9 * SR), 0.01, 0.1, 0.6, 0.1, beat * 0.6)
            place(out, bs * 0.35, t0 + k * beat)
        for k in range(8):
            br = hp(noise(0.12), 4000) * expdec(int(0.12 * SR), 0.03) * (0.12 if k % 2 else 0.07)
            place(out, br, t0 + k * beat * 0.5)
        for k in (1, 3):
            sn = bp(noise(0.25), 1500, 6000) * expdec(int(0.25 * SR), 0.06) * 0.18
            place(out, sn, t0 + k * beat)
        # melodie au vibraphone, une note par temps fort
        if bar % 2 == 0:
            for k, semi in enumerate(rng.choice([[3, 7, 10, 8], [5, 3, 0, -2], [7, 8, 7, 3]])):
                v = np.sin(2 * np.pi * note_hz(semi + 12) * t_axis(beat * 1.2)) * expdec(int(beat * 1.2 * SR), 0.4)
                place(out, v * 0.12, t0 + k * beat)
    out = reverb(out[: int(d * SR)], 1.2, 0.25)[: int(d * SR)]
    save("radio_lounge", out, peak=0.7)


def music_organ():
    bpm = 60
    beat = 60.0 / bpm
    prog = [[-21, -17, -14, -9], [-23, -19, -16, -11], [-26, -21, -17, -14], [-24, -19, -16, -12]]
    d = len(prog) * 2 * 4 * beat
    out = np.zeros(int(d * SR) + SR)
    for i in range(len(prog) * 2):
        ch = prog[i % len(prog)]
        t0 = i * 4 * beat
        for semi in ch + [ch[0] - 12]:
            f = note_hz(semi)
            dur = 4 * beat
            tone = sum(np.sin(2 * np.pi * f * h * t_axis(dur)) / h for h in (1, 2, 3, 4, 6, 8))
            tone *= env(len(tone), 0.08, 0.2, 0.8, 0.3, dur - 0.6)
            place(out, tone * 0.08, t0)
    out = reverb(out[: int(d * SR)], 4.0, 0.55)[: int(d * SR)]
    save("radio_organ", loopify(out, 2.0), peak=0.65)


def music_chip():
    bpm = 132
    beat = 60.0 / bpm
    bars = 16
    d = bars * 4 * beat
    out = np.zeros(int(d * SR) + SR)
    prog = [[0, 4, 7], [-3, 0, 4], [-7, -3, 0], [-5, -1, 2]]
    for bar in range(bars):
        ch = prog[bar % 4]
        t0 = bar * 4 * beat
        for k in range(16):
            semi = ch[k % 3] + (12 if (k // 3) % 2 else 0)
            nt = square(note_hz(semi + 3), beat * 0.24, 0.25) * env(int(beat * 0.24 * SR), 0.002, 0.03, 0.5, 0.02, 0.1)
            place(out, nt * 0.08, t0 + k * beat * 0.25)
        for k in range(4):
            bs = square(note_hz(ch[0] - 21), beat * 0.45, 0.5) * env(int(beat * 0.45 * SR), 0.002, 0.05, 0.6, 0.05, 0.25)
            place(out, lp(bs, 1200) * 0.2, t0 + k * beat)
            kick = np.sin(2 * np.pi * np.linspace(150, 40, int(0.15 * SR)) * t_axis(0.15)) * expdec(int(0.15 * SR), 0.05)
            place(out, kick * 0.4, t0 + k * beat)
        lead = [12, 14, 15, 19, 17, 15, 14, 12] if bar % 4 < 2 else [19, 17, 15, 14, 15, 17, 19, 22]
        for k, semi in enumerate(lead):
            nt = square(note_hz(semi + 3), beat * 0.45, 0.5) * env(int(beat * 0.45 * SR), 0.003, 0.05, 0.6, 0.05, 0.3)
            place(out, nt * 0.06, t0 + k * beat * 0.5)
    save("radio_chip", out[: int(d * SR)], peak=0.65)


# ------------------------------------------------------------------ sons rigolos
def formant_voice(f0_curve, d, formants, breath=0.15):
    t = t_axis(d)
    src = saw(f0_curve(t), d) + noise(d) * breath
    out = np.zeros_like(src)
    for fc, bw, amp in formants:
        out += bp(src, fc - bw, fc + bw) * amp
    return out


def laugh():
    out = np.zeros(int(1.6 * SR))
    for k in range(6):
        d = 0.16
        f0 = 260 - k * 12 + rng.uniform(-10, 10)
        v = formant_voice(lambda t: f0 * (1 + 0.15 * np.exp(-t * 20)), d, [(750, 150, 1.0), (1200, 200, 0.6), (2500, 300, 0.2)], 0.35)
        v *= env(len(v), 0.01, 0.05, 0.7, 0.06, 0.04)
        place(out, v, k * 0.2)
    save("laugh", reverb(out, 0.5, 0.15))


def fart():
    d = 1.3
    t = t_axis(d)
    f = 95 + 25 * np.sin(2 * np.pi * 7 * t) + 40 * np.exp(-t * 3) - t * 20
    x = lp(square(f, d, 0.3), 700) * (0.6 + 0.4 * np.abs(np.sin(2 * np.pi * 13 * t)))
    x += lp(noise(d), 400) * 0.3
    x *= env(len(t), 0.02, 0.1, 0.9, 0.35, 0.8)
    save("fart", x)


def boing():
    d = 0.8
    t = t_axis(d)
    f = 180 + 250 * np.exp(-t * 6) * (1 + 0.3 * np.sin(2 * np.pi * 18 * t))
    x = np.sin(2 * np.pi * np.cumsum(f) / SR) * np.exp(-t * 4)
    save("boing", x)


def cheer():
    d = 2.5
    out = np.zeros(int(d * SR))
    for k in range(10):
        f0 = rng.uniform(180, 380)
        v = formant_voice(lambda t, f0=f0: f0 * (1 + 0.3 * np.sin(2 * np.pi * 3 * t)), 1.6, [(rng.uniform(600, 900), 150, 1.0), (rng.uniform(1100, 1600), 200, 0.5)], 0.3)
        v *= env(len(v), 0.15, 0.3, 0.6, 0.6, 0.6)
        place(out, v * rng.uniform(0.4, 0.9), rng.uniform(0, 0.6))
    claps = np.zeros_like(out)
    for k in range(40):
        c = hp(noise(0.03), 1200) * expdec(int(0.03 * SR), 0.006)
        place(claps, c * 0.6, rng.uniform(0.2, 2.2))
    save("cheer", reverb(out + claps, 1.2, 0.3))


def slide_whistle():
    d = 1.0
    t = t_axis(d)
    f = 500 + 900 * (0.5 - 0.5 * np.cos(np.pi * t / d))
    x = np.sin(2 * np.pi * np.cumsum(f) / SR) * env(len(t), 0.05, 0.1, 0.8, 0.2, 0.6)
    save("whistle_up", x, peak=0.5)
    f2 = 1400 - 900 * (0.5 - 0.5 * np.cos(np.pi * t / d))
    x2 = np.sin(2 * np.pi * np.cumsum(f2) / SR) * env(len(t), 0.05, 0.1, 0.8, 0.2, 0.6)
    save("whistle_down", x2, peak=0.5)


def sad_trombone():
    out = np.zeros(int(2.4 * SR))
    for k, semi in enumerate([-2, -3, -4, -5]):
        d = 0.5 if k < 3 else 1.2
        t = t_axis(d)
        f = note_hz(semi - 12) * (1 + (0.02 * np.sin(2 * np.pi * 6 * t) if k == 3 else 0))
        x = lp(saw(f, d), 1500) * env(len(t), 0.03, 0.1, 0.8, 0.15, d - 0.3)
        place(out, x, k * 0.45)
    save("trombone", reverb(out, 0.6, 0.2))


def choir_ah():
    # "Messe obligatoire !" : choeur qui monte
    d = 3.0
    t = t_axis(d)
    x = np.zeros_like(t)
    for semi in [-12, -5, 0, 4, 7]:
        f = note_hz(semi)
        x += saw(f * (1 + 0.005 * np.sin(2 * np.pi * 5 * t + semi)), d)
    x = bp(x, 400, 1500) * env(len(t), 0.6, 0.3, 0.8, 1.0, 1.0)
    save("choir", reverb(x, 3.0, 0.5))


# ------------------------------------------------------------------ v0.9 : fous rires
def slap():
    d = 0.45
    t = t_axis(d)
    crack = hp(noise(d), 900) * expdec(len(t), 0.012)
    body = lp(noise(d), 1800) * expdec(len(t), 0.04) * 0.7
    thump = np.sin(2 * np.pi * 140 * t) * expdec(len(t), 0.03) * 0.5
    save("slap", reverb(crack + body + thump, 0.4, 0.15))


def bonk():
    d = 0.7
    t = t_axis(d)
    f = 520 * (1 + 0.6 * np.exp(-t * 40))
    x = np.sin(2 * np.pi * np.cumsum(f) / SR) * expdec(len(t), 0.12)
    x += 0.5 * np.sin(2 * np.pi * np.cumsum(f * 2.76) / SR) * expdec(len(t), 0.05)
    x += hp(noise(d), 2000) * expdec(len(t), 0.004) * 0.6
    save("bonk", x)


def squeak():
    # poulet en caoutchouc
    d = 0.55
    t = t_axis(d)
    f = 900 + 700 * np.sin(np.pi * t / d) + 60 * np.sin(2 * np.pi * 30 * t)
    x = formant_voice(lambda tt: f[: len(tt)], d, [(1400, 300, 1.0), (2800, 400, 0.7)], 0.5)
    x = x[: len(t)] * env(len(t), 0.01, 0.05, 0.9, 0.12, 0.35)
    x += 0.4 * saw(f, d) * env(len(t), 0.01, 0.05, 0.9, 0.12, 0.35)
    save("squeak", bp(x, 500, 6000), peak=0.8)


def kazoo_fanfare():
    out = np.zeros(int(1.9 * SR))
    for k, (semi, d) in enumerate([(0, 0.16), (0, 0.16), (0, 0.16), (5, 0.55), (9, 0.2), (12, 0.75)]):
        t = t_axis(d)
        f = note_hz(semi) * (1 + 0.012 * np.sin(2 * np.pi * 6 * t))
        x = formant_voice(lambda tt, f=f: f[: len(tt)], d, [(700, 120, 1.0), (1150, 150, 0.8), (2600, 250, 0.4)], 0.2)
        x = x[: len(t)] + 0.5 * bp(saw(f, d), 400, 3500)
        x *= env(len(t), 0.01, 0.03, 0.85, 0.05, d - 0.08)
        place(out, x, [0, 0.18, 0.36, 0.54, 1.1, 1.15][k] if k < 5 else 1.32)
    save("kazoo", reverb(out, 0.5, 0.15))


def pop():
    d = 0.25
    t = t_axis(d)
    f = 300 + 900 * np.exp(-t * 30)
    x = np.sin(2 * np.pi * np.cumsum(f) / SR) * expdec(len(t), 0.04)
    save("pop", x, peak=0.7)


def honk():
    d = 0.5
    t = t_axis(d)
    f = 330 + 20 * np.sin(2 * np.pi * 8 * t)
    x = lp(square(f, d, 0.3), 2200) + 0.6 * lp(saw(f * 1.5, d), 2000)
    x *= env(len(t), 0.01, 0.05, 0.9, 0.1, 0.3)
    save("honk", x, peak=0.7)


def disco_loop():
    # messe disco : 4 temps, charleston, basse octave, cordes
    bpm = 120
    beat = 60.0 / bpm
    bars = 4
    d = bars * 4 * beat
    out = np.zeros(int(d * SR))
    kick_t = t_axis(0.25)
    kick = np.sin(2 * np.pi * np.cumsum(50 + 120 * np.exp(-kick_t * 30)) / SR) * expdec(len(kick_t), 0.09)
    hat = hp(noise(0.06), 7000) * expdec(int(0.06 * SR), 0.015)
    clap = bp(noise(0.12), 900, 4000) * expdec(int(0.12 * SR), 0.03)
    chords = [[0, 4, 7], [-3, 0, 4], [-7, -3, 0], [-5, -1, 2]]
    roots = [-24, -27, -31, -29]
    for b in range(bars * 4):
        at = b * beat
        place(out, kick * 0.9, at)
        place(out, hat * 0.35, at + beat / 2)
        if b % 2 == 1:
            place(out, clap * 0.5, at)
        bar = b // 4
        # basse en octaves
        for h in range(2):
            n = roots[bar] + (12 if h else 0)
            bt = t_axis(beat / 2)
            bass = lp(saw(note_hz(n), beat / 2), 900) * env(len(bt), 0.005, 0.05, 0.6, 0.05, beat / 2 - 0.1)
            place(out, bass * 0.45, at + h * beat / 2)
    for bar in range(bars):
        ct = t_axis(4 * beat)
        pad = np.zeros(len(ct))
        for n in chords[bar]:
            pad += saw(note_hz(n) * (1 + 0.003 * np.sin(2 * np.pi * 5 * ct)), 4 * beat)
        pad = lp(pad, 2500) * env(len(ct), 0.05, 0.2, 0.7, 0.2, 4 * beat - 0.3) * 0.18
        place(out, pad, bar * 4 * beat)
    n = len(out)
    wet = reverb(out, 0.6, 0.12)
    looped = wet[:n].copy()
    tail = wet[n:]
    looped[: len(tail)] += tail
    save("disco", looped)


def roll_loop():
    # roulettes de chaise de bureau sur le marbre
    d = 2.0
    t = t_axis(d)
    x = lp(brown(d), 300) * 0.8 + bp(noise(d), 1200, 3000) * 0.08 * (0.6 + 0.4 * np.sin(2 * np.pi * 11 * t))
    x *= 0.8 + 0.2 * np.sin(2 * np.pi * 3 * t)
    n = len(x)
    xf = int(0.2 * SR)
    x[:xf] = x[:xf] * np.linspace(0, 1, xf) + x[n - xf:] * np.linspace(1, 0, xf)
    save("roll", x[: n - xf], peak=0.6)


def intro_sounds():
    # BOOM de bande-annonce : sous-grave + craquement + queue de reverb
    d = 4.0
    t = t_axis(d)
    sub = np.sin(2 * np.pi * np.cumsum(28 + 70 * np.exp(-t * 3.0)) / SR) * np.exp(-t * 0.9)
    crack = lp(noise(d), 2500) * np.exp(-t * 6.0) * 0.6
    boom = reverb(sub * 1.2 + crack, 2.5, 0.35)
    save("boom", boom)
    # glitch numerique
    d2 = 0.6
    t2 = t_axis(d2)
    g = square(np.where((t2 * 30).astype(int) % 2 == 0, 180, 1400), d2, 0.4) * 0.5
    g += hp(noise(d2), 3000) * (np.sin(2 * np.pi * 23 * t2) > 0) * 0.5
    g *= env(len(t2), 0.005, 0.05, 0.9, 0.05, 0.5)
    save("glitch", g, peak=0.6)
    # bourdon sombre (drone) en boucle douce
    d3 = 8.0
    t3 = t_axis(d3)
    dr = np.zeros_like(t3)
    for f in [55, 82.4, 110.2, 164.8]:
        dr += saw(f * (1 + 0.003 * np.sin(2 * np.pi * 0.2 * t3 + f)), d3)
    dr = lp(dr, 600) * (0.6 + 0.4 * np.sin(2 * np.pi * 0.125 * t3)) * 0.4
    dr += lp(brown(d3), 200) * 0.3
    dr *= env(len(t3), 1.5, 0.1, 1.0, 1.5, d3 - 3.0)
    save("drone", reverb(dr, 3.0, 0.4))
    # bip de texte (machine a ecrire numerique)
    d4 = 0.04
    t4 = t_axis(d4)
    b = np.sin(2 * np.pi * 1900 * t4) * expdec(len(t4), 0.01)
    save("blip", b, peak=0.4)


if __name__ == "__main__":
    import sys
    if len(sys.argv) > 1 and sys.argv[1] == "intro":
        intro_sounds()
        sys.exit(0)
    if len(sys.argv) > 1 and sys.argv[1] == "disco":
        disco_loop(); roll_loop()
        sys.exit(0)
    if len(sys.argv) > 1 and sys.argv[1] == "fun2":
        slap(); bonk(); squeak(); kazoo_fanfare(); pop(); honk()
        sys.exit(0)
    if len(sys.argv) > 1 and sys.argv[1] == "fun":
        laugh(); fart(); boing(); cheer(); slide_whistle(); sad_trombone(); choir_ah()
        sys.exit(0)
    laugh(); fart(); boing(); cheer(); slide_whistle(); sad_trombone(); choir_ah()
    slap(); bonk(); squeak(); kazoo_fanfare(); pop(); honk()
    disco_loop()
    roll_loop()
    intro_sounds()
    amb_office()
    amb_menu()
    phone_ring()
    typing_loop()
    footsteps()
    sale()
    god_speak()
    buzz_error()
    power()
    thunder()
    frogs()
    meow()
    coffee()
    ui()
    bells()
    power_down()
    beeps()
    paper()
    heartbeat()
    shimmer()
    music_lounge()
    music_organ()
    music_chip()
