"""Pieces de decor « pate a modeler » (res://models/env/*.obj).

    python3 tools/gen_env.py [prefixes...]
"""
import os
import sys
import numpy as np
from sdf import *

OUT = os.path.join(os.path.dirname(__file__), "..", "models", "env")
os.makedirs(OUT, exist_ok=True)
PARTS = {}


def part(name, lo, hi, res=0.01, tris=3000):
    def deco(fn):
        PARTS[name] = (fn, lo, hi, res, tris)
        return fn
    return deco


# ------------------------------------------------------------------ vestiaire

@part("locker", (-0.26, -0.01, -0.27), (0.26, 1.96, 0.27), 0.008, 5000)
def locker():
    body = rbox((0.23, 0.97, 0.24), 0.025, (0, 0.97, 0))
    # porte en relief + fentes d'aeration + poignee
    door_in = rbox((0.2, 0.9, 0.02), 0.01, (0, 0.98, -0.25))
    vents = union(*[rbox((0.13, 0.008, 0.03), 0.006, (0, 1.6 + i * 0.045, -0.24)) for i in range(5)])
    vents2 = union(*[rbox((0.13, 0.008, 0.03), 0.006, (0, 0.3 + i * 0.045, -0.24)) for i in range(4)])
    handle = rbox((0.012, 0.07, 0.02), 0.008, (0.15, 1.0, -0.255))
    plate = rbox((0.05, 0.02, 0.006), 0.004, (0, 1.42, -0.245))
    b = sub(body, door_in, 0.01)
    b = sub(b, union(vents, vents2), 0.004)
    return union(b, handle, plate)


@part("bench", (-0.8, -0.01, -0.22), (0.8, 0.5, 0.22), 0.01, 3000)
def bench():
    seat = rbox((0.78, 0.04, 0.2), 0.02, (0, 0.44, 0))
    legs = mirror_x(rbox((0.04, 0.2, 0.17), 0.015, (0.65, 0.2, 0)))
    return union(seat, legs)


@part("folded", (-0.2, -0.01, -0.15), (0.2, 0.2, 0.15), 0.006, 1500)
def folded():
    return union(*[rbox((0.17 - i * 0.01, 0.025, 0.12), 0.02, (0.0 + i * 0.005, 0.025 + i * 0.05, 0)) for i in range(3)])


@part("mirror_frame", (-0.5, -0.01, -0.08), (0.5, 1.5, 0.08), 0.008, 3000)
def mirror_frame():
    outer = rbox((0.46, 0.72, 0.05), 0.03, (0, 0.74, 0))
    inner = rbox((0.38, 0.64, 0.1), 0.02, (0, 0.74, -0.02))
    return sub(outer, inner)


@part("bulb", (-0.05, -0.05, -0.05), (0.05, 0.05, 0.05), 0.004, 600)
def bulb():
    return sphere(0.042)


@part("eye_sign", (-1.3, -0.65, -0.12), (1.3, 0.65, 0.12), 0.012, 5000)
def eye_sign():
    # oeil-enseigne : amande lumineuse + iris
    def almond(P):
        a = np.linalg.norm(P[:, :2] - np.array([0, -0.9]), axis=1) - 1.45
        b = np.linalg.norm(P[:, :2] - np.array([0, 0.9]), axis=1) - 1.45
        return np.maximum(np.maximum(a, b), np.abs(P[:, 2]) - 0.05) - 0.02
    return almond


@part("eye_iris", (-0.5, -0.5, -0.1), (0.5, 0.5, 0.1), 0.008, 3000)
def eye_iris():
    ring = xform(torus(0.3, 0.06), rot=rot_x(np.pi / 2))
    disk = xform(cyl(0.23, 0.03, round_=0.02), rot=rot_x(np.pi / 2))
    return union(ring, disk)


@part("tube_light", (-0.9, -0.08, -0.12), (0.9, 0.12, 0.12), 0.008, 2000)
def tube_light():
    housing = rbox((0.85, 0.04, 0.09), 0.02, (0, 0.06, 0))
    tube = capsule((-0.78, 0.0, 0), (0.78, 0.0, 0), 0.04)
    return union(housing, tube)


@part("pot", (-0.25, -0.01, -0.25), (0.25, 0.42, 0.25), 0.008, 2000)
def pot():
    p = sub(cone(0.15, 0.2, 0.18, (0, 0.18, 0)), cyl(0.17, 0.05, (0, 0.38, 0)))
    soil = cyl(0.17, 0.02, (0, 0.33, 0))
    rim = xform(torus(0.2, 0.025), (0, 0.36, 0))
    return union(p, soil, rim)


@part("leaves", (-0.7, -0.05, -0.7), (0.7, 1.2, 0.7), 0.01, 5000)
def leaves():
    rng = np.random.default_rng(4)
    lv = []
    for i in range(11):
        a = rng.uniform(0, 2 * np.pi)
        tilt = rng.uniform(0.4, 1.1)
        ln = rng.uniform(0.35, 0.6)
        tip = np.array([np.cos(a) * np.sin(tilt) * ln, np.cos(tilt) * ln + 0.35, np.sin(a) * np.sin(tilt) * ln])
        mid = tip * 0.55 + np.array([0, 0.15, 0])
        leaf = xform(ellipsoid((0.07, 0.012, ln * 0.5)), tuple(mid), rot_y(-a + np.pi / 2) @ rot_x(-(np.pi / 2 - tilt) * 0.8))
        lv.append(leaf)
        lv.append(capsule((0, 0.3, 0), tuple(mid * 0.6 + np.array([0, 0.1, 0])), 0.012))
    return union(*lv)


@part("rug", (-1.0, -0.01, -1.0), (1.0, 0.05, 1.0), 0.01, 3000)
def rug():
    return cyl(0.95, 0.015, (0, 0.015, 0), 0.012)


@part("coat_hook", (-0.6, -0.1, -0.1), (0.6, 0.1, 0.1), 0.005, 1500)
def coat_hook():
    bar = rbox((0.55, 0.02, 0.02), 0.01)
    hooks = union(*[capsule((x, 0, 0), (x, -0.06, -0.05), 0.01) for x in (-0.4, -0.13, 0.13, 0.4)])
    return union(bar, hooks)


@part("hanging_shirt", (-0.3, -0.75, -0.12), (0.3, 0.05, 0.12), 0.007, 2500)
def hanging_shirt():
    body = rbox((0.18, 0.28, 0.06), 0.05, (0, -0.38, 0))
    sleeves = mirror_x(xform(capsule((0, 0, 0), (0, -0.3, 0), 0.05), (0.2, -0.15, 0), rot_z(0.25)))
    hanger = xform(torus(0.03, 0.006), (0, -0.02, 0), rot_x(np.pi / 2))
    return union(smooth(0.03, body, sleeves), hanger)


@part("mug_prop", (-0.08, -0.01, -0.08), (0.12, 0.16, 0.08), 0.004, 1500)
def mug_prop():
    body = sub(cyl(0.055, 0.065, (0, 0.065, 0), 0.008), cyl(0.045, 0.065, (0, 0.077, 0)))
    handle = xform(torus(0.035, 0.011), (0.065, 0.065, 0), rot_x(np.pi / 2))
    return union(body, inter(handle, lambda P: 0.055 - P[:, 0]))


def main():
    only = sys.argv[1:]
    for name, (fn, lo, hi, res, tris) in PARTS.items():
        if only and not any(name.startswith(o) for o in only):
            continue
        try:
            v, n, f = mesh(fn(), lo, hi, res, tris)
        except Exception as e:
            print("ECHEC", name, e)
            continue
        write_obj(os.path.join(OUT, name + ".obj"), v, n, f)
        print("%-16s %6d triangles" % (name, len(f)))


if __name__ == "__main__":
    main()
