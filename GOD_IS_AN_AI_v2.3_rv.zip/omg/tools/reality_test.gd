extends Node
## Tests unitaires de REALITY ECHO.
## godot --headless res://tools/reality_test.tscn
var WHO := ["SAMUEL", "J-F", "CORINNE", "MAXIME", "JULIE", "DAVE", "SOPHIE", "RENAUD"]
var fails := 0
var checks := 0

func ok(cond: bool, what: String) -> void:
	checks += 1
	if not cond:
		fails += 1
		print("  ECHEC : ", what)

func _ready() -> void:
	await get_tree().process_frame
	var backup := FileAccess.get_file_as_string(Reality.PATH) if FileAccess.file_exists(Reality.PATH) else ""
	_t_false_positives()
	_t_seeds()
	_t_amplify_and_tiers()
	_t_characters()
	_t_cap()
	_t_persist()
	_t_corrupt_files()
	_t_snapshot()
	_t_shape()
	_t_ai_items()
	_t_promises()
	# on remet le monde du joueur
	if backup != "":
		var f := FileAccess.open(Reality.PATH, FileAccess.WRITE)
		f.store_string(backup)
		f = null
	else:
		DirAccess.remove_absolute(ProjectSettings.globalize_path(Reality.PATH))
	print("REALITY TESTS : ", checks - fails, "/", checks, " OK")
	get_tree().quit(1 if fails > 0 else 0)

func _fresh() -> void:
	Reality.reset_world()
	Reality.buffer = []

func _t_false_positives() -> void:
	print("- phrases banales (ne doivent PAS creer d'echo)")
	_fresh()
	var banal := ["Salut, ça va ?", "J'ai perdu mon emploi hier", "On se voit plus loin", "Le plateau de fromages est servi",
		"Passe-moi la tarte s'il te plaît", "haha trop drôle", "OK on y va", "Hello how are you doing",
		"I lost my job yesterday", "Merci beaucoup Seigneur", "Je vais chercher un café", "C'est quoi ton problème",
		"Il est quelle heure là", "Attends je reviens", "Nice one buddy", "Où est le stagiaire",
		"Quelle difficulté ce niveau", "Un vrai massacre ce matin", "Je t'envoie ça dans le chat",
		"Le client raccroche encore", "Mon exploit du jour", "Allô oui bonjour"]
	for s in banal:
		var n: int = Reality.echoes.size()
		Reality.hear(s, "SAMUEL", "voice")
		if Reality.echoes.size() != n:
			print("    faux positif : « ", s, " » -> ", Reality.echoes[-1]["kind"], " ", Reality.echoes[-1]["key"])
	ok(Reality.echoes.size() <= 1, "phrases banales : %d echos crees (max 1 toléré)" % Reality.echoes.size())

func _t_seeds() -> void:
	print("- graines")
	_fresh()
	var seeds := {"Imagine si les pigeons étaient des caméras": "rule", "Et si la gravité arrêtait de marcher le lundi": "rule",
		"What if cats were secret spies": "rule", "Tout le monde devrait adorer les grille-pains": "belief",
		"Imagine si la Terre était vraiment plate": "rule", "Je gage que les toasters complotent contre nous": "belief"}
	for s in seeds:
		var n: int = Reality.echoes.size()
		Reality.hear(s, "SAMUEL", "voice")
		ok(Reality.echoes.size() == n + 1, "graine non creee : " + s)
		if Reality.echoes.size() == n + 1:
			ok(str(Reality.echoes[-1]["kind"]) == seeds[s], "type %s attendu pour « %s », eu %s" % [seeds[s], s, Reality.echoes[-1]["kind"]])

func _t_amplify_and_tiers() -> void:
	print("- amplification et niveaux")
	_fresh()
	Reality.hear("Imagine si les pigeons étaient des caméras", "SAMUEL", "voice")
	var e: Dictionary = Reality.echoes[0]
	var s0 := float(e["strength"])
	Reality.hear("Les pigeons caméras nous regardent", "CORINNE", "voice")
	ok(Reality.echoes.size() == 1, "la reprise doit amplifier, pas creer (%d echos)" % Reality.echoes.size())
	ok(float(e["strength"]) > s0, "force doit augmenter")
	ok(e["speakers"].size() == 2, "2 orateurs attendus")
	# delai : sans maturation, jamais au-dela du niveau 1
	for i in 30:
		Reality.hear("les pigeons sont des caméras vraiment", ["SAMUEL", "CORINNE", "BOB"][i % 3], "voice")
	ok(int(e["tier"]) <= 1, "ECHO DELAY : niveau %d avant maturation" % int(e["tier"]))
	# maturation : un niveau a la fois
	var seen := [int(e["tier"])]
	for i in 12:
		e["ready_at"] = 0.0
		e["next_at"] = 0.0
		Reality._check_tier(e)
		if int(e["tier"]) != seen[-1]:
			ok(int(e["tier"]) == seen[-1] + 1, "saut de niveau %d -> %d" % [seen[-1], int(e["tier"])])
			seen.append(int(e["tier"]))
	ok(int(e["tier"]) == 5, "doit atteindre la reecriture (niveau %d)" % int(e["tier"]))
	ok(Reality.hooks.has("pigeon"), "hook pigeon actif")
	ok(not Reality.hooks.has("flat"), "pas de hook flat parasite : " + str(Reality.hooks.keys()))
	ok(Reality.rules.size() == 1, "1 loi reecrite")

func _t_characters() -> void:
	print("- personnages inventes")
	_fresh()
	Reality.hear("Ah non pas encore Gérard", "CORINNE", "voice")
	ok(Reality.echoes.size() == 1 and str(Reality.echoes[0]["kind"]) == "character", "Gérard doit etre un personnage")
	Reality.hear("Gérard va rappeler je le sens", "SAMUEL", "voice")
	ok(Reality.echoes.size() == 1, "Gérard doit etre amplifie (%d)" % Reality.echoes.size())
	# un personnage plafonne au niveau 4
	var e: Dictionary = Reality.echoes[0]
	e["strength"] = 50.0
	for i in 10:
		e["ready_at"] = 0.0
		e["next_at"] = 0.0
		Reality._check_tier(e)
	ok(int(e["tier"]) == 4, "personnage plafonne a 4 (eu %d)" % int(e["tier"]))
	# les noms des joueurs / collegues ne sont pas des personnages
	_fresh()
	Reality.hear("Bien joué Corinne tu l'as eu", "SAMUEL", "voice")
	ok(Reality.echoes.is_empty(), "un nom de JOUEUR ne doit pas devenir un personnage")

func _t_cap() -> void:
	print("- plafond memoire")
	_fresh()
	for i in 150:
		Reality.hear("Imagine si les grille-pains numéro%d formaient une secte" % i, "P%d" % i, "voice")
	ok(Reality.echoes.size() <= Reality.MAX_ECHOES, "max %d echos (eu %d)" % [Reality.MAX_ECHOES, Reality.echoes.size()])

func _t_persist() -> void:
	print("- sauvegarde / chargement")
	_fresh()
	Reality.hear("Imagine si la Terre était vraiment plate", "SAMUEL", "voice")
	Reality.hear("Tout le monde devrait adorer les grille-pains", "SAMUEL", "voice")
	var e: Dictionary = Reality.echoes[0]
	e["strength"] = 40.0
	for i in 8:
		e["ready_at"] = 0.0
		e["next_at"] = 0.0
		Reality._check_tier(e)
	Reality.save_world()
	var n: int = Reality.echoes.size()
	Reality.echoes = []
	Reality.hooks = {}
	Reality.rules = []
	Reality.load_world()
	ok(Reality.echoes.size() == n, "echos recharges")
	ok(Reality.hooks.has("flat"), "hook flat recharge")
	ok(Reality.rules.size() == 1, "loi rechargee")
	# les echos recharges restent utilisables (types JSON -> float)
	var p: Dictionary = Reality.pick_for_prayer()
	ok(true, "pick apres chargement")
	Reality.hear("La Terre plate tout le monde le sait", "BOB", "voice")
	ok(Reality.echoes.size() == n, "amplification apres chargement")

func _t_corrupt_files() -> void:
	print("- fichiers corrompus")
	for junk in ["", "{{{", "[]", "{\"echoes\": \"x\"}", "{\"echoes\": [1, \"a\", {}], \"hooks\": [], \"rules\": {}}", "{\"echoes\": [{\"id\": 3}]}"]:
		var f := FileAccess.open(Reality.PATH, FileAccess.WRITE)
		f.store_string(junk)
		f = null
		Reality.echoes = []
		Reality.load_world()
		ok(typeof(Reality.echoes) == TYPE_ARRAY and typeof(Reality.hooks) == TYPE_DICTIONARY and typeof(Reality.rules) == TYPE_ARRAY, "types apres " + junk)
		# le jeu doit continuer de tourner
		Reality.hear("Imagine si les pigeons étaient des caméras", "SAMUEL", "voice")
		Reality.pick_for_prayer()
		Reality.trends()
		Reality.rules_prompt()
		for e in Reality.echoes:
			ok(typeof(e) == TYPE_DICTIONARY and e.has("stems") and e.has("history"), "echo valide apres " + junk)
	_fresh()

func _t_snapshot() -> void:
	print("- snapshot reseau")
	_fresh()
	Reality.hear("Imagine si les pigeons étaient des caméras", "SAMUEL", "voice")
	for i in 40:
		Reality.echoes[0]["history"].append("x %d" % i)
	var snap: Dictionary = Reality.snapshot()
	var bytes := var_to_bytes(snap).size()
	ok(bytes < 60000, "snapshot < 60 Ko (%d)" % bytes)
	var copy: Dictionary = bytes_to_var(var_to_bytes(snap))
	Reality.apply_snapshot(copy)
	ok(Reality.echoes.size() == 1, "snapshot applique")

func _t_shape() -> void:
	print("- faconnage des prieres")
	_fresh()
	Reality.hear("Imagine si les pigeons étaient des caméras", "SAMUEL", "voice")
	Reality.hear("Ah non pas encore Gérard", "CORINNE", "voice")
	Reality.add_promise("Je te promets que ton chien est vivant", "SAMUEL", "Brenda Finch")
	for e in Reality.echoes:
		for tier in [1, 2, 3, 4, 5]:
			e["tier"] = tier
			var b := {"name": "Test Person", "pers_prompt": "Base. ", "shame": "x"}
			b = Reality.shape_believer(b, e)
			ok(str(b["pers_prompt"]).begins_with("Base. ") and str(b["pers_prompt"]).length() > 8, "prompt tier %d %s" % [tier, e["kind"]])
			ok(not str(b["pers_prompt"]).contains("%s"), "placeholder non remplace")
			if str(e["kind"]) == "character" and tier >= 3:
				ok(str(b["name"]) == "Gérard" and b.has("echo_self"), "Gérard appelle lui-meme")
	ok(Reality.echoes.all(func(e): return e["history"].size() <= 30), "historique borne")

func _t_ai_items() -> void:
	print("- reponses IA farfelues")
	_fresh()
	for it in [{}, {"key": ""}, {"key": "x", "kind": "dragon"}, {"key": "a".repeat(500), "idea": "y"},
			{"key": "ok_idee", "idea": "une idée", "tags": "pas une liste", "funny": "beaucoup"},
			{"key": "ok2", "idea": "z", "kind": "character", "name": ""}]:
		Reality._apply_ai_item(it)
	for e in Reality.echoes:
		ok(str(e["kind"]) in ["belief", "rule", "character", "object", "lie"], "kind valide (" + str(e["kind"]) + ")")
		ok(str(e["key"]).length() <= 40, "cle bornee")
		ok(typeof(e["tags"]) == TYPE_ARRAY, "tags liste")
		ok(not (str(e["kind"]) == "character" and str(e["name"]) == ""), "personnage sans nom")

func _t_promises() -> void:
	print("- promesses")
	_fresh()
	Reality.add_promise("Je te promets que ton chien est vivant", "SAMUEL", "Brenda Finch")
	Reality.add_promise("Je te promets, ton chien est vivant !", "SAMUEL", "Brenda Finch")
	Reality.add_promise("Je te promets que tu vas gagner au loto", "CORINNE", "Kevin Roy")
	ok(Reality.echoes.size() == 2, "promesses fusionnees (%d)" % Reality.echoes.size())
	# fusion d'une idee de l'IA sous une autre cle
	_fresh()
	Reality.hear("Imagine si la Terre était vraiment plate", "SAMUEL", "voice")
	Reality._apply_ai_item({"key": "monde_plat", "idea": "La Terre est plate", "quote": "la Terre est plate pour vrai", "kind": "rule"})
	ok(Reality.echoes.size() == 1, "idee IA fusionnee avec l'existante (%d)" % Reality.echoes.size())
