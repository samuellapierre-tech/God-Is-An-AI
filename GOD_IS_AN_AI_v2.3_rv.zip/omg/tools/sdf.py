"""Mini-librairie SDF -> maillages lisses (style pate a modeler).

Chaque forme est une fonction f(P) -> distance signee, P = tableau (N, 3).
On combine avec union / smooth union / soustraction, puis `mesh()` extrait
la surface (marching cubes), simplifie et calcule des normales exactes a
partir du gradient du champ (rendu parfaitement lisse).

Repere Godot : Y en haut, le personnage regarde vers -Z.
"""
import numpy as np
from skimage.measure import marching_cubes
import fast_simplification


# ------------------------------------------------------------------ outils

def _v(x):
    return np.asarray(x, dtype=np.float64)


def rot_x(a):
    c, s = np.cos(a), np.sin(a)
    return np.array([[1, 0, 0], [0, c, -s], [0, s, c]])


def rot_y(a):
    c, s = np.cos(a), np.sin(a)
    return np.array([[c, 0, s], [0, 1, 0], [-s, 0, c]])


def rot_z(a):
    c, s = np.cos(a), np.sin(a)
    return np.array([[c, -s, 0], [s, c, 0], [0, 0, 1]])


def xform(f, pos=(0, 0, 0), rot=None, scale=None):
    """Place la forme f en `pos`, tournee par la matrice `rot`, etiree par `scale`."""
    pos = _v(pos)
    inv = None if rot is None else np.linalg.inv(rot)
    sc = None if scale is None else _v(scale)

    def g(P):
        Q = P - pos
        if inv is not None:
            Q = Q @ inv.T
        if sc is not None:
            Q = Q / sc
            return f(Q) * np.min(sc)
        return f(Q)
    return g


# ------------------------------------------------------------------ primitives

def sphere(r, c=(0, 0, 0)):
    c = _v(c)
    return lambda P: np.linalg.norm(P - c, axis=1) - r


def ellipsoid(r, c=(0, 0, 0)):
    """Ellipsoide (approximation de distance correcte pres de la surface)."""
    r = _v(r)
    c = _v(c)

    def f(P):
        Q = P - c
        k0 = np.linalg.norm(Q / r, axis=1)
        k1 = np.linalg.norm(Q / (r * r), axis=1)
        return k0 * (k0 - 1.0) / np.maximum(k1, 1e-9)
    return f


def capsule(a, b, r, r2=None):
    """Capsule de a a b ; r2 = rayon au bout b (cone arrondi)."""
    a = _v(a)
    b = _v(b)
    r2 = r if r2 is None else r2

    def f(P):
        pa = P - a
        ba = b - a
        h = np.clip((pa @ ba) / (ba @ ba), 0.0, 1.0)
        return np.linalg.norm(pa - h[:, None] * ba, axis=1) - (r + (r2 - r) * h)
    return f


def rbox(size, r, c=(0, 0, 0)):
    """Boite aux coins arrondis ; size = demi-tailles."""
    b = _v(size) - r
    c = _v(c)

    def f(P):
        q = np.abs(P - c) - b
        return np.linalg.norm(np.maximum(q, 0.0), axis=1) + np.minimum(np.max(q, axis=1), 0.0) - r
    return f


def torus(R, r, c=(0, 0, 0)):
    """Tore dans le plan XZ (axe Y)."""
    c = _v(c)

    def f(P):
        Q = P - c
        q = np.stack([np.linalg.norm(Q[:, [0, 2]], axis=1) - R, Q[:, 1]], axis=1)
        return np.linalg.norm(q, axis=1) - r
    return f


def cyl(r, h, c=(0, 0, 0), round_=0.0):
    """Cylindre d'axe Y, demi-hauteur h, bords arrondis."""
    c = _v(c)

    def f(P):
        Q = P - c
        d = np.stack([np.linalg.norm(Q[:, [0, 2]], axis=1) - r + round_, np.abs(Q[:, 1]) - h + round_], axis=1)
        return np.minimum(np.maximum(d[:, 0], d[:, 1]), 0.0) + np.linalg.norm(np.maximum(d, 0.0), axis=1) - round_
    return f


def cone(r1, r2, h, c=(0, 0, 0)):
    """Cone tronque d'axe Y de y=-h (rayon r1) a y=+h (rayon r2)."""
    c = _v(c)

    def f(P):
        Q = P - c
        q = np.stack([np.linalg.norm(Q[:, [0, 2]], axis=1), Q[:, 1]], axis=1)
        k1 = np.array([r2, h])
        k2 = np.array([r2 - r1, 2.0 * h])
        ca = np.stack([q[:, 0] - np.minimum(q[:, 0], np.where(q[:, 1] < 0, r1, r2)), np.abs(q[:, 1]) - h], axis=1)
        cb = q - k1 + k2 * np.clip(((k1 - q) @ k2) / (k2 @ k2), 0.0, 1.0)[:, None]
        s = np.where((cb[:, 0] < 0) & (ca[:, 1] < 0), -1.0, 1.0)
        return s * np.sqrt(np.minimum((ca * ca).sum(1), (cb * cb).sum(1)))
    return f


def plane_y(y):
    return lambda P: P[:, 1] - y


# ------------------------------------------------------------------ operations

def union(*fs):
    def f(P):
        d = fs[0](P)
        for g in fs[1:]:
            d = np.minimum(d, g(P))
        return d
    return f


def smooth(k, *fs):
    """Union douce (la pate se fond)."""
    def f(P):
        d = fs[0](P)
        for g in fs[1:]:
            e = g(P)
            h = np.clip(0.5 + 0.5 * (e - d) / k, 0.0, 1.0)
            d = e * (1 - h) + d * h - k * h * (1 - h)
        return d
    return f


def sub(a, b, k=0.0):
    """a moins b (k > 0 : soustraction douce)."""
    if k <= 0:
        return lambda P: np.maximum(a(P), -b(P))

    def f(P):
        d1 = a(P)
        d2 = -b(P)
        h = np.clip(0.5 - 0.5 * (d2 - d1) / k, 0.0, 1.0)
        return d2 * (1 - h) + d1 * h + k * h * (1 - h)
    return f


def inter(a, b):
    return lambda P: np.maximum(a(P), b(P))


def shell(f, t):
    """Coquille d'epaisseur t autour de la surface."""
    return lambda P: np.abs(f(P)) - t


def mirror_x(f):
    def g(P):
        Q = P.copy()
        Q[:, 0] = np.abs(Q[:, 0])
        return f(Q)
    return g


def displace(f, amp, freq, seed=0):
    """Bosselage doux (relief de pate a modeler / cheveux boucles)."""
    rng = np.random.default_rng(seed)
    ph = rng.uniform(0, 6.28, 9)

    def g(P):
        n = (np.sin(P[:, 0] * freq + ph[0]) * np.sin(P[:, 1] * freq * 1.1 + ph[1]) * np.sin(P[:, 2] * freq * 0.9 + ph[2])
             + 0.5 * np.sin(P[:, 0] * freq * 2.1 + ph[3]) * np.sin(P[:, 1] * freq * 1.9 + ph[4]) * np.sin(P[:, 2] * freq * 2.3 + ph[5]))
        return f(P) + amp * n
    return g


# ------------------------------------------------------------------ extraction

def mesh(f, lo, hi, res=0.006, target_tris=4000, smooth_iters=0):
    """Retourne (verts, normals, faces) de la surface f=0 dans la boite [lo, hi]."""
    lo = _v(lo) - res * 2
    hi = _v(hi) + res * 2
    n = np.ceil((hi - lo) / res).astype(int) + 1
    xs = [np.linspace(lo[i], lo[i] + res * (n[i] - 1), n[i]) for i in range(3)]
    G = np.stack(np.meshgrid(*xs, indexing="ij"), axis=-1).reshape(-1, 3)
    vals = np.empty(G.shape[0])
    step = 400000
    for i in range(0, G.shape[0], step):
        vals[i:i + step] = f(G[i:i + step])
    vol = vals.reshape(n)
    if vol.min() > 0 or vol.max() < 0:
        raise ValueError("forme vide ou hors de la boite")
    v, fc, _, _ = marching_cubes(vol, 0.0, spacing=(res, res, res))
    v = v + lo
    if target_tris and fc.shape[0] > target_tris:
        red = 1.0 - target_tris / fc.shape[0]
        v, fc = fast_simplification.simplify(v.astype(np.float32), fc.astype(np.int32), red)
        v = v.astype(np.float64)
    # normales exactes = gradient du champ
    e = res * 0.5
    nx = f(v + [e, 0, 0]) - f(v - [e, 0, 0])
    ny = f(v + [0, e, 0]) - f(v - [0, e, 0])
    nz = f(v + [0, 0, e]) - f(v - [0, 0, e])
    nrm = np.stack([nx, ny, nz], axis=1)
    nrm /= np.maximum(np.linalg.norm(nrm, axis=1, keepdims=True), 1e-12)
    # marching cubes de skimage : orientation des triangles a verifier
    a, b, c = v[fc[:, 0]], v[fc[:, 1]], v[fc[:, 2]]
    fn = np.cross(b - a, c - a)
    if (fn * nrm[fc[:, 0]]).sum() < 0:
        fc = fc[:, [0, 2, 1]]
    return v, nrm, fc


def write_obj(path, v, n, fc):
    with open(path, "w") as fh:
        fh.write("# genere par tools/gen_models.py\n")
        for p in v:
            fh.write("v %.5f %.5f %.5f\n" % (p[0], p[1], p[2]))
        for p in n:
            fh.write("vn %.4f %.4f %.4f\n" % (p[0], p[1], p[2]))
        for t in fc:
            a, b, c = t[0] + 1, t[1] + 1, t[2] + 1
            fh.write("f %d//%d %d//%d %d//%d\n" % (a, a, b, b, c, c))
