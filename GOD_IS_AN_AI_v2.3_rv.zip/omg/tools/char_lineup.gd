extends Node3D
## Scene de test : alignement des personnages (comparaison avec les planches).
##   MODE=a (6 premiers employes) | b (6 suivants) | random | emo | close
const Character := preload("res://scripts/character.gd")

func _ready() -> void:
	var env := WorldEnvironment.new()
	var e := Environment.new()
	e.background_mode = Environment.BG_COLOR
	e.background_color = Color(0.2, 0.15, 0.11)
	e.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	e.ambient_light_color = Color(0.85, 0.7, 0.55)
	e.ambient_light_energy = 0.45
	e.tonemap_mode = Environment.TONE_MAPPER_FILMIC
	e.glow_enabled = true
	e.glow_intensity = 0.4
	e.ssao_enabled = true
	e.ssao_radius = 0.6
	e.ssao_intensity = 1.2
	env.environment = e
	add_child(env)
	var key := DirectionalLight3D.new()
	key.rotation_degrees = Vector3(-30, -25, 0)
	key.light_energy = 1.25
	key.light_color = Color(1.0, 0.88, 0.72)
	key.shadow_enabled = true
	key.shadow_blur = 2.0
	key.shadow_normal_bias = 2.5
	add_child(key)
	var rim := DirectionalLight3D.new()
	rim.rotation_degrees = Vector3(-20, 160, 0)
	rim.light_energy = 0.9
	rim.light_color = Color(1.0, 0.75, 0.45)
	add_child(rim)
	var mode := OS.get_environment("MODE")
	if mode == "":
		mode = "a"
	var ids: Array = []
	match mode:
		"a":
			ids = Character.PRESET_ORDER.slice(0, 6)
		"b":
			ids = Character.PRESET_ORDER.slice(6, 12)
		"close":
			ids = [OS.get_environment("WHO") if OS.get_environment("WHO") != "" else "ted"]
		_:
			ids = ["r", "r", "r", "r", "r", "r"]
	var rng := RandomNumberGenerator.new()
	rng.seed = int(OS.get_environment("SEED")) if OS.get_environment("SEED") != "" else 7
	var emos := ["happy", "laugh", "shock", "love", "fury", "dizzy"]
	var n := ids.size()
	for i in n:
		var c := Character.new()
		add_child(c)
		var lk: Dictionary = Character.preset(ids[i]) if ids[i] != "r" else Character.random_look(rng)
		c.build(lk, "stand")
		c.position = Vector3((float(i) - (n - 1) * 0.5) * 0.85, 0.78 * float(lk.get("height", 1.0)), 0)
		c.rotation.y = PI
		if mode == "emo":
			c.set_emotion(emos[i % emos.size()])
		elif mode == "random":
			c.set_emotion(["neutral", "happy"][i % 2])
		else:
			c.set_emotion("happy" if i % 3 == 0 else "neutral")
		var l := Label3D.new()
		l.text = str(Character.PRESETS[ids[i]]["name"]) if ids[i] != "r" else ""
		l.font = Loc.font("title")
		l.font_size = 64
		l.pixel_size = 0.0025
		l.modulate = Color(1.0, 0.9, 0.75)
		l.position = c.position + Vector3(0, -0.92, 0.2)
		add_child(l)
	var cam := Camera3D.new()
	if mode == "close":
		cam.position = Vector3(0, 1.75, 1.25)
		cam.fov = 40
		cam.rotation_degrees = Vector3(-8, 0, 0)
	else:
		cam.position = Vector3(0, 0.95, 4.4)
		cam.fov = 42
		cam.rotation_degrees = Vector3(-4, 0, 0)
	add_child(cam)
	var fl := MeshInstance3D.new()
	var pm := PlaneMesh.new()
	pm.size = Vector2(30, 30)
	fl.mesh = pm
	fl.material_override = Character.clay(Color(0.33, 0.25, 0.19), 0.5, {"bumps": 0.0})
	add_child(fl)
