"""Genere les pieces des personnages « pate a modeler » (res://models/char/*.obj).

    python3 tools/gen_models.py            # tout
    python3 tools/gen_models.py head hair_  # seulement les noms qui commencent par...

Repere : origine = hanches du personnage debout, Y en haut, visage vers -Z.
Gabarit (metres) :
    tete : centre (0, 0.86, 0) dans le corps, mais les pieces de tete sont
           modelisees autour de (0,0,0) (la tete est un noeud a part), rayon ~0.25
    epaules : pivots (+-0.25, 0.5, 0) ; bras = 0..-0.26 puis avant-bras 0..-0.24
    hanches : pivots (+-0.11, 0, 0) ; cuisse 0..-0.3 ; tibia 0..-0.32 ; sol a -0.72
"""
import os
import sys
import numpy as np
from sdf import *

OUT = os.path.join(os.path.dirname(__file__), "..", "models", "char")
os.makedirs(OUT, exist_ok=True)
PARTS = {}


def part(name, lo, hi, res=0.006, tris=2500):
    def deco(fn):
        PARTS[name] = (fn, lo, hi, res, tris)
        return fn
    return deco


HR = 0.25   # rayon de la tete

# ================================================================== TETE

@part("head", (-0.3, -0.29, -0.28), (0.3, 0.29, 0.28), 0.005, 4000)
def head():
    skull = ellipsoid((HR, HR * 1.02, HR * 0.97))
    cheeks = mirror_x(sphere(0.12, (0.1, -0.08, -0.12)))
    jaw = ellipsoid((0.19, 0.12, 0.16), (0, -0.12, -0.04))
    ears = mirror_x(xform(ellipsoid((0.035, 0.06, 0.045)), (0.245, -0.01, 0.02)))
    return smooth(0.05, skull, cheeks, jaw, ears)


@part("nose", (-0.05, -0.05, -0.05), (0.05, 0.05, 0.05), 0.003, 600)
def nose():
    return smooth(0.01, ellipsoid((0.034, 0.03, 0.03)), ellipsoid((0.028, 0.02, 0.02), (0, -0.012, -0.012)))


@part("eye", (-0.06, -0.06, -0.06), (0.06, 0.06, 0.06), 0.003, 900)
def eye():
    return sphere(0.052)


@part("lid", (-0.065, -0.065, -0.065), (0.065, 0.065, 0.065), 0.003, 900)
def lid():
    # paupiere = demi-coquille du haut (on la fait pivoter pour cligner)
    return inter(shell(sphere(0.056), 0.004), lambda P: -P[:, 1])


@part("brow", (-0.05, -0.02, -0.02), (0.05, 0.02, 0.02), 0.002, 400)
def brow():
    return capsule((-0.035, -0.004, 0), (0.035, 0.004, 0), 0.011)


# ================================================================== CORPS

def torso_shape(w=1.0, belly=0.0, d=1.0):
    chest = ellipsoid((0.235 * w, 0.27, 0.165 * d), (0, 0.33, 0))
    waist = ellipsoid((0.21 * w, 0.2, 0.15 * d), (0, 0.16, 0))
    sh = mirror_x(sphere(0.085, (0.2 * w, 0.5, 0)))
    parts = [chest, waist, sh]
    if belly > 0:
        parts.append(ellipsoid((0.2 * w, 0.2, 0.17 * belly), (0, 0.2, -0.04)))
    body = smooth(0.08, *parts)
    # haut plat pour le col, bas coupe dans le pantalon
    return inter(inter(body, plane_y(0.6)), lambda P: 0.02 - P[:, 1])


@part("torso_reg", (-0.37, -0.02, -0.29), (0.37, 0.62, 0.29), 0.006, 3500)
def torso_reg():
    # style « RV There Yet? » : un peu de bedaine, epaules rondes
    return torso_shape(1.1, belly=0.95, d=1.05)


@part("torso_fat", (-0.4, -0.02, -0.32), (0.4, 0.62, 0.32), 0.006, 3500)
def torso_fat():
    return torso_shape(1.22, belly=1.35, d=1.12)


@part("torso_slim", (-0.3, -0.02, -0.22), (0.3, 0.62, 0.22), 0.006, 3500)
def torso_slim():
    return torso_shape(0.86, d=0.9)


def hips_shape(w=1.0, d=1.0):
    pelvis = ellipsoid((0.215 * w, 0.14, 0.16 * d), (0, 0.03, 0))
    legs = mirror_x(capsule((0.11 * w, 0.0, 0), (0.11 * w, -0.12, 0), 0.115 * w))
    return inter(smooth(0.05, pelvis, legs), lambda P: P[:, 1] - 0.13)


@part("hips_reg", (-0.37, -0.27, -0.29), (0.37, 0.15, 0.29), 0.006, 2000)
def hips_reg():
    return hips_shape(1.1, 1.05)


@part("hips_fat", (-0.4, -0.27, -0.32), (0.4, 0.15, 0.32), 0.006, 2000)
def hips_fat():
    return hips_shape(1.2, 1.15)


@part("hips_slim", (-0.3, -0.27, -0.22), (0.3, 0.15, 0.22), 0.006, 2000)
def hips_slim():
    return hips_shape(0.88, 0.9)


def belt_shape(w=1.0, d=1.0):
    return xform(torus(0.2, 0.024), (0, 0.11, 0), scale=(1.08 * w, 1.0, 0.8 * d))


@part("belt_reg", (-0.34, 0.06, -0.27), (0.34, 0.16, 0.27), 0.004, 1200)
def belt_reg():
    return belt_shape(1.17, 1.22)


@part("belt_fat", (-0.34, 0.06, -0.26), (0.34, 0.16, 0.26), 0.004, 1200)
def belt_fat():
    return belt_shape(1.2, 1.15)


@part("belt_slim", (-0.27, 0.06, -0.19), (0.27, 0.16, 0.19), 0.004, 1200)
def belt_slim():
    return belt_shape(0.88, 0.9)


@part("buckle", (-0.05, -0.04, -0.02), (0.05, 0.04, 0.02), 0.002, 600)
def buckle():
    return sub(rbox((0.04, 0.03, 0.008), 0.006), rbox((0.025, 0.016, 0.02), 0.004))


@part("buckle_eye", (-0.06, -0.04, -0.02), (0.06, 0.04, 0.02), 0.002, 900)
def buckle_eye():
    outer = xform(ellipsoid((0.05, 0.028, 0.01)))
    pupil = sphere(0.016, (0, 0, -0.006))
    return smooth(0.004, outer, pupil)


@part("collar", (-0.18, 0.5, -0.2), (0.18, 0.68, 0.16), 0.004, 2000)
def collar():
    ring = xform(torus(0.1, 0.024), (0, 0.605, 0), scale=(1.0, 1.0, 0.95))

    def flap(sx):
        # pointe de col triangulaire couchee sur la poitrine
        def f(P):
            Q = P - np.array([sx * 0.05, 0.57, -0.13])
            Q = Q @ np.linalg.inv(rot_x(-0.9)).T
            x = Q[:, 0] * sx
            y = Q[:, 1]
            tri = np.maximum(np.maximum(-y - 0.07, y - 0.0), np.abs(x - 0.02 + y * 0.35) - (0.045 + y * 0.55))
            return np.maximum(tri, np.abs(Q[:, 2]) - 0.007) - 0.004
        return f
    return smooth(0.012, ring, flap(1), flap(-1))


@part("neck", (-0.1, 0.5, -0.1), (0.1, 0.72, 0.1), 0.005, 600)
def neck():
    return capsule((0, 0.55, 0), (0, 0.68, 0), 0.08)


@part("tie", (-0.06, 0.12, -0.22), (0.06, 0.62, -0.08), 0.003, 1200)
def tie():
    knot = rbox((0.026, 0.024, 0.016), 0.012, (0, 0.575, -0.16))

    def blade(P):
        # lame qui s'elargit vers le bas, pointe en V
        y = P[:, 1]
        t = np.clip((0.56 - y) / 0.36, 0, 1)
        half = 0.018 + 0.03 * t
        d_side = np.abs(P[:, 0]) - half
        d_top = y - 0.56
        d_tip = (0.2 - y) + np.abs(P[:, 0]) * 0.9
        d_z = np.abs(P[:, 2] + 0.165 + 0.02 * (1 - t)) - 0.007
        return np.maximum(np.maximum(np.maximum(d_side, d_top), d_tip), d_z) - 0.003
    return smooth(0.008, knot, blade)


@part("bowtie", (-0.12, 0.5, -0.22), (0.12, 0.64, -0.1), 0.003, 1200)
def bowtie():
    c = (0, 0.57, -0.16)
    knot = sphere(0.022, c)
    wing = lambda sx: xform(cone(0.012, 0.045, 0.045), (sx * 0.05, 0.57, -0.16), rot_z(-sx * np.pi / 2), (1, 1, 0.6))
    return smooth(0.01, knot, wing(1), wing(-1))


@part("headband_tie", (-0.32, -0.18, -0.32), (0.32, 0.2, 0.36), 0.004, 2000)
def headband_tie():
    band = xform(torus(HR + 0.03, 0.022), (0, 0.14, 0.0), rot_x(-0.22), (1.0, 1.7, 1.0))
    knot = sphere(0.038, (0.0, 0.17, 0.285))
    tail = lambda sx: capsule((sx * 0.01, 0.16, 0.29), (sx * 0.11, -0.06, 0.34), 0.022, 0.034)
    return smooth(0.015, band, knot, tail(1), tail(-1))


def straps(w=1.0, d=1.0):
    def strap(sx):
        return union(
            capsule((sx * 0.1 * w, 0.12, -0.17 * d - 0.012), (sx * 0.12 * w, 0.5, -0.11 * d), 0.017),
            capsule((sx * 0.12 * w, 0.5, -0.11 * d), (sx * 0.12 * w, 0.52, 0.1 * d), 0.017),
            capsule((sx * 0.12 * w, 0.5, 0.1 * d), (sx * 0.04, 0.12, 0.17 * d + 0.012), 0.017))
    return union(strap(1), strap(-1))


@part("suspenders_reg", (-0.3, 0.05, -0.28), (0.3, 0.6, 0.28), 0.004, 2000)
def suspenders_reg():
    return straps(1.1, 1.15)


@part("suspenders_fat", (-0.36, 0.05, -0.34), (0.36, 0.6, 0.34), 0.004, 2000)
def suspenders_fat():
    return straps(1.2, 1.3)


@part("suspenders_slim", (-0.28, 0.05, -0.24), (0.28, 0.6, 0.24), 0.004, 2000)
def suspenders_slim():
    return straps(0.88, 0.9)


@part("badge", (-0.06, -0.08, -0.03), (0.06, 0.06, 0.03), 0.002, 900)
def badge():
    card = rbox((0.032, 0.045, 0.004), 0.004, (0, -0.03, 0))
    clip = rbox((0.012, 0.012, 0.006), 0.003, (0, 0.022, 0))
    return union(card, clip)


@part("lanyard", (-0.16, 0.25, -0.22), (0.16, 0.66, 0.16), 0.004, 1200)
def lanyard():
    # V du cordon autour du cou jusqu'au badge
    a = capsule((0.08, 0.6, -0.08), (0.0, 0.35, -0.185), 0.006)
    b = capsule((-0.08, 0.6, -0.08), (0.0, 0.35, -0.185), 0.006)
    c = xform(torus(0.095, 0.006), (0, 0.62, 0.0), rot_x(0.35))
    return union(a, b, inter(c, lambda Q: Q[:, 2] - 0.05))


@part("pocket_pens", (-0.05, -0.06, -0.03), (0.05, 0.08, 0.03), 0.002, 1200)
def pocket_pens():
    pocket = rbox((0.04, 0.04, 0.008), 0.006, (0, -0.02, 0))
    pens = union(*[capsule((x, -0.01, 0.002), (x + 0.004, 0.06, 0.002), 0.006) for x in (-0.018, 0.0, 0.018)])
    return union(pocket, pens)


@part("pin_star", (-0.04, -0.04, -0.02), (0.04, 0.04, 0.02), 0.002, 800)
def pin_star():
    def f(P):
        a = np.arctan2(P[:, 1], P[:, 0])
        r = np.linalg.norm(P[:, :2], axis=1)
        k = 0.02 + 0.012 * np.cos(5 * a)
        return np.maximum(r - k, np.abs(P[:, 2]) - 0.006) - 0.002
    return f


@part("pin_flower", (-0.04, -0.04, -0.02), (0.04, 0.04, 0.02), 0.002, 900)
def pin_flower():
    pet = union(*[sphere(0.012, (0.018 * np.cos(a), 0.018 * np.sin(a), 0)) for a in np.linspace(0, 6.28, 6, endpoint=False)])
    return xform(smooth(0.004, pet, sphere(0.012)), scale=(1, 1, 0.5))


@part("pin_butterfly", (-0.04, -0.04, -0.02), (0.04, 0.04, 0.02), 0.002, 900)
def pin_butterfly():
    w = mirror_x(union(xform(ellipsoid((0.016, 0.012, 0.004)), (0.016, 0.008, 0), rot_z(0.4)),
                       xform(ellipsoid((0.012, 0.009, 0.004)), (0.013, -0.01, 0), rot_z(-0.4))))
    return union(w, capsule((0, -0.016, 0), (0, 0.016, 0), 0.004))


# ================================================================== BRAS ET JAMBES

@part("arm_up", (-0.1, -0.3, -0.1), (0.1, 0.06, 0.1), 0.004, 1200)
def arm_up():
    return capsule((0, 0.0, 0), (0, -0.26, 0), 0.07, 0.064)


@part("arm_lo", (-0.1, -0.27, -0.1), (0.1, 0.05, 0.1), 0.004, 1200)
def arm_lo():
    return capsule((0, 0.0, 0), (0, -0.2, 0), 0.062, 0.058)


@part("cuff", (-0.08, -0.25, -0.08), (0.08, -0.15, 0.08), 0.003, 900)
def cuff():
    return cyl(0.066, 0.025, (0, -0.2, 0), 0.01)


@part("hand", (-0.11, -0.4, -0.11), (0.11, -0.16, 0.11), 0.003, 2200)
def hand():
    # moufle de pate a modeler avec un pouce (main droite ; la gauche = miroir)
    wrist = capsule((0, -0.2, 0), (0, -0.24, 0), 0.045)
    palm = ellipsoid((0.06, 0.07, 0.04), (0, -0.29, 0))
    fingers = ellipsoid((0.055, 0.045, 0.036), (0, -0.335, -0.005))
    thumb = capsule((-0.045, -0.27, -0.03), (-0.065, -0.31, -0.05), 0.019)
    return smooth(0.02, wrist, palm, fingers, thumb)


@part("thigh", (-0.14, -0.34, -0.14), (0.14, 0.06, 0.14), 0.005, 1200)
def thigh():
    return capsule((0, 0.0, 0), (0, -0.31, 0), 0.105, 0.097)


@part("shin", (-0.13, -0.36, -0.13), (0.13, 0.05, 0.13), 0.005, 1200)
def shin():
    return capsule((0, 0.02, 0), (0, -0.31, 0), 0.084, 0.086)


@part("shin_skin", (-0.1, -0.36, -0.1), (0.1, 0.05, 0.1), 0.004, 900)
def shin_skin():
    return capsule((0, 0.0, 0), (0, -0.31, 0), 0.06, 0.055)


@part("pant_cuff", (-0.13, -0.36, -0.13), (0.13, -0.24, 0.13), 0.004, 900)
def pant_cuff():
    return cyl(0.1, 0.035, (0, -0.29, 0), 0.015)


@part("short_hem", (-0.13, -0.1, -0.13), (0.13, 0.05, 0.13), 0.004, 900)
def short_hem():
    # bas d'un short (au-dessus du genou)
    return cyl(0.112, 0.04, (0, -0.03, 0), 0.02)


@part("sock", (-0.08, -0.36, -0.08), (0.08, -0.16, 0.08), 0.003, 900)
def sock():
    return cyl(0.064, 0.085, (0, -0.26, 0), 0.02)


# ---------------------------------------------------------- chaussures (pied = bas du tibia)

FOOT_Y = -0.31     # bas du tibia (cheville)


@part("shoe_oxford", (-0.11, -0.46, -0.24), (0.11, -0.25, 0.12), 0.004, 2500)
def shoe_oxford():
    body = smooth(0.05, ellipsoid((0.092, 0.07, 0.16), (0, -0.37, -0.06)), sphere(0.08, (0, -0.35, 0.03)))
    return inter(body, lambda P: -0.43 - P[:, 1])


@part("shoe_sneaker", (-0.11, -0.46, -0.25), (0.11, -0.24, 0.12), 0.004, 2500)
def shoe_sneaker():
    body = smooth(0.05, ellipsoid((0.09, 0.07, 0.16), (0, -0.36, -0.05)), sphere(0.08, (0, -0.33, 0.02)))
    return inter(body, lambda P: -0.41 - P[:, 1])


@part("sneaker_sole", (-0.11, -0.46, -0.25), (0.11, -0.36, 0.12), 0.004, 1500)
def sneaker_sole():
    return inter(xform(ellipsoid((0.092, 0.03, 0.163)), (0, -0.418, -0.05)), lambda P: -0.432 - P[:, 1])


@part("sandal", (-0.11, -0.46, -0.24), (0.11, -0.28, 0.12), 0.003, 2500)
def sandal():
    sole = rbox((0.08, 0.014, 0.15), 0.012, (0, -0.425, -0.05))
    above = lambda P: -(P[:, 1] + 0.415)
    strap1 = inter(shell(ellipsoid((0.07, 0.045, 0.035), (0, -0.4, -0.11)), 0.006), above)
    strap2 = inter(shell(ellipsoid((0.066, 0.05, 0.035), (0, -0.39, 0.0)), 0.006), above)
    return union(sole, strap1, strap2)


@part("foot_bare", (-0.1, -0.46, -0.24), (0.1, -0.28, 0.12), 0.004, 1500)
def foot_bare():
    return smooth(0.03, ellipsoid((0.062, 0.045, 0.13), (0, -0.385, -0.05)), sphere(0.055, (0, -0.36, 0.02)))


@part("croc", (-0.12, -0.46, -0.26), (0.12, -0.24, 0.13), 0.004, 2500)
def croc():
    body = smooth(0.05, ellipsoid((0.095, 0.075, 0.17), (0, -0.36, -0.05)), sphere(0.085, (0, -0.33, 0.02)))
    body = inter(body, lambda P: -0.415 - P[:, 1])
    holes = union(*[sphere(0.012, (x, -0.31, z)) for x in (-0.035, 0.0, 0.035) for z in (-0.13, -0.09)])
    return sub(body, holes)


@part("boot", (-0.12, -0.46, -0.24), (0.12, -0.12, 0.13), 0.004, 2500)
def boot():
    foot = smooth(0.05, ellipsoid((0.09, 0.07, 0.15), (0, -0.37, -0.05)), cyl(0.085, 0.09, (0, -0.25, 0.0), 0.03))
    return inter(foot, lambda P: -0.43 - P[:, 1])


@part("slipper_bunny", (-0.13, -0.46, -0.27), (0.13, -0.16, 0.14), 0.004, 3000)
def slipper_bunny():
    body = smooth(0.06, ellipsoid((0.1, 0.08, 0.17), (0, -0.36, -0.05)), sphere(0.09, (0, -0.33, 0.03)))
    body = inter(body, lambda P: -0.43 - P[:, 1])
    ears = mirror_x(capsule((0.035, -0.31, -0.12), (0.05, -0.2, -0.1), 0.022, 0.026))
    head = sphere(0.06, (0, -0.32, -0.15))
    return smooth(0.02, body, ears, head)


# ================================================================== CHEVEUX (autour de la tete, centre 0)

def scalp(cover=0.0, thick=0.03, back=0.0):
    """Calotte qui epouse le crane ; cover = hauteur de la frange (plus bas = plus couvert)."""
    cap = ellipsoid((HR + thick, HR * 1.02 + thick, HR * 0.97 + thick))
    front_cut = lambda P: (cover - P[:, 1]) * 1.0 - np.maximum(P[:, 2], 0) * 1.6 + back
    return inter(cap, lambda P: front_cut(P))


@part("hair_curly", (-0.36, -0.12, -0.36), (0.36, 0.38, 0.36), 0.005, 5000)
def hair_curly():
    # tignasse frisee (Ted) : beaucoup de boucles fondues
    rng = np.random.default_rng(3)
    curls = []
    for _ in range(46):
        th = rng.uniform(0, 2 * np.pi)
        ph = rng.uniform(0.0, 1.25)
        r = HR + 0.025
        p = (np.sin(ph) * np.cos(th) * r * 1.05, np.cos(ph) * r + 0.02, np.sin(ph) * np.sin(th) * r)
        if p[2] < -0.12 and p[1] < 0.14:
            continue
        curls.append(sphere(rng.uniform(0.055, 0.075), p))
    base = scalp(0.08, 0.035)
    return displace(smooth(0.035, base, *curls), 0.003, 45, 1)


@part("hair_bun", (-0.33, -0.15, -0.33), (0.33, 0.52, 0.33), 0.005, 5000)
def hair_bun():
    # chignon tresse (Nova)
    base = scalp(0.17, 0.022)
    bun = displace(sphere(0.11, (0, 0.33, 0.04)), 0.008, 70, 2)
    braids = union(*[capsule((0.0 + np.cos(a) * 0.05, 0.3, 0.04 + np.sin(a) * 0.05), (np.cos(a) * 0.17, 0.12, np.sin(a) * 0.17 + 0.02), 0.022)
                     for a in np.linspace(0, 6.28, 9, endpoint=False)])
    return smooth(0.02, base, bun, braids)


@part("hair_sidepart", (-0.32, -0.16, -0.32), (0.32, 0.32, 0.32), 0.004, 4000)
def hair_sidepart():
    # couronne degarnie + raie (Benoit)
    ring = inter(scalp(0.04, 0.022), lambda P: -(P[:, 1] - 0.14) - np.maximum(-P[:, 2], 0) * 0.0)
    top_strands = union(*[capsule((-0.12 + i * 0.05, 0.22, -0.02 - i * 0.01), (-0.02 + i * 0.05, 0.26 - i * 0.01, 0.12), 0.012) for i in range(4)])
    back = inter(ellipsoid((HR + 0.022, HR * 1.02 + 0.022, HR * 0.97 + 0.022)), lambda P: P[:, 1] - 0.16)
    back = inter(back, lambda P: -P[:, 2] - 0.02)
    return smooth(0.015, ring, back, top_strands)


@part("hair_mohawk", (-0.32, -0.1, -0.32), (0.32, 0.4, 0.32), 0.004, 3000)
def hair_mohawk():
    # petite crete (Ziggy), le reste rase
    fuzz = scalp(0.06, 0.006)
    return smooth(0.02, fuzz, xform(ellipsoid((0.035, 0.09, 0.16)), (0, 0.26, 0.01)))


@part("hair_bob", (-0.34, -0.2, -0.34), (0.34, 0.34, 0.34), 0.005, 4000)
def hair_bob():
    # carre blond (Angel) avec frange
    cap = ellipsoid((HR + 0.04, HR * 1.02 + 0.035, HR * 0.97 + 0.04), (0, 0.01, 0.01))
    face_hole = ellipsoid((0.2, 0.2, 0.3), (0, -0.07, -0.2))
    bottom = lambda P: -0.1 - P[:, 1]
    fringe = xform(ellipsoid((0.2, 0.06, 0.08)), (0, 0.16, -0.19), rot_x(0.4))
    return displace(smooth(0.03, inter(sub(cap, face_hole, 0.02), bottom), fringe), 0.004, 50, 4)


@part("hair_bowl", (-0.33, -0.12, -0.33), (0.33, 0.34, 0.33), 0.004, 4000)
def hair_bowl():
    # coupe au bol noire (Marc, Gus)
    cap = ellipsoid((HR + 0.035, HR * 1.02 + 0.03, HR * 0.97 + 0.035), (0, 0.015, 0.005))
    cut = lambda P: (0.15 - P[:, 1]) - np.maximum(P[:, 2] + 0.05, 0) * 0.9
    spikes = union(*[capsule((x, 0.2, -0.19), (x * 1.05, 0.14, -0.235), 0.024) for x in (-0.12, -0.04, 0.04, 0.12)])
    return smooth(0.025, inter(cap, cut), spikes)


@part("hair_puff", (-0.34, -0.12, -0.34), (0.34, 0.6, 0.34), 0.005, 5000)
def hair_puff():
    # grosse touffe sur le dessus (Ray)
    base = scalp(0.16, 0.015)
    puff = displace(smooth(0.04, sphere(0.15, (0, 0.33, 0.05)), sphere(0.11, (0.1, 0.38, 0.0)), sphere(0.1, (-0.09, 0.4, 0.07))), 0.012, 45, 5)
    return smooth(0.03, base, puff)


@part("hair_long", (-0.35, -0.6, -0.34), (0.35, 0.34, 0.36), 0.005, 5000)
def hair_long():
    # longs cheveux lisses (Sophie)
    cap = ellipsoid((HR + 0.03, HR * 1.02 + 0.03, HR * 0.97 + 0.03), (0, 0.01, 0.01))
    face = ellipsoid((0.2, 0.24, 0.3), (0, -0.06, -0.22))
    fall = smooth(0.06, capsule((0, 0.0, 0.1), (0, -0.48, 0.12), 0.2), mirror_x(capsule((0.2, 0.0, -0.02), (0.2, -0.45, 0.02), 0.06)))
    fall = xform(fall, scale=(1.15, 1, 0.75))
    return sub(smooth(0.05, cap, fall), face, 0.03)


@part("hair_buns2", (-0.4, -0.12, -0.34), (0.4, 0.5, 0.34), 0.005, 5000)
def hair_buns2():
    # deux chignons (Lea)
    base = scalp(0.16, 0.025)
    buns = mirror_x(displace(sphere(0.095, (0.16, 0.27, 0.03)), 0.008, 70, 6))
    return smooth(0.03, base, buns)


@part("hair_messy", (-0.36, -0.14, -0.36), (0.36, 0.38, 0.36), 0.005, 5000)
def hair_messy():
    # bouclettes en bataille (Sam, Diego)
    rng = np.random.default_rng(9)
    curls = []
    for _ in range(60):
        th = rng.uniform(0, 2 * np.pi)
        ph = rng.uniform(0.0, 1.45)
        r = HR + 0.012
        p = (np.sin(ph) * np.cos(th) * r, np.cos(ph) * r, np.sin(ph) * np.sin(th) * r)
        if p[2] < -0.1 and p[1] < 0.2:
            continue
        curls.append(sphere(rng.uniform(0.035, 0.05), p))
    return smooth(0.015, scalp(0.15, 0.02), *curls)


@part("hair_afro", (-0.4, -0.12, -0.4), (0.4, 0.5, 0.4), 0.006, 5000)
def hair_afro():
    blob = ellipsoid((0.34, 0.3, 0.32), (0, 0.13, 0.04))
    blob = sub(blob, ellipsoid((0.22, 0.25, 0.3), (0, -0.08, -0.2)), 0.04)
    return displace(blob, 0.012, 40, 7)


@part("hair_short", (-0.33, -0.12, -0.33), (0.33, 0.33, 0.33), 0.004, 3500)
def hair_short():
    base = scalp(0.15, 0.03)
    tuft = xform(ellipsoid((0.12, 0.04, 0.08)), (0.05, 0.24, -0.15), rot_x(0.6) @ rot_z(-0.2))
    return smooth(0.03, base, tuft)


# ================================================================== VISAGE

@part("mustache_walrus", (-0.14, -0.06, -0.06), (0.14, 0.05, 0.06), 0.003, 1500)
def mustache_walrus():
    return mirror_x(smooth(0.02, ellipsoid((0.05, 0.03, 0.03), (0.035, 0.0, 0.0)), xform(ellipsoid((0.04, 0.022, 0.025)), (0.085, -0.02, 0.01), rot_z(0.6))))


@part("mustache_thin", (-0.1, -0.04, -0.04), (0.1, 0.04, 0.04), 0.002, 900)
def mustache_thin():
    return mirror_x(capsule((0.008, 0.0, 0), (0.06, -0.012, 0.008), 0.011, 0.007))


@part("mustache_curly", (-0.14, -0.06, -0.05), (0.14, 0.06, 0.05), 0.002, 1500)
def mustache_curly():
    curl = xform(torus(0.022, 0.008), (0.09, 0.01, 0.0), rot_x(np.pi / 2))
    return mirror_x(smooth(0.01, capsule((0.008, 0.0, 0), (0.07, -0.004, 0.005), 0.016, 0.01), curl))


@part("beard", (-0.28, -0.32, -0.3), (0.28, 0.05, 0.3), 0.005, 3000)
def beard():
    b = ellipsoid((0.22, 0.17, 0.2), (0, -0.14, -0.04))
    mouth = ellipsoid((0.06, 0.03, 0.08), (0, -0.085, -0.22))
    return displace(sub(inter(b, lambda P: P[:, 1] + 0.02), mouth, 0.02), 0.005, 60, 8)


@part("teeth", (-0.04, -0.04, -0.02), (0.04, 0.02, 0.02), 0.002, 500)
def teeth():
    return mirror_x(rbox((0.014, 0.018, 0.006), 0.005, (0.016, -0.012, 0)))


# ================================================================== LUNETTES (centrees sur les yeux, z = face)

EY = 0.035       # hauteur des yeux
EX = 0.085       # ecart des yeux
EZ = -0.235      # devant du visage


def frames(rim, bridge_r=0.008):
    br = capsule((-0.04, EY + 0.01, EZ - 0.02), (0.04, EY + 0.01, EZ - 0.02), bridge_r)
    arms = mirror_x(capsule((0.15, EY + 0.01, EZ + 0.02), (0.25, EY + 0.02, 0.05), 0.008))
    return union(rim, br, arms)


def ring_xy(R, r, c, sx=1.0, sy=1.0):
    return xform(torus(R, r), c, rot_x(np.pi / 2), (sx, 1.0, sy))


@part("glasses_round", (-0.3, -0.06, -0.3), (0.3, 0.12, 0.1), 0.002, 3000)
def glasses_round():
    return frames(mirror_x(ring_xy(0.062, 0.009, (EX, EY, EZ - 0.02))))


@part("glasses_square", (-0.3, -0.06, -0.3), (0.3, 0.12, 0.1), 0.002, 3000)
def glasses_square():
    def rim(P):
        Q = P - np.array([EX, EY, EZ - 0.02])
        outer = rbox((0.068, 0.05, 0.012), 0.012)(Q)
        inner = rbox((0.056, 0.038, 0.03), 0.006)(Q)
        return np.maximum(outer, -inner)
    return frames(mirror_x(rim), 0.01)


@part("glasses_heart", (-0.3, -0.08, -0.3), (0.3, 0.12, 0.1), 0.002, 3000)
def glasses_heart():
    def heart(P):
        Q = P - np.array([EX, EY, EZ - 0.02])
        x, y = np.abs(Q[:, 0]) / 0.07, Q[:, 1] / 0.07 + 0.25
        a = np.arctan2(x, y) / np.pi
        r = np.sqrt(x * x + y * y)
        h = np.abs(a)
        d = (13 * h - 22 * h * h + 10 * h ** 3) / (6 - 5 * h)
        d2 = (r - d * 0.62) * 0.07
        return np.maximum(d2, np.abs(Q[:, 2]) - 0.01) - 0.002
    return frames(mirror_x(heart))


@part("glasses_star", (-0.32, -0.1, -0.3), (0.32, 0.14, 0.1), 0.002, 3000)
def glasses_star():
    def star(P):
        Q = P - np.array([EX, EY, EZ - 0.02])
        a = np.arctan2(Q[:, 1], Q[:, 0]) - np.pi / 2
        r = np.linalg.norm(Q[:, :2], axis=1)
        k = 0.055 + 0.025 * np.cos(5 * a)
        return np.maximum(r - k, np.abs(Q[:, 2]) - 0.01) - 0.002
    return frames(mirror_x(star))


@part("glasses_3d", (-0.3, -0.06, -0.3), (0.3, 0.12, 0.1), 0.002, 2000)
def glasses_3d():
    def rim(P):
        Q = P - np.array([0, EY, EZ - 0.02])
        outer = rbox((0.165, 0.05, 0.008), 0.01)(Q)
        holes = mirror_x(rbox((0.06, 0.035, 0.03), 0.006, (EX, 0, 0)))(Q)
        return np.maximum(outer, -holes)
    return frames(rim)


@part("lens_round", (-0.08, -0.08, -0.02), (0.08, 0.08, 0.02), 0.002, 500)
def lens_round():
    return xform(cyl(0.058, 0.002, round_=0.001), rot=rot_x(np.pi / 2))


# ================================================================== CHAPEAUX (sur la tete)

@part("halo", (-0.2, -0.04, -0.2), (0.2, 0.04, 0.2), 0.003, 1500)
def halo():
    return torus(0.15, 0.018)


@part("crown", (-0.18, -0.02, -0.18), (0.18, 0.2, 0.18), 0.003, 3000)
def crown():
    band = shell(cyl(0.15, 0.04, (0, 0.04, 0)), 0.008)
    spikes = union(*[cone(0.03, 0.002, 0.05, (0.15 * np.cos(a), 0.12, 0.15 * np.sin(a))) for a in np.linspace(0, 6.28, 6, endpoint=False)])
    balls = union(*[sphere(0.014, (0.15 * np.cos(a), 0.175, 0.15 * np.sin(a))) for a in np.linspace(0, 6.28, 6, endpoint=False)])
    return union(inter(band, lambda P: P[:, 1] - 0.08), spikes, balls)


@part("cap", (-0.3, -0.05, -0.42), (0.3, 0.24, 0.3), 0.004, 3000)
def cap():
    dome = inter(ellipsoid((HR + 0.03, 0.19, HR + 0.03), (0, 0.0, 0)), lambda P: -P[:, 1] + 0.0)
    brim = xform(ellipsoid((0.16, 0.012, 0.13)), (0, 0.0, -0.28), rot_x(-0.12))
    button = sphere(0.02, (0, 0.19, 0))
    return union(dome, brim, button)


@part("tophat", (-0.3, -0.02, -0.3), (0.3, 0.4, 0.3), 0.004, 3000)
def tophat():
    return union(cyl(0.16, 0.16, (0, 0.18, 0), 0.01), xform(cyl(0.26, 0.008, round_=0.006), (0, 0.02, 0)))


@part("tinfoil", (-0.28, -0.02, -0.28), (0.28, 0.5, 0.28), 0.004, 3000)
def tinfoil():
    return displace(cone(0.25, 0.01, 0.2, (0, 0.2, 0)), 0.008, 35, 11)


@part("beanie", (-0.3, -0.06, -0.3), (0.3, 0.32, 0.3), 0.004, 3000)
def beanie():
    dome = inter(ellipsoid((HR + 0.035, 0.26, HR + 0.035)), lambda P: -P[:, 1] - 0.0)
    fold = cyl(HR + 0.045, 0.035, (0, 0.03, 0), 0.02)
    ribs = lambda P: dome(P) + 0.004 * np.sin(np.arctan2(P[:, 2], P[:, 0]) * 30)
    return union(ribs, fold)


@part("propeller_cap", (-0.32, -0.04, -0.32), (0.32, 0.36, 0.32), 0.004, 3000)
def propeller_cap():
    dome = inter(ellipsoid((HR + 0.03, 0.19, HR + 0.03)), lambda P: -P[:, 1])
    stick = capsule((0, 0.18, 0), (0, 0.26, 0), 0.01)
    return union(dome, stick)


@part("propeller", (-0.2, -0.03, -0.06), (0.2, 0.03, 0.06), 0.002, 1500)
def propeller():
    return mirror_x(xform(ellipsoid((0.09, 0.006, 0.03)), (0.09, 0, 0), rot_x(0.3)))


@part("antenna", (-0.32, -0.1, -0.1), (0.32, 0.36, 0.1), 0.003, 2500)
def antenna():
    band = inter(xform(torus(HR + 0.02, 0.012), rot=rot_z(np.pi / 2)), lambda P: -P[:, 1] - 0.02)
    sticks = mirror_x(capsule((0.1, 0.22, 0), (0.15, 0.32, 0), 0.008))
    balls = mirror_x(sphere(0.03, (0.15, 0.33, 0)))
    return union(band, sticks, balls)


@part("star_band", (-0.32, -0.1, -0.1), (0.32, 0.42, 0.1), 0.003, 2500)
def star_band():
    band = inter(xform(torus(HR + 0.02, 0.012), rot=rot_z(np.pi / 2)), lambda P: -P[:, 1] - 0.02)
    sticks = mirror_x(capsule((0.1, 0.22, 0), (0.15, 0.33, 0), 0.007))

    def star(c):
        def f(P):
            Q = P - np.array(c)
            a = np.arctan2(Q[:, 1], Q[:, 0]) - np.pi / 2
            r = np.linalg.norm(Q[:, :2], axis=1)
            return np.maximum(r - (0.035 + 0.016 * np.cos(5 * a)), np.abs(Q[:, 2]) - 0.01) - 0.004
        return f
    return union(band, sticks, mirror_x(star((0.15, 0.36, 0))))


@part("horns", (-0.32, -0.1, -0.1), (0.32, 0.38, 0.1), 0.003, 2500)
def horns():
    band = inter(xform(torus(HR + 0.02, 0.012), rot=rot_z(np.pi / 2)), lambda P: -P[:, 1] - 0.02)
    horn = mirror_x(capsule((0.11, 0.22, 0), (0.16, 0.34, 0), 0.04, 0.004))
    return smooth(0.01, band, horn)


@part("headset", (-0.33, -0.25, -0.3), (0.33, 0.32, 0.12), 0.003, 3500)
def headset():
    band = inter(xform(torus(HR + 0.03, 0.014), rot=rot_z(np.pi / 2)), lambda P: -P[:, 1] + 0.02)
    cups = mirror_x(xform(cyl(0.06, 0.025, round_=0.012), (0.27, 0.0, 0.0), rot_z(np.pi / 2)))
    mic = capsule((-0.27, -0.03, -0.02), (-0.12, -0.13, -0.22), 0.009)
    mic_head = sphere(0.022, (-0.11, -0.135, -0.23))
    return union(band, cups, mic, mic_head)


@part("earring", (-0.03, -0.04, -0.03), (0.03, 0.02, 0.03), 0.002, 600)
def earring():
    return xform(torus(0.016, 0.004), (0, -0.016, 0), rot_z(np.pi / 2))


# ================================================================== DOS ET MAINS

@part("wings", (-0.6, -0.1, 0.0), (0.6, 0.75, 0.35), 0.006, 4000)
def wings():
    def wing(sx):
        feathers = [xform(ellipsoid((0.17 - i * 0.02, 0.045, 0.03)), (sx * (0.18 + i * 0.07), 0.48 - i * 0.07, 0.24), rot_z(sx * (0.5 + i * 0.25))) for i in range(5)]
        return smooth(0.03, xform(ellipsoid((0.16, 0.18, 0.05)), (sx * 0.2, 0.42, 0.22), rot_z(sx * 0.4)), *feathers)
    return union(wing(1), wing(-1))


@part("mug", (-0.08, -0.08, -0.08), (0.12, 0.1, 0.08), 0.003, 2000)
def mug():
    body = sub(cyl(0.055, 0.065, round_=0.008), cyl(0.045, 0.065, (0, 0.012, 0)))
    handle = xform(torus(0.035, 0.011), (0.065, 0.0, 0), rot_x(np.pi / 2))
    return union(body, inter(handle, lambda P: 0.055 - P[:, 0]))


@part("book", (-0.1, -0.13, -0.03), (0.1, 0.13, 0.03), 0.003, 1200)
def book():
    return union(rbox((0.08, 0.11, 0.02), 0.006), rbox((0.074, 0.105, 0.024), 0.003, (0.004, 0, 0)))


@part("skirt", (-0.3, -0.32, -0.28), (0.3, 0.14, 0.28), 0.005, 2500)
def skirt():
    s = cone(0.29, 0.21, 0.19, (0, -0.07, 0))
    pleats = lambda P: s(P) + 0.008 * np.sin(np.arctan2(P[:, 2], P[:, 0]) * 14)
    return xform(pleats, scale=(1.0, 1.0, 0.82))


@part("hoodie_hood", (-0.3, 0.35, 0.0), (0.3, 0.75, 0.32), 0.005, 2500)
def hoodie_hood():
    hood = sub(ellipsoid((0.22, 0.16, 0.14), (0, 0.58, 0.16)), ellipsoid((0.17, 0.14, 0.12), (0, 0.62, 0.12)), 0.02)
    return inter(hood, lambda P: -P[:, 2] + 0.06)


# ================================================================== MAINS 1re PERSONNE

@part("fp_hand", (-0.09, -0.06, -0.22), (0.1, 0.06, 0.12), 0.003, 5000)
def fp_hand():
    # grosse main de figurine (main DROITE, paume vers le bas, doigts vers -Z)
    palm = ellipsoid((0.058, 0.026, 0.06), (0, 0, -0.01))
    wrist = capsule((0, 0.0, 0.03), (0, 0.004, 0.11), 0.042, 0.038)
    fingers = []
    for i, (x, ln) in enumerate([(-0.036, 0.062), (-0.012, 0.072), (0.013, 0.07), (0.037, 0.058)]):
        fingers.append(capsule((x * 1.1, 0.0, -0.05), (x * 1.45, -0.006, -0.05 - ln), 0.02, 0.019))
    thumb = capsule((-0.05, -0.004, 0.0), (-0.085, -0.008, -0.05), 0.019)
    return smooth(0.012, palm, wrist, thumb, *fingers)


@part("fp_sleeve", (-0.07, -0.07, 0.06), (0.07, 0.07, 0.4), 0.004, 1500)
def fp_sleeve():
    return capsule((0, 0, 0.1), (0, 0, 0.36), 0.05, 0.056)


# ================================================================== GENERATION

def main():
    only = sys.argv[1:]
    for name, (fn, lo, hi, res, tris) in PARTS.items():
        if only and not any(name.startswith(o) for o in only):
            continue
        try:
            v, n, f = mesh(fn(), lo, hi, res, tris)
        except Exception as e:
            print("ECHEC", name, e)
            continue
        write_obj(os.path.join(OUT, name + ".obj"), v, n, f)
        print("%-18s %6d triangles" % (name, len(f)))


if __name__ == "__main__":
    main()
