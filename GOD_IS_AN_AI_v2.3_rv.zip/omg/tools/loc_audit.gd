extends SceneTree
# godot --headless --script res://tools/loc_audit.gd
func _init() -> void:
	var L = load("res://autoload/loc.gd").new()
	var fr: Dictionary = L.STR["fr"]
	var en: Dictionary = L.STR["en"]
	var bad := 0
	for k in fr:
		if not en.has(k):
			print("MANQUE EN : ", k); bad += 1
	for k in en:
		if not fr.has(k):
			print("MANQUE FR : ", k); bad += 1
	var re := RegEx.new()
	re.compile("%[sd%]|%\\.?\\d*[sdf]")
	for k in fr:
		if en.has(k) and typeof(fr[k]) == TYPE_STRING and typeof(en[k]) == TYPE_STRING:
			var a := re.search_all(fr[k]).size()
			var b := re.search_all(en[k]).size()
			if a != b:
				print("PLACEHOLDERS ", k, " fr=", a, " en=", b); bad += 1
		elif en.has(k) and typeof(fr[k]) != typeof(en[k]):
			print("TYPE ", k); bad += 1
		elif en.has(k) and typeof(fr[k]) == TYPE_ARRAY and (fr[k] as Array).size() != (en[k] as Array).size():
			print("TAILLE LISTE ", k, " fr=", (fr[k] as Array).size(), " en=", (en[k] as Array).size())
	# cles utilisees dans le code
	var used := {}
	var rk := RegEx.new()
	rk.compile("Loc\\.(?:t|f|list)\\(\"([a-zA-Z0-9_]+)\"")
	for f in _files("res://"):
		var src := FileAccess.get_file_as_string(f)
		for m in rk.search_all(src):
			used[m.get_string(1)] = f
	for k in used:
		if not fr.has(k):
			print("CLE INCONNUE : ", k, " (", used[k], ")"); bad += 1
	print("LOC AUDIT : ", fr.size(), " cles, ", used.size(), " utilisees, ", bad, " problemes")
	L.free()
	quit()

func _files(dir: String) -> Array:
	var out := []
	var d := DirAccess.open(dir)
	if d == null:
		return out
	for f in d.get_files():
		if f.ends_with(".gd"):
			out.append(dir.path_join(f))
	for s in d.get_directories():
		if not s.begins_with("."):
			out.append_array(_files(dir.path_join(s)))
	return out
