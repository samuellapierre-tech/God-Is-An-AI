"""Faux serveur de chat Twitch pour tester « le chat joue Dieu » sans Internet.
   python3 tools/mock_twitch.py   puis lancer le jeu avec  -- --twitch=test --twitch-url=ws://127.0.0.1:8765
"""
import asyncio, random, websockets

LINES = [
    ("Patate_Volante", "!prier j'ai mangé le lunch de mon coloc et j'ai accusé le chien"),
    ("xXDarkSasukeXx", "!prier jai dit je t'aime à mon prof de math devant toute la classe"),
    ("MamieGinette", "!pray I microwaved fish in the office on purpose"),
    ("Ti_Guy_42", "!signe"), ("lulu", "!colere"), ("bob", "!colere"), ("zoe", "!joie"),
    ("a", "!amen"), ("b", "!amen"), ("c", "!amen"), ("d", "!amen"),
    ("spammer", "!prier visitez www.spam.com"),
    ("KevinDu450", "LOL le gars parle à Dieu"),
]

async def handler(ws):
    joined = False
    async def reader():
        nonlocal joined
        async for m in ws:
            print("<<", m.strip())
            if m.startswith("JOIN"):
                joined = True
    task = asyncio.create_task(reader())
    while not joined:
        await asyncio.sleep(0.1)
    await ws.send(":tmi.twitch.tv 001 justinfan :Welcome\r\n")
    await ws.send("PING :tmi.twitch.tv\r\n")
    i = 0
    while True:
        u, msg = LINES[i % len(LINES)]
        col = "#%06X" % random.randint(0, 0xFFFFFF)
        await ws.send(f"@badge-info=;color={col};display-name={u};mod=0 :{u.lower()}!{u.lower()}@{u.lower()}.tmi.twitch.tv PRIVMSG #test :{msg}\r\n")
        i += 1
        await asyncio.sleep(0.4)

async def main():
    async with websockets.serve(handler, "127.0.0.1", 8765):
        print("mock twitch sur ws://127.0.0.1:8765")
        await asyncio.Future()

asyncio.run(main())
