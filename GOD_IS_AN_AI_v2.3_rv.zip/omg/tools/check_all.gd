extends Node
## godot --headless res://tools/check_all.tscn : compile tous les scripts.

func _ready() -> void:
	var bad := 0
	for p in _scan("res://"):
		var s = load(p)
		if s == null:
			bad += 1
			print("ECHEC ", p)
	print("CHECK DONE, echecs = ", bad)
	get_tree().quit()


func _scan(dir: String) -> Array:
	var out := []
	var d := DirAccess.open(dir)
	if d == null:
		return out
	for f in d.get_files():
		if f.ends_with(".gd") or f.ends_with(".gdshader"):
			out.append(dir.path_join(f))
	for sub in d.get_directories():
		if not sub.begins_with("."):
			out += _scan(dir.path_join(sub))
	return out
