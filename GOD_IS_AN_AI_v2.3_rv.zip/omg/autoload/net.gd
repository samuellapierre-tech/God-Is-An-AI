extends Node
## Co-op en ligne (ENet) : heberger / rejoindre, lobby, depart de partie.
## L'hote fait autorite sur la journee (horloge, quota, Dieu, boutique).
## Chaque joueur traite ses propres prieres a son propre poste.
##
##   Net.host("Samuel")            -> cree la partie sur le port 7777
##   Net.join("Corinne", "1.2.3.4")
##   Net.start_game(false)         -> (hote) tout le monde passe au bureau

signal lobby_changed
signal status(text: String)
signal kicked_to_menu(text: String)

const PORT := 7777
const MAX_PLAYERS := 4
const POD_ORDER := [0, 4, 2, 6]

var active := false
var players := {}          # peer_id -> {"name", "pod", "seed", "satan"}
var my_name := "JOUEUR"
var satan_mode := false
var seed_value := 0
var ready_peers := []      # joueurs dont le bureau est charge (hote compris)


func _ready() -> void:
	multiplayer.peer_connected.connect(_on_peer_connected)
	multiplayer.peer_disconnected.connect(_on_peer_disconnected)
	multiplayer.connected_to_server.connect(_on_connected)
	multiplayer.connection_failed.connect(_on_failed)
	multiplayer.server_disconnected.connect(_on_server_gone)


# ------------------------------------------------------------- etat

func is_host() -> bool:
	return not active or multiplayer.is_server()


func my_id() -> int:
	return multiplayer.get_unique_id() if active else 1


func my_pod() -> int:
	if not active:
		return 0
	return int(players.get(my_id(), {}).get("pod", 0))


func count() -> int:
	return max(1, players.size()) if active else 1


func peer_for_pod(pod: int) -> int:
	for id in players:
		if int(players[id]["pod"]) == pod:
			return int(id)
	return 0


func is_satan(id: int) -> bool:
	return bool(players.get(id, {}).get("satan", false))


func i_am_satan() -> bool:
	return active and is_satan(my_id())


# ------------------------------------------------------------- connexion

func host(pname: String, port := PORT) -> int:
	leave()
	my_name = _clean(pname)
	var peer := ENetMultiplayerPeer.new()
	var err := peer.create_server(port, MAX_PLAYERS - 1)
	if err != OK:
		status.emit(Loc.f("net_err_host", [port]))
		return err
	multiplayer.multiplayer_peer = peer
	active = true
	players = {1: {"name": my_name, "pod": POD_ORDER[0], "seed": Profile.look_seed, "satan": false, "echo": Loc.echoes, "cos": Profile.cosmetics()}}
	status.emit(Loc.f("net_hosting", [port, "***.***.***.***" if Loc.streamer_mode else _local_ips()]))
	lobby_changed.emit()
	return OK


## Comme host(), mais avec un pair deja cree (ex. : SteamMultiplayerPeer).
func host_with_peer(pname: String, peer: MultiplayerPeer) -> void:
	leave()
	my_name = _clean(pname)
	multiplayer.multiplayer_peer = peer
	active = true
	players = {1: {"name": my_name, "pod": POD_ORDER[0], "seed": Profile.look_seed, "satan": false, "echo": Loc.echoes, "cos": Profile.cosmetics()}}
	status.emit(Loc.t("steam_hosting"))
	lobby_changed.emit()


func join_with_peer(pname: String, peer: MultiplayerPeer) -> void:
	leave()
	my_name = _clean(pname)
	multiplayer.multiplayer_peer = peer
	active = true
	players = {}
	status.emit(Loc.t("steam_joining"))


func join(pname: String, ip: String, port := PORT) -> int:
	leave()
	my_name = _clean(pname)
	var peer := ENetMultiplayerPeer.new()
	var err := peer.create_client(ip.strip_edges(), port)
	if err != OK:
		status.emit(Loc.t("net_err_join"))
		return err
	multiplayer.multiplayer_peer = peer
	active = true
	players = {}
	status.emit(Loc.f("net_joining", [ip, port]))
	return OK


func leave() -> void:
	if multiplayer.multiplayer_peer != null and active:
		multiplayer.multiplayer_peer.close()
	multiplayer.multiplayer_peer = OfflineMultiplayerPeer.new()
	active = false
	players = {}
	lobby_changed.emit()


func _clean(n: String) -> String:
	var s := n.strip_edges().to_upper()
	if s == "":
		s = "JOUEUR"
	return s.substr(0, 12)


func _local_ips() -> String:
	var out := []
	for a in IP.get_local_addresses():
		var s := str(a)
		if s.count(".") == 3 and not s.begins_with("127.") and not s.begins_with("169.254"):
			out.append(s)
	return ", ".join(out) if not out.is_empty() else "127.0.0.1"


# ------------------------------------------------------------- evenements reseau

func _on_peer_connected(_id: int) -> void:
	pass


func _on_peer_disconnected(id: int) -> void:
	if not multiplayer.is_server():
		return
	if players.has(id):
		var nm := str(players[id]["name"])
		players.erase(id)
		ready_peers.erase(id)
		_ready_list.rpc(ready_peers)
		_sync_players.rpc(players)
		_notice.rpc(Loc.f("net_left", [nm]))


func _on_connected() -> void:
	_register.rpc_id(1, my_name, Profile.look_seed, Loc.echoes, Profile.cosmetics())


func _on_failed() -> void:
	leave()
	status.emit(Loc.t("net_err_join"))


var last_message := ""


func _on_server_gone() -> void:
	leave()
	last_message = Loc.t("net_host_gone")
	kicked_to_menu.emit(last_message)
	if get_tree().current_scene != null and get_tree().current_scene.name != "Menu":
		get_tree().change_scene_to_file("res://scenes/menu.tscn")


@rpc("any_peer", "reliable")
func _register(pname: String, seed_in: int, echo := true, cos := {}) -> void:
	if not multiplayer.is_server():
		return
	var id := multiplayer.get_remote_sender_id()
	if players.size() >= MAX_PLAYERS or get_tree().current_scene == null or get_tree().current_scene.name != "Menu":
		_refused.rpc_id(id)
		return
	var used := []
	for p in players.values():
		used.append(int(p["pod"]))
	var pod := 0
	for po in POD_ORDER:
		if not used.has(po):
			pod = po
			break
	var nm := _clean(pname)
	for p in players.values():
		if str(p["name"]) == nm:
			nm = (nm + str(players.size() + 1)).substr(0, 12)
	players[id] = {"name": nm, "pod": pod, "seed": seed_in, "satan": false, "echo": echo, "cos": cos}
	_sync_players.rpc(players)
	_notice.rpc(Loc.f("net_joined", [nm]))


@rpc("authority", "reliable")
func _refused() -> void:
	leave()
	status.emit(Loc.t("net_full"))


@rpc("authority", "reliable", "call_local")
func _sync_players(p: Dictionary) -> void:
	players = p
	lobby_changed.emit()


@rpc("authority", "reliable", "call_local")
func _notice(text: String) -> void:
	status.emit(text)


# ------------------------------------------------------------- depart

## Appele par le bureau (Main) quand il a fini de charger.
func scene_loaded() -> void:
	if not active:
		return
	if multiplayer.is_server():
		_mark_loaded(1)
	else:
		_client_loaded.rpc_id(1)


@rpc("any_peer", "reliable")
func _client_loaded() -> void:
	if multiplayer.is_server():
		_mark_loaded(multiplayer.get_remote_sender_id())


func _mark_loaded(id: int) -> void:
	if not ready_peers.has(id):
		ready_peers.append(id)
	_ready_list.rpc(ready_peers)


@rpc("authority", "reliable", "call_local")
func _ready_list(list: Array) -> void:
	ready_peers = list


func all_loaded() -> bool:
	for id in players:
		if not ready_peers.has(int(id)):
			return false
	return true


func start_game(weekly: bool, with_satan := false) -> void:
	if not multiplayer.is_server():
		return
	seed_value = randi()
	for id in players:
		players[id]["satan"] = false
	if with_satan and players.size() >= 2:
		var ids := players.keys()
		players[ids[randi() % ids.size()]]["satan"] = true
	_sync_players.rpc(players)
	_start.rpc(seed_value, weekly, with_satan)


@rpc("authority", "reliable", "call_local")
func _start(seed_in: int, weekly: bool, with_satan: bool) -> void:
	ready_peers = []
	seed_value = seed_in
	satan_mode = with_satan
	Game.new_run(weekly, seed_in)
	Loc.set_loading(true)
	get_tree().change_scene_to_file("res://main.tscn")
