extends Node
## Relais IA (version commerciale) : le jeu ne contient aucune cle.
## config_ia.cfg (a la racine du projet) :
##   [relais]
##   url="https://ohmygod-relais.TONCOMPTE.workers.dev"
##   secret="meme valeur que CLIENT_SECRET du serveur"
## Priorite : cle_api.txt (developpement) > relais > mode hors ligne.

var url := ""
var secret := ""
var player := ""


func _ready() -> void:
	var cf := ConfigFile.new()
	for p in ["res://config_ia.cfg", "user://config_ia.cfg"]:
		if cf.load(p) == OK:
			url = str(cf.get_value("relais", "url", "")).strip_edges().trim_suffix("/")
			secret = str(cf.get_value("relais", "secret", ""))
			if url != "":
				break
	var pf := ConfigFile.new()
	pf.load("user://relais_id.cfg")
	player = str(pf.get_value("id", "player", ""))
	if player == "":
		var c := Crypto.new()
		player = c.generate_random_bytes(16).hex_encode()
		pf.set_value("id", "player", player)
		pf.save("user://relais_id.cfg")


func enabled() -> bool:
	return url != ""


## Signature pour un corps binaire (transcription audio).
func sign_bytes(body: PackedByteArray) -> String:
	if secret == "":
		return ""
	var ctx := HMACContext.new()
	ctx.start(HashingContext.HASH_SHA256, secret.to_utf8_buffer())
	ctx.update(body)
	return ctx.finish().hex_encode()


## En-tetes HTTP pour un corps JSON donne (signature HMAC-SHA256).
func headers(body: String) -> PackedStringArray:
	var h := PackedStringArray(["content-type: application/json"])
	if secret != "":
		var ctx := HMACContext.new()
		ctx.start(HashingContext.HASH_SHA256, secret.to_utf8_buffer())
		ctx.update(body.to_utf8_buffer())
		h.append("x-omg-sig: " + ctx.finish().hex_encode())
	return h
