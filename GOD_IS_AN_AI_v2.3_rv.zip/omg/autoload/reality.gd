extends Node
## ============================================================
##  REALITY ECHO — « Everything you say can become part of reality. »
## ============================================================
## La simulation ecoute : la voix des joueurs (transcrite), ce qu'ils
## ecrivent aux fideles, le chat texte, et meme le chat Twitch.
## Certaines idees deviennent des ECHO SEEDS. Repetees, partagees,
## reprises en appel, elles prennent de la force (AMPLIFICATION) et
## montent de niveau :
##   1 Coincidence  2 Comportement  3 Tendance  4 Societe  5 Reecriture
## Elles reviennent plus tard (DELAY), parfois deformees (CORRUPTION),
## dans des prieres, la Gazette, la bouche des collegues... et peuvent
## finir par reecrire les lois de la simulation.
## Rien n'est deterministe : aucune formule exacte, volontairement.
##
## Memoire persistante : user://world.json (la simulation se souvient
## d'une partie a l'autre). Option « Nouvelle simulation » pour effacer.

signal tier_up(e: Dictionary)
signal changed
signal first_heard(e: Dictionary)     # le PREMIER ECHO de la partie : la simulation montre qu'elle a entendu
signal seeded(e: Dictionary)          # une nouvelle idee retenue (retour discret)

const PATH := "user://world.json"
const MAX_ECHOES := 60
const KINDS := ["belief", "rule", "character", "object", "lie"]
const TIER_AT := [0.0, 1.0, 3.2, 5.6, 8.4, 12.5]   # force minimale par niveau (avec du flou)
const STOP_FR := ["alors", "aussi", "autre", "avant", "avec", "avoir", "bien", "c'est", "cette", "comme", "dans", "depuis", "donc", "elle", "elles", "encore", "est-ce", "etait", "faire", "fait", "faut", "imagine", "juste", "leur", "leurs", "mais", "meme", "moins", "notre", "nous", "parce", "pour", "pourquoi", "quand", "quelque", "qu'il", "sans", "sont", "suis", "tout", "toute", "tous", "tres", "vous", "vraiment", "ouais", "genre", "ok", "dire", "était", "être", "peut", "veux", "vais", "allez", "bon", "là", "ça", "cela", "voilà", "chose", "choses", "jamais", "toujours", "rien", "personne", "seigneur", "dieu", "employé", "employee", "test", "about", "there", "their", "would", "could", "should", "think", "really", "people", "thing", "things", "what", "when", "where", "which", "with", "your", "they", "them", "this", "that", "just", "like", "were", "have", "been", "from", "imagine", "always", "never", "nobody", "something"]
const TRIGGERS := ["imagine", "et si", "si jamais", "je gage", "c'est sûr que", "c'est sur que", "tout le monde", "religion", "secte", "culte", "loi", "devrait", "devraient", "what if", "everyone", "cult", "should", "i bet", "religion", "sacré", "sacre", "sacred", "caméra", "camera", "espion", "spy", "plate", "flat", "complot", "conspiracy", "vivant", "alive", "promets", "promise", "secret"]
const REWRITE_HOOKS := {
	"flat": ["plate", "flat", "plates"],
	"gravity": ["gravité", "gravite", "gravity", "flotte", "flottent", "float"],
	"pigeon": ["pigeon", "pigeons"],
	"cat": ["chat", "chats", "cat", "cats"],
	"night": ["nuit", "dark", "night", "obscurite", "obscurité"],
	"monday": ["lundi", "lundis", "monday"],
}

var echoes := []             # voir _new_echo()
var next_id := 1
var rules := []              # lois de la simulation reecrites (texte)
var hooks := {}              # reecritures visuelles actives : hook -> echo id
var buffer := []             # [{text, who, ctx}] en attente d'extraction IA
var extract_t := 0.0
var http: HTTPRequest
var busy := false
var heard_count := 0
# PREMIER ECHO GARANTI : dans chaque partie, une phrase d'un joueur revient VITE
var first_done := false
var first_id := -1
var session_t := 0.0
var recent := []             # dernieres phrases des joueurs [{text, who, ctx}]
const FIRST_FALLBACK := 100.0   # s de jeu sans idee -> on prend la meilleure phrase entendue


func _ready() -> void:
	http = HTTPRequest.new()
	http.timeout = 25.0
	add_child(http)
	http.request_completed.connect(_on_extract)
	load_world()


# ------------------------------------------------------------- memoire du monde

func load_world() -> void:
	if not FileAccess.file_exists(PATH):
		return
	var js := JSON.new()
	var txt := FileAccess.get_file_as_string(PATH)
	if js.parse(txt) != OK or typeof(js.data) != TYPE_DICTIONARY:
		# memoire illisible : on la met de cote au lieu de l'ecraser
		if txt.strip_edges() != "":
			DirAccess.rename_absolute(ProjectSettings.globalize_path(PATH), ProjectSettings.globalize_path(PATH.replace(".json", "_illisible.json")))
		return
	var d: Dictionary = js.data
	var raw = d.get("echoes", [])
	echoes = []
	if typeof(raw) == TYPE_ARRAY:
		for e in raw:
			if typeof(e) == TYPE_DICTIONARY:
				echoes.append(_sanitize(e))
	next_id = int(d.get("next_id", 1)) if typeof(d.get("next_id", 1)) in [TYPE_INT, TYPE_FLOAT] else 1
	for e in echoes:
		next_id = maxi(next_id, int(e["id"]) + 1)
	var rr = d.get("rules", [])
	rules = rr if typeof(rr) == TYPE_ARRAY else []
	var hh = d.get("hooks", {})
	hooks = hh if typeof(hh) == TYPE_DICTIONARY else {}
	# le temps a passe entre deux sessions : les idees reviennent plus vite
	var now := Time.get_unix_time_from_system()
	for e in echoes:
		e["ready_at"] = minf(float(e.get("ready_at", now)), now + randf_range(60.0, 240.0))


func reload() -> void:
	echoes = []
	rules = []
	hooks = {}
	next_id = 1
	buffer = []
	first_done = false
	first_id = -1
	session_t = 0.0
	recent = []
	if Net.active and not Net.is_host():
		return        # en co-op, le client attend le monde de l'hote
	load_world()


func save_world() -> void:
	if Net.active and not Net.is_host():
		return
	var f := FileAccess.open(PATH, FileAccess.WRITE)
	if f != null:
		f.store_string(JSON.stringify({"echoes": echoes, "next_id": next_id, "rules": rules, "hooks": hooks}))


func reset_world() -> void:
	buffer = []
	_pending = []
	echoes = []
	rules = []
	hooks = {}
	next_id = 1
	save_world()
	changed.emit()


## Complete un echo venu du disque, du reseau ou de l'IA (rien ne doit planter).
func _sanitize(e: Dictionary) -> Dictionary:
	var now := Time.get_unix_time_from_system()
	var defs := {"id": next_id, "key": "echo", "idea": "", "orig": "", "who": "?", "ctx": "voice", "when": "",
		"kind": "belief", "name": "", "target": "", "corrupt": "", "movement": "", "rewrite": "",
		"strength": 1.0, "tier": 0, "mentions": 1, "born": now, "ready_at": now, "used": 0}
	for k in defs:
		if not e.has(k) or typeof(e[k]) != typeof(defs[k]) and not (typeof(e[k]) in [TYPE_INT, TYPE_FLOAT] and typeof(defs[k]) in [TYPE_INT, TYPE_FLOAT]):
			e[k] = defs[k]
	for k in ["tags", "speakers", "history", "stems"]:
		if typeof(e.get(k)) != TYPE_ARRAY:
			e[k] = []
	if str(e["idea"]) == "":
		e["idea"] = str(e["orig"]) if str(e["orig"]) != "" else str(e["key"]).replace("_", " ")
	if (e["stems"] as Array).is_empty():
		e["stems"] = _words(str(e["idea"]) + " " + str(e["orig"]))
	if not (str(e["kind"]) in KINDS):
		e["kind"] = "belief"
	if str(e["kind"]) == "character" and str(e["name"]) == "":
		e["kind"] = "belief"
	e["key"] = str(e["key"]).substr(0, 40)
	e["tier"] = clampi(int(e["tier"]), 0, 5)
	return e


func _hist(e: Dictionary, txt: String) -> void:
	var h: Array = e["history"]
	h.append("%s : %s" % [_clock(), txt])
	while h.size() > 24:
		h.remove_at(1)        # on garde la naissance, on oublie le milieu


## JSON.parse_string sans message d'erreur dans la console (les IA repondent parfois en prose).
func quiet_json(txt: String) -> Variant:
	var js := JSON.new()
	if js.parse(txt) != OK:
		return null
	return js.data


func authority() -> bool:
	return not Net.active or Net.is_host()


# ------------------------------------------------------------- l'ecoute

## Tout ce qui est « dit » passe ici. ctx : voice / call / chat / twitch / mission
func hear(text: String, who: String, ctx := "voice") -> void:
	text = text.strip_edges()
	if text.length() < 6:
		return
	heard_count += 1
	if not authority():
		return
	if not who.begins_with("@"):
		recent.append({"text": text.substr(0, 160), "who": who, "ctx": ctx})
		if recent.size() > 12:
			recent.pop_front()
	if _ai_available():
		buffer.append({"text": text.substr(0, 220), "who": who, "ctx": ctx, "when": _clock()})
		if buffer.size() > 30:
			buffer.pop_front()
	else:
		_heuristic(text, who, ctx)


func _clock() -> String:
	var main := get_tree().current_scene
	if main != null and main.has_method("clock_text"):
		return str(main.clock_text())
	return Loc.f("hl_day", [Game.day])


func _ai_available() -> bool:
	var main := get_tree().current_scene
	if main == null or main.get("api_key") == null:
		return false
	return str(main.api_key) != "" or bool(main.relay_ok())


var tier_t := 3.0
var last_pick := -1


func _process(dt: float) -> void:
	if not authority():
		return
	var main := get_tree().current_scene
	var running: bool = main != null and main.get("frozen") != null and not bool(main.frozen)
	# AMPLIFICATION SOCIALE : les idees deja repandues continuent de se propager seules
	if running:
		for e in echoes:
			if int(e["tier"]) >= 2:
				_grow(e, dt * 0.006 * float(e["tier"]) * randf_range(0.4, 1.6), "")
	if running and not first_done:
		session_t += dt
		if session_t > FIRST_FALLBACK:
			session_t = FIRST_FALLBACK - 20.0     # on reessaie dans 20 s si personne n'a parle
			_first_fallback()
	# les idees qui ont « mature » montent de niveau meme sans qu'on en reparle
	tier_t -= dt
	if running and tier_t <= 0.0:
		tier_t = 3.0
		for e in echoes.duplicate():
			if int(e["tier"]) >= 1:
				_check_tier(e)
	# extraction IA par paquets
	extract_t += dt
	if extract_t > 40.0 and not buffer.is_empty() and not busy and _ai_available():
		extract_t = 0.0
		_extract_ai()


# ------------------------------------------------------------- extraction (sans IA)

func _norm(s: String) -> String:
	var out := s.to_lower()
	for pair in [["é", "e"], ["è", "e"], ["ê", "e"], ["ë", "e"], ["à", "a"], ["â", "a"], ["î", "i"], ["ï", "i"], ["ô", "o"], ["ù", "u"], ["û", "u"], ["ç", "c"]]:
		out = out.replace(pair[0], pair[1])
	return out


func _words(s: String) -> Array:
	var clean := _norm(s)
	for ch in [",", ".", "!", "?", ";", ":", "\"", "«", "»", "(", ")", "-", "'", "’"]:
		clean = clean.replace(ch, " ")
	var out := []
	for w in clean.split(" ", false):
		if w.length() >= 4 and not (w in STOP_FR) and not w.is_valid_int():
			out.append(w.substr(0, 6))
	return out


const NOT_NAMES := ["dieu", "god", "seigneur", "lord", "satan", "jesus", "jésus", "terre", "earth", "lune", "moon", "soleil", "sun",
	"lundi", "monday", "internet", "simulation", "france", "canada", "quebec", "québec", "paris", "montreal", "montréal", "imagine", "genre",
	"monsieur", "madame", "bonjour", "merci", "salut", "allo", "allô", "oui", "non", "okay", "hello", "yes", "mister", "miss", "lol",
	"twitch", "steam", "discord", "youtube", "tiktok", "google", "amen", "alléluia", "alleluia", "noël", "christmas", "the", "les"]


## Noms de personnes « connues » (joueurs, collegues) : ce ne sont pas des personnages inventes.
func _known_names() -> Array:
	var out := []
	for id in Net.players:
		out.append(str(Net.players[id].get("name", "")).to_lower())
	var main := get_tree().current_scene
	if main != null and main.get("WHO") != null:
		for w in main.WHO:
			out.append(str(w).to_lower())
	return out


func _names(s: String, who: String) -> Array:
	# noms propres inventes (Gérard...) : majuscule au milieu d'une phrase
	var out := []
	var known := _known_names()
	var parts := s.split(" ", false)
	for i in range(1, parts.size()):
		var prev: String = parts[i - 1]
		if prev.ends_with(".") or prev.ends_with("!") or prev.ends_with("?") or prev.ends_with(":") or prev.ends_with("…") or prev.ends_with("\""):
			continue        # debut de phrase : la majuscule ne veut rien dire
		var w: String = parts[i].strip_edges().trim_suffix(",").trim_suffix(".").trim_suffix("!").trim_suffix("?").trim_prefix("«").trim_suffix("»")
		if w.length() >= 3 and w[0] == w[0].to_upper() and w[0] != w[0].to_lower() and w.substr(1) == w.substr(1).to_lower():
			if w.to_upper() != who.to_upper() and not (w.to_lower() in NOT_NAMES) and not (w.to_lower() in known):
				out.append(w)
	return out


## Texte normalise entoure d'espaces, ponctuation retiree : pour chercher des MOTS entiers.
func _padded(s: String) -> String:
	var clean := _norm(s)
	for ch in [",", ".", "!", "?", ";", ":", "\"", "«", "»", "(", ")", "-", "'", "’", "…"]:
		clean = clean.replace(ch, " ")
	return " " + " ".join(clean.split(" ", false)) + " "


func _has(p: String, k: String) -> bool:
	var kk := _padded(k).strip_edges()
	return p.contains(" " + kk + " ") or p.contains(" " + kk + "s ") or p.contains(" " + kk + "x ")


func _heuristic(text: String, who: String, ctx: String) -> void:
	var low := _norm(text)
	var pad := _padded(text)
	var words := _words(text)
	var names := _names(text, who)
	var hit := false
	for t in TRIGGERS:
		if _has(pad, t):
			hit = true
			break
	# on essaie d'abord d'AMPLIFIER une idee existante
	for e in echoes:
		var common := 0
		for w in words:
			if w in e["stems"]:
				common += 1
		var name_hit: bool = e["name"] != "" and low.contains(_norm(str(e["name"])))
		if common >= 2 or name_hit or (common >= 1 and hit):
			_mention(e, who, ctx, text)
			return
	var hooked := false
	for h in REWRITE_HOOKS:
		for k in REWRITE_HOOKS[h]:
			if _has(pad, k):
				hooked = true
	if names.size() > 0 and ctx != "call" and not hooked:
		_new_echo(text, who, ctx, {"kind": "character", "name": names[0], "key": _norm(names[0]), "tags": [names[0]]})
		return
	if not hit or words.size() < 2:
		return
	var kind := "belief"
	if hooked:
		kind = "rule"
	if ctx == "call" and (_has(pad, "vivant") or _has(pad, "alive") or _has(pad, "promets") or _has(pad, "promise")):
		kind = "lie"
	_new_echo(text, who, ctx, {"kind": kind, "tags": words.slice(0, 4), "key": "_".join(PackedStringArray(words.slice(0, 3)))})


# ------------------------------------------------------------- extraction (avec l'IA)

func _extract_ai() -> void:
	var main := get_tree().current_scene
	busy = true
	# on reste sous les limites du relais (9000 caracteres de messages)
	var lines := ""
	for b in buffer.slice(-18):
		lines += "- [%s] %s : « %s »\n" % [b["ctx"], str(b["who"]).substr(0, 20), str(b["text"]).substr(0, 180)]
	var known := []
	var strong := echoes.duplicate()
	strong.sort_custom(func(x, y): return float(x["strength"]) > float(y["strength"]))
	for e in strong.slice(0, 25):
		known.append("%s = %s" % [e["key"], str(e["idea"]).substr(0, 90)])
	var system := Loc.t("echo_ai_system") + "\n(G.O.D. Reality Echo)"
	var user := Loc.f("echo_ai_user", ["\n".join(PackedStringArray(known)) if not known.is_empty() else "-", lines])
	var body := {"system": system, "messages": [{"role": "user", "content": user}]}
	var pending := buffer.duplicate()
	buffer = []
	_pending = pending
	var err: int
	if str(main.api_key) != "":
		body["model"] = main.AI_MODEL
		body["max_tokens"] = 700
		err = http.request("https://api.anthropic.com/v1/messages", ["content-type: application/json", "x-api-key: " + str(main.api_key), "anthropic-version: 2023-06-01"], HTTPClient.METHOD_POST, JSON.stringify(body))
	else:
		body["player"] = Relay.player
		var js := JSON.stringify(body)
		err = http.request(Relay.url + "/v1/chat", Relay.headers(js), HTTPClient.METHOD_POST, js)
	if err != OK:
		busy = false
		for b in pending:
			_heuristic(str(b["text"]), str(b["who"]), str(b["ctx"]))


var _pending := []


func _on_extract(_r: int, code: int, _h: PackedStringArray, bytes: PackedByteArray) -> void:
	busy = false
	var ok := false
	if code == 429:
		var m := get_tree().current_scene
		if m != null and m.get("relay_wait") != null:
			m.relay_wait = 25.0
	if code == 200:
		var data = quiet_json(bytes.get_string_from_utf8())
		if typeof(data) == TYPE_DICTIONARY and data.has("content"):
			var txt := ""
			for blk in data["content"]:
				if typeof(blk) == TYPE_DICTIONARY and blk.get("type", "") == "text":
					txt += str(blk.get("text", ""))
			var a := txt.find("{")
			var z := txt.rfind("}")
			if a >= 0 and z > a:
				var obj = quiet_json(txt.substr(a, z - a + 1))
				if typeof(obj) == TYPE_DICTIONARY:
					ok = true
					var items = obj.get("echoes", [])
					for it in (items if typeof(items) == TYPE_ARRAY else []):
						if typeof(it) == TYPE_DICTIONARY:
							_apply_ai_item(it)
	if not ok:
		for b in _pending:
			_heuristic(str(b["text"]), str(b["who"]), str(b["ctx"]))
	_pending = []


func _apply_ai_item(it: Dictionary) -> void:
	var key := _norm(str(it.get("key", ""))).strip_edges().replace(" ", "_").substr(0, 40)
	if key == "" or str(it.get("idea", it.get("quote", ""))).strip_edges() == "":
		return
	var who := str(it.get("who", "?"))
	var quote := str(it.get("quote", it.get("idea", "")))
	var ctx := str(it.get("ctx", "voice"))
	# meme idee sous une autre cle (l'IA n'est pas toujours constante) : on amplifie
	var st := _words(str(it.get("idea", "")) + " " + quote)
	for e in echoes:
		var common := 0
		for w in st:
			if w in e["stems"]:
				common += 1
		if str(e["key"]) == key or common >= 3 or (common >= 2 and st.size() <= 4):
			_mention(e, who, ctx, quote)
			if str(it.get("movement", "")) != "" and str(e["movement"]) == "":
				e["movement"] = str(it["movement"])
			return
	var kind := str(it.get("kind", "belief"))
	var nm := str(it.get("name", "")).substr(0, 30)
	if not (kind in KINDS) or (kind == "character" and nm == ""):
		kind = "belief"
	var tags = it.get("tags", [])
	if typeof(tags) != TYPE_ARRAY:
		tags = []
	var fun = it.get("funny", 5)
	var power: float = clampf(float(fun) / 5.0, 0.2, 2.0) if typeof(fun) in [TYPE_INT, TYPE_FLOAT] else 1.0
	_new_echo(quote, who, ctx, {
		"key": key, "idea": str(it.get("idea", quote)).substr(0, 160), "tags": tags,
		"kind": kind, "name": nm,
		"corrupt": str(it.get("corrupt", "")), "movement": str(it.get("movement", "")),
		"rewrite": str(it.get("rewrite", "")), "target": str(it.get("target", "")),
		"power": power,
	})


# ------------------------------------------------------------- les echos

func _new_echo(text: String, who: String, ctx: String, info: Dictionary) -> void:
	var now := Time.get_unix_time_from_system()
	var fast := Dev.args.has("echotest")
	var e := {
		"id": next_id, "key": str(info.get("key", "echo%d" % next_id)),
		"idea": str(info.get("idea", text)), "orig": text, "who": who, "ctx": ctx,
		"when": _clock(), "tags": info.get("tags", []), "stems": _words(str(info.get("idea", text)) + " " + text),
		"kind": str(info.get("kind", "belief")), "name": str(info.get("name", "")),
		"target": str(info.get("target", "")), "corrupt": str(info.get("corrupt", "")),
		"movement": str(info.get("movement", "")), "rewrite": str(info.get("rewrite", "")),
		"strength": 0.6 + float(info.get("power", 1.0)) * randf_range(0.3, 0.9) + (0.8 if ctx == "call" else 0.0),
		"tier": 0, "speakers": [who], "mentions": 1, "born": now,
		"ready_at": now + (randf_range(8.0, 25.0) if fast else randf_range(150.0, 720.0)),
		"used": 0, "history": [],
	}
	next_id += 1
	echoes.append(e)
	if echoes.size() > MAX_ECHOES:
		# on oublie l'idee la plus faible
		var weakest := 0
		for i in echoes.size():
			if float(echoes[i]["strength"]) < float(echoes[weakest]["strength"]) and int(echoes[i]["tier"]) < 5:
				weakest = i
		echoes.remove_at(weakest)
		if not (e in echoes):
			changed.emit()
			return        # l'idee etait trop faible pour etre retenue
	if not first_done and str(e["kind"]) != "lie" and not who.begins_with("@"):
		_make_first(e)
	_check_tier(e)
	if Dev.args.has("autoplay"):
		print("ECHO SEED [", e["kind"], "] ", e["key"], " <- ", who, " : ", text)
	save_world()
	seeded.emit(e)
	changed.emit()


## Le premier echo de la partie revient en ~30 s au lieu de 2 a 12 min.
func _make_first(e: Dictionary) -> void:
	first_done = true
	first_id = int(e["id"])
	e["first"] = true
	e["ready_at"] = Time.get_unix_time_from_system() + randf_range(18.0, 32.0)
	e["strength"] = maxf(float(e["strength"]), 1.6)
	if Dev.args.has("autoplay"):
		print("PREMIER ECHO : ", e["key"], " <- ", e["who"], " : ", e["orig"])
	first_heard.emit(e)


## Personne n'a rien dit d'« idee » ? On prend la phrase la plus savoureuse entendue.
func _first_fallback() -> void:
	var best := {}
	var best_s := -1.0
	for r in recent:
		var w := _words(str(r["text"]))
		if w.size() < 2 or str(r["text"]).length() < 12:
			continue
		var sc := float(w.size()) + (3.0 if str(r["ctx"]) != "call" else 0.0) + randf() * 2.0
		if str(r["text"]).contains("?") or str(r["text"]).contains("!"):
			sc += 2.0
		if sc > best_s:
			best_s = sc
			best = r
	if best.is_empty():
		return
	var w2 := _words(str(best["text"]))
	_new_echo(str(best["text"]), str(best["who"]), str(best["ctx"]), {"kind": "belief", "tags": w2.slice(0, 4), "key": "_".join(PackedStringArray(w2.slice(0, 3)))})


func _mention(e: Dictionary, who: String, ctx: String, text: String) -> void:
	e["mentions"] = int(e["mentions"]) + 1
	var gain := 0.8
	if not (who in e["speakers"]):
		e["speakers"].append(who)
		gain += 1.4          # plusieurs joueurs developpent la meme idee
	if ctx == "call":
		gain += 0.9          # dite en pleine priere
	if ctx == "twitch":
		gain += 0.3
	_grow(e, gain * randf_range(0.6, 1.4), text)


func _grow(e: Dictionary, amount: float, text: String) -> void:
	e["strength"] = float(e["strength"]) + amount
	if text != "" and Dev.args.has("autoplay"):
		print("ECHO AMPLIFIE ", e["key"], " force=", snappedf(float(e["strength"]), 0.1), " (", text, ")")
	_check_tier(e)


func _check_tier(e: Dictionary) -> void:
	var t := int(e["tier"])
	var max_t := 5 if str(e["kind"]) in ["rule", "belief"] else 4
	var now := Time.get_unix_time_from_system()
	# un seul niveau a la fois : la realite rattrape la blague PEU A PEU
	if t < max_t and float(e["strength"]) >= TIER_AT[t + 1] * randf_range(0.85, 1.2):
		# ECHO DELAY : a partir du niveau 2, il faut attendre que ca « mature »
		if t + 1 < 2 or now >= maxf(float(e["ready_at"]), float(e.get("next_at", 0.0))):
			t += 1
			var fast: bool = Dev.args.has("echotest")
			if t >= 2:
				e["next_at"] = now + (randf_range(6.0, 14.0) if fast else randf_range(45.0, 150.0))
	if t > int(e["tier"]):
		e["tier"] = t
		_hist(e, Loc.t("echo_tier_%d" % t))
		if t == 5:
			_rewrite(e)
		tier_up.emit(e)
		if Dev.args.has("autoplay"):
			print("ECHO NIVEAU ", t, " : ", e["key"])
		save_world()


func _rewrite(e: Dictionary) -> void:
	var rule := str(e["rewrite"]) if str(e["rewrite"]) != "" else str(e["idea"])
	if not (rule in rules):
		rules.append(rule)
		while rules.size() > 20:
			rules.pop_front()
	var pad := _padded(str(e["idea"]) + " " + str(e["orig"]) + " " + str(e["rewrite"]))
	for h in REWRITE_HOOKS:
		for k in REWRITE_HOOKS[h]:
			if _has(pad, k):
				hooks[h] = int(e["id"])


## ECHO PERSONNEL : ce que « Dieu » a affirme a un fidele (conseil,
## prediction, mensonge) devient une graine liee a cette personne.
func add_promise(text: String, who: String, target: String) -> void:
	if not authority() or text.strip_edges() == "":
		return
	# la meme promesse (ou presque) faite au meme fidele : on l'amplifie
	var st := _words(text)
	for e in echoes:
		if str(e["kind"]) != "lie":
			continue
		var common := 0
		for w in st:
			if w in e["stems"]:
				common += 1
		if common >= 2 or (str(e["target"]) == target and common >= 1):
			_mention(e, who, "call", text)
			return
	_new_echo(text, who, "call", {"kind": "lie", "target": target, "tags": _words(text).slice(0, 4),
		"key": "promesse_" + _norm(target).replace(" ", "_") + "_%d" % next_id, "power": 1.4})


## Une conversion autour d'une idee la renforce (ECHO SOCIAL / CASCADE).
func believer_convinced(b: Dictionary) -> void:
	if not authority() or not b.has("echo_id"):
		return
	var e := find(int(b["echo_id"]))
	if not e.is_empty():
		_grow(e, randf_range(1.2, 2.4), "")
		_hist(e, Loc.f("echo_hist_conv", [str(b.get("name", "?"))]))


func find(id: int) -> Dictionary:
	for e in echoes:
		if int(e["id"]) == id:
			return e
	return {}


# ------------------------------------------------------------- retour dans le monde

## Choisit une idee pour une nouvelle priere (ou rien). Jamais previsible.
func pick_for_prayer() -> Dictionary:
	var now := Time.get_unix_time_from_system()
	# le premier echo revient a coup sur, au premier appel apres sa maturation
	for e in echoes:
		if e.get("first", false) and int(e["used"]) == 0 and float(e["ready_at"]) <= now:
			if int(e["tier"]) < 1:
				e["tier"] = 1
			return e
	var cands := []
	var total := 0.0
	for e in echoes:
		if float(e["ready_at"]) > now or int(e["tier"]) < 1:
			continue
		var w := float(e["tier"]) * float(e["tier"]) * randf_range(0.3, 1.0) / (1.0 + float(e["used"]) * 0.7)
		if int(e["tier"]) == 1:
			w *= 0.35
		if int(e["id"]) == last_pick:
			w *= 0.15        # running gag oui, disque raye non
		cands.append([e, w])
		total += w
	if cands.is_empty():
		return {}
	var chance := clampf(0.18 + total * 0.03, 0.18, 0.62)
	if Dev.args.has("echotest"):
		chance = 0.85
	if randf() > chance:
		return {}
	var r := randf() * total
	for c in cands:
		r -= float(c[1])
		if r <= 0.0:
			return c[0]
	return cands[0][0]


## Co-op : un client a recu une priere nee de cet echo (l'hote tient les comptes).
func mark_used(id: int, believer: String) -> void:
	var e := find(id)
	if e.is_empty():
		return
	e["used"] = int(e["used"]) + 1
	_hist(e, Loc.f("echo_hist_prayer", [believer]))
	changed.emit()


## Transforme un fidele genere en fidele « contamine » par l'idee.
func shape_believer(b: Dictionary, e: Dictionary) -> Dictionary:
	if e.get("first", false) and int(e["used"]) == 0:
		# PREMIER ECHO : le fidele cite MOT POUR MOT ce qu'un joueur vient de dire
		e["used"] = 1
		last_pick = int(e["id"])
		b["echo_id"] = int(e["id"])
		b["echo_first"] = true
		b["echo_quote"] = str(e["orig"]).substr(0, 140)
		b["echo_who"] = str(e["who"])
		b["pers_prompt"] = str(b["pers_prompt"]) + Loc.f("ai_echo_first", [str(e["who"]), b["echo_quote"]])
		b["echo_line"] = b["echo_quote"]
		_hist(e, Loc.f("echo_hist_prayer", [str(b["name"])]))
		if Dev.args.has("autoplay"):
			print("PRIERE PREMIER ECHO ", b["name"], " cite : ", b["echo_quote"])
		save_world()
		return b
	e["used"] = int(e["used"]) + 1
	last_pick = int(e["id"])
	b["echo_id"] = int(e["id"])
	var idea := str(e["idea"])
	# ECHO CORRUPTION : la simulation comprend de travers
	if randf() < 0.3:
		idea = str(e["corrupt"]) if str(e["corrupt"]) != "" else _corrupt(e)
		b["echo_corrupt"] = true
	var tier := int(e["tier"])
	var kind := str(e["kind"])
	if kind == "character" and tier >= 3 and str(e["name"]) != "":
		# le personnage invente par les joueurs appelle lui-meme
		b["name"] = str(e["name"])
		b["echo_self"] = true
		Profile.unlock("gerard")
	var mv := str(e["movement"]) if str(e["movement"]) != "" else Loc.f("echo_movement_default", [str(e["key"]).replace("_", " ").to_upper()])
	var line := ""
	match tier:
		1:
			line = Loc.f("ai_echo_1", [idea])
		2:
			line = Loc.f("ai_echo_2", [idea])
		3:
			line = Loc.f("ai_echo_3", [idea])
		4:
			line = Loc.f("ai_echo_4", [mv, idea])
		_:
			line = Loc.f("ai_echo_5", [str(e["rewrite"]) if str(e["rewrite"]) != "" else idea])
	if kind == "character":
		line = Loc.f("ai_echo_char_self" if b.has("echo_self") else "ai_echo_char", [str(e["name"]), idea])
	elif kind == "lie":
		line = Loc.f("ai_echo_lie", [idea])
	b["pers_prompt"] = str(b["pers_prompt"]) + line
	b["echo_line"] = idea
	_hist(e, Loc.f("echo_hist_prayer", [str(b["name"])]))
	if Dev.args.has("autoplay"):
		print("PRIERE ECHO (niveau ", tier, ") ", b["name"], " <- ", e["key"], (" [DEFORMEE]" if b.has("echo_corrupt") else ""))
	save_world()
	return b


func _corrupt(e: Dictionary) -> String:
	var tags: Array = e["tags"]
	var pool := Loc.list("echo_corrupt_tpl")
	var a := str(tags[0]) if tags.size() > 0 else str(e["key"])
	var b2 := str(tags[1]) if tags.size() > 1 else Loc.pick("echo_corrupt_words")
	return str(pool[randi() % pool.size()]).format({"a": a, "b": b2})


## Lois reecrites, ajoutees a toutes les conversations IA.
func rules_prompt() -> String:
	if rules.is_empty():
		return ""
	var rs := []
	for r in rules.slice(-4):
		rs.append(str(r).substr(0, 140))
	return Loc.f("ai_world_rules", ["; ".join(PackedStringArray(rs))])


## Les idees visibles (tendances et +) pour le tableau du bureau.
func trends() -> Array:
	var out := []
	for e in echoes:
		if int(e["tier"]) >= 3:
			out.append(e)
	out.sort_custom(func(a, b): return float(a["strength"]) > float(b["strength"]))
	return out


# ------------------------------------------------------------- co-op

func snapshot() -> Dictionary:
	return {"echoes": echoes, "rules": rules, "hooks": hooks}


func apply_snapshot(d: Dictionary) -> void:
	var raw = d.get("echoes", [])
	echoes = []
	if typeof(raw) == TYPE_ARRAY:
		for e in raw:
			if typeof(e) == TYPE_DICTIONARY:
				echoes.append(_sanitize(e))
	var rr = d.get("rules", [])
	rules = rr if typeof(rr) == TYPE_ARRAY else []
	var hh = d.get("hooks", {})
	hooks = hh if typeof(hh) == TYPE_DICTIONARY else {}
	if Dev.args.has("autoplay"):
		print("MONDE RECU : ", echoes.size(), " echos, lois=", rules.size(), " hooks=", hooks.keys())
	changed.emit()
