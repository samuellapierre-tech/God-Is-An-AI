extends Node
## LE CHAT JOUE DIEU : lecture anonyme du chat Twitch (aucune cle, aucun compte).
##
##   !prier <confession>   / !pray   -> ta confession devient un fidele qui appelle le streamer
##   !colere / !wrath                 -> vote : Dieu se fache (exposition +)
##   !joie / !joy                     -> vote : Dieu se calme (exposition -)
##   !signe / !sign                   -> declenche un signe divin pendant l'appel
##   !amen                            -> la foule applaudit quand le chat spam
##
## Test local : --twitch-url=ws://127.0.0.1:8765 (tools/mock_twitch.py)

signal status(text: String)
signal chat(user: String, text: String, col: Color)
signal confession_added(user: String)
signal echo_idea(user: String, text: String)

const URL := "wss://irc-ws.chat.twitch.tv:443"
const MAX_QUEUE := 15
const MAX_LEN := 160

var ws: WebSocketPeer = null
var channel := ""
var connected := false
var url := URL
var retry := 0.0

var queue := []            # [{user, text}]
var used_users := {}       # un viewer = une confession par journee
var votes := {"wrath": {}, "joy": {}}
var signs := []            # noms des viewers qui ont demande un signe
var amens := []            # temps des !amen recents
var recent := []           # [[user, text, color]] pour l'affichage
var total_msgs := 0
var mission_votes := {}     # viewer -> 0/1/2 (vote pour la carte de mission)
var blocklist := PackedStringArray(["http", "www.", ".com", "@"])


func _ready() -> void:
	for arg in OS.get_cmdline_user_args():
		var s := str(arg)
		if s.begins_with("--twitch-url="):
			url = s.substr(13)
		elif s.begins_with("--twitch="):
			Loc.twitch_channel = s.substr(9)
	var f: FileAccess = null
	if FileAccess.file_exists("user://stream_blocklist.txt"):
		f = FileAccess.open("user://stream_blocklist.txt", FileAccess.READ)
	if f != null:
		for w in f.get_as_text().split("\n", false):
			if w.strip_edges() != "":
				blocklist.append(w.strip_edges().to_lower())
	if Loc.twitch_channel != "":
		start(Loc.twitch_channel)


func active() -> bool:
	return connected and channel != ""


func start(chan: String) -> void:
	stop()
	channel = chan.strip_edges().to_lower().trim_prefix("#").trim_prefix("https://www.twitch.tv/").trim_prefix("twitch.tv/")
	if channel == "":
		return
	ws = WebSocketPeer.new()
	var err := ws.connect_to_url(url)
	if err != OK:
		status.emit(Loc.t("tw_fail"))
		ws = null
		retry = 10.0
		return
	status.emit(Loc.f("tw_connecting", [channel]))


func stop() -> void:
	if ws != null:
		ws.close()
	ws = null
	connected = false
	channel = ""
	retry = 0.0


func _process(dt: float) -> void:
	if ws == null:
		if retry > 0.0:
			retry -= dt
			if retry <= 0.0 and Loc.twitch_channel != "":
				start(Loc.twitch_channel)
		return
	ws.poll()
	var st := ws.get_ready_state()
	if st == WebSocketPeer.STATE_OPEN:
		if not connected:
			connected = true
			ws.send_text("CAP REQ :twitch.tv/tags")
			ws.send_text("PASS SCHMOOPIIE")
			ws.send_text("NICK justinfan%d" % randi_range(10000, 99999))
			ws.send_text("JOIN #" + channel)
			status.emit(Loc.f("tw_on", [channel]))
		while ws.get_available_packet_count() > 0:
			var txt := ws.get_packet().get_string_from_utf8()
			for line in txt.split("\r\n", false):
				_line(line)
	elif st == WebSocketPeer.STATE_CLOSED:
		var keep := channel
		ws = null
		connected = false
		status.emit(Loc.t("tw_lost"))
		if keep != "":
			retry = 8.0


func _line(line: String) -> void:
	if line.begins_with("PING"):
		ws.send_text("PONG" + line.substr(4))
		return
	var tags := {}
	var rest := line
	if rest.begins_with("@"):
		var sp := rest.find(" ")
		for kv in rest.substr(1, sp - 1).split(";"):
			var i := kv.find("=")
			if i > 0:
				tags[kv.substr(0, i)] = kv.substr(i + 1)
		rest = rest.substr(sp + 1)
	var pm := rest.find(" PRIVMSG #")
	if pm < 0:
		return
	var user := rest.substr(1, rest.find("!") - 1)
	var msg_at := rest.find(" :", pm)
	if msg_at < 0:
		return
	var msg := rest.substr(msg_at + 2).strip_edges()
	var display := str(tags.get("display-name", user)).replace("\\s", " ")
	if display == "":
		display = user
	var col := Color.from_string(str(tags.get("color", "")), Color(0.75, 0.6, 1.0)) if str(tags.get("color", "")) != "" else Color(0.75, 0.6, 1.0)
	handle(display, msg, col)


## Point d'entree commun (vrai chat ou tests).
func handle(user: String, msg: String, col := Color(0.75, 0.6, 1.0)) -> void:
	total_msgs += 1
	user = user.substr(0, 20)
	var low := msg.to_lower()
	var cmd := low.split(" ", false)[0] if low != "" else ""
	var arg := msg.substr(msg.find(" ") + 1).strip_edges() if msg.find(" ") > 0 else ""
	match cmd:
		"!prier", "!pray", "!prie", "!confess", "!confesse":
			_confess(user, arg)
		"!colere", "!colère", "!wrath", "!angry":
			votes["wrath"][user] = true
			votes["joy"].erase(user)
		"!joie", "!joy", "!happy":
			votes["joy"][user] = true
			votes["wrath"].erase(user)
		"!signe", "!sign", "!miracle":
			if not signs.has(user) and signs.size() < 6:
				signs.append(user)
		"!echo", "!idee", "!idée", "!idea":
			if arg.length() > 5:
				echo_idea.emit(user, arg.substr(0, 160))
		"!1", "!2", "!3":
			mission_votes[user] = int(cmd.substr(1)) - 1
		"!mission", "!m":
			if arg.is_valid_int() and int(arg) >= 1 and int(arg) <= 3:
				mission_votes[user] = int(arg) - 1
		"!amen", "!gg", "!alleluia", "!hallelujah":
			amens.append(Time.get_ticks_msec())
	recent.append([user, msg.substr(0, 90), col])
	if recent.size() > 7:
		recent.pop_front()
	chat.emit(user, msg, col)


func _confess(user: String, text: String) -> void:
	text = text.strip_edges().replace("\n", " ")
	if text.length() < 6 or used_users.has(user) or queue.size() >= MAX_QUEUE:
		return
	var low := text.to_lower()
	for w in blocklist:
		if low.contains(w):
			return
	used_users[user] = true
	queue.append({"user": user, "text": text.substr(0, MAX_LEN)})
	confession_added.emit(user)


# ------------------------------------------------------------- utilise par le bureau

func has_confession() -> bool:
	return not queue.is_empty()


func take_confession() -> Dictionary:
	return queue.pop_front() if not queue.is_empty() else {}


## Resultat du vote d'humeur depuis le dernier appel : "wrath", "joy" ou "".
func take_mood_vote() -> Array:
	var w: int = votes["wrath"].size()
	var j: int = votes["joy"].size()
	votes = {"wrath": {}, "joy": {}}
	if w + j < 2 or w == j:
		return ["", w, j]
	return ["wrath" if w > j else "joy", w, j]


func mission_tally() -> Array:
	var v := [0, 0, 0]
	for u in mission_votes:
		v[int(mission_votes[u])] += 1
	return v


func take_sign() -> String:
	return str(signs.pop_front()) if not signs.is_empty() else ""


## Vrai si au moins 4 !amen dans les 8 dernieres secondes (une seule fois).
func take_cheer() -> bool:
	var now := Time.get_ticks_msec()
	var keep := []
	for a in amens:
		if now - int(a) < 8000:
			keep.append(a)
	amens = keep
	if amens.size() >= 4:
		amens = []
		return true
	return false


func new_day() -> void:
	used_users = {}
