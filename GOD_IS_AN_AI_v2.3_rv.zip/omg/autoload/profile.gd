extends Node
## CARRIERE : experience, niveaux, titres, succes et cosmetiques debloquables.
## Sauvegarde : user://profile.cfg (sur chaque ordinateur).

signal unlocked(kind: String, id: String)   # kind = "ach" ou "item"

const PATH := "user://profile.cfg"

# id -> niveau requis (0 = debloque par un succes)
const HATS := {
	"": 1, "party": 2, "beanie": 3, "cowboy": 4, "propeller": 5, "chef": 6, "bowler": 7,
	"flower": 8, "tinfoil": 10, "viking": 12, "wizard": 14, "horns": 16, "mitre": 18,
	"crown": 20, "halo": 0,
}
# extras du visage : id -> niveau (0 = succes)
const EXTRAS := {"glasses": 3, "mustache": 5, "bowtie": 7, "googly": 0, "clown": 0, "freckles": 9}
# succes -> recompense (cosmetique)
const ACH_REWARD := {"week_clean": "halo", "slip": "googly", "fired": "clown", "satan_win": "horns", "hundred": "mitre"}
const ACHS := ["first_conv", "kid", "conf", "callback", "day_perfect", "week_clean", "fired", "rich",
	"fart", "slip", "hoops", "thief", "red", "viewer", "echo", "satan_win", "satan_caught", "weekly",
	"mass", "hundred", "helium", "shout", "barista", "slap", "bonk", "face", "snipe", "karaoke", "disco", "strike", "mission", "mission_fou", "mission25", "saboteur", "rewrite", "gerard"]

var xp := 0
var ach := {}            # id -> true
var items := {}          # cosmetiques debloques par succes
var hat := ""
var extras := {}         # id -> bool
var totals := {}         # compteurs a vie
var last_gain := 0
var look_seed := 0      # ton visage (garde d'une partie a l'autre)
var outfit := {}         # VESTIAIRE : ton employe et sa tenue complete (look de character.gd)

## Objets speciaux du vestiaire : "cle:valeur" -> condition ("lvl:N" ou "ach:id").
const LOCKS := {
	"hat:halo": "ach:week_clean", "hat:horns": "ach:satan_win", "hat:crown": "lvl:20", "hat:tinfoil": "lvl:6",
	"hat:tophat": "lvl:4", "wings:gold": "lvl:15", "wings:black": "lvl:8", "glasses:heart": "lvl:3",
	"glasses:star": "lvl:5", "shoes:bunny": "lvl:7", "hat:star": "lvl:9", "hat:antenna": "lvl:2",
	"wings:white": "ach:mission", "glasses:3d": "lvl:11",
}
var last_lvl_up := 0


func _ready() -> void:
	var cf := ConfigFile.new()
	if cf.load(PATH) == OK:
		xp = int(cf.get_value("p", "xp", 0))
		ach = cf.get_value("p", "ach", {})
		items = cf.get_value("p", "items", {})
		hat = str(cf.get_value("p", "hat", ""))
		extras = cf.get_value("p", "extras", {})
		totals = cf.get_value("p", "totals", {})
		look_seed = int(cf.get_value("p", "look_seed", 0))
		var o = cf.get_value("p", "outfit", {})
		outfit = o if typeof(o) == TYPE_DICTIONARY else {}
	if look_seed == 0:
		look_seed = randi() % 2000000000 + 1
		save()


func save() -> void:
	var cf := ConfigFile.new()
	cf.set_value("p", "xp", xp)
	cf.set_value("p", "ach", ach)
	cf.set_value("p", "items", items)
	cf.set_value("p", "hat", hat)
	cf.set_value("p", "extras", extras)
	cf.set_value("p", "totals", totals)
	cf.set_value("p", "look_seed", look_seed)
	cf.set_value("p", "outfit", outfit)
	cf.save(PATH)


# ------------------------------------------------------------- niveaux

static func level_for(x: int) -> int:
	var l := 1
	while 125 * (l + 1) * l <= x:
		l += 1
	return l


static func xp_for(l: int) -> int:
	return 125 * l * (l - 1)


func level() -> int:
	return level_for(xp)


func title() -> String:
	var t := Loc.list("career_titles")
	return str(t[clampi((level() - 1) / 2, 0, t.size() - 1)])


func progress() -> float:
	var l := level()
	var a := xp_for(l)
	var b := xp_for(l + 1)
	return clampf(float(xp - a) / float(maxi(1, b - a)), 0.0, 1.0)


func add_xp(n: int) -> void:
	var before := level()
	xp += maxi(0, n)
	last_gain += maxi(0, n)
	var after := level()
	if after > before:
		last_lvl_up = after
		for l in range(before + 1, after + 1):
			for h in HATS:
				if int(HATS[h]) == l:
					unlocked.emit("item", str(h))
			for e in EXTRAS:
				if int(EXTRAS[e]) == l:
					unlocked.emit("item", str(e))
	save()


# ------------------------------------------------------------- succes

func unlock(id: String) -> void:
	if ach.has(id) or not id in ACHS:
		return
	ach[id] = true
	xp += 150
	unlocked.emit("ach", id)
	if ACH_REWARD.has(id):
		items[ACH_REWARD[id]] = true
		unlocked.emit("item", str(ACH_REWARD[id]))
	save()


func count(key: String, n := 1) -> int:
	totals[key] = int(totals.get(key, 0)) + n
	var v := int(totals[key])
	match key:
		"conversions":
			if v >= 1:
				unlock("first_conv")
			if v >= 100:
				unlock("hundred")
		"hoops":
			if v >= 10:
				unlock("hoops")
		"red":
			if v >= 20:
				unlock("red")
		"coffee_ok":
			if v >= 10:
				unlock("barista")
		"missions":
			if v >= 25:
				unlock("mission25")
	save()
	return v


# ------------------------------------------------------------- cosmetiques

func has_item(id: String) -> bool:
	if HATS.has(id):
		var need := int(HATS[id])
		return items.has(id) if need == 0 else level() >= need
	if EXTRAS.has(id):
		var need2 := int(EXTRAS[id])
		return items.has(id) if need2 == 0 else level() >= need2
	return false


func unlocked_hats() -> Array:
	var out := []
	for h in HATS:
		if has_item(str(h)):
			out.append(str(h))
	return out


## Un objet du vestiaire est-il disponible ? (cle = "hat", valeur = "halo"...)
func outfit_ok(key: String, val: String) -> bool:
	var cond := str(LOCKS.get(key + ":" + val, ""))
	if cond == "":
		return true
	if cond.begins_with("lvl:"):
		return level() >= int(cond.substr(4))
	return ach.has(cond.substr(4))


func outfit_lock_text(key: String, val: String) -> String:
	var cond := str(LOCKS.get(key + ":" + val, ""))
	if cond.begins_with("lvl:"):
		return Loc.f("lk_need_lvl", [int(cond.substr(4))])
	if cond.begins_with("ach:"):
		return Loc.f("lk_need_ach", [Loc.t("ach_" + cond.substr(4))])
	return ""


## Ce que les autres voient sur ton avatar (envoye en co-op).
func cosmetics() -> Dictionary:
	return {"outfit": my_look()}


## Applique les cosmetiques recus a un « look » de personnage.
static func apply(look: Dictionary, cos: Dictionary) -> Dictionary:
	if cos.has("outfit") and typeof(cos["outfit"]) == TYPE_DICTIONARY and not (cos["outfit"] as Dictionary).is_empty():
		return preload("res://scripts/character.gd").normalize_look(cos["outfit"])
	if cos.is_empty():
		return look
	look["hat"] = str(cos.get("hat", look.get("hat", "")))
	return look


## Mon personnage (la tenue du vestiaire ; Ted par defaut).
func my_look() -> Dictionary:
	var C = preload("res://scripts/character.gd")
	if outfit.is_empty():
		var lk: Dictionary = C.preset("ted")
		lk["headset"] = true
		return lk
	var o: Dictionary = C.normalize_look(outfit)
	# objets verrouilles (profil copie d'un autre ordi...) : on les retire
	for k in ["hat", "wings", "glasses", "shoes"]:
		if not outfit_ok(k, str(o.get(k, ""))):
			o[k] = "" if k != "shoes" else "oxford"
	return o


func set_outfit(lk: Dictionary) -> void:
	outfit = lk.duplicate(true)
	save()


func reroll_face() -> void:
	look_seed = randi() % 2000000000 + 1
	save()


# ------------------------------------------------------------- fin de journee / semaine

func day_done(solved: int, quota: int) -> int:
	last_gain = 0
	last_lvl_up = 0
	var g := solved * 40 + (60 if solved >= quota else 0)
	if solved >= quota * 2 and quota > 0:
		unlock("day_perfect")
	add_xp(g)
	return g


func week_done(fired: bool, earned: int, strikes: int, weekly: bool) -> int:
	last_gain = 0
	last_lvl_up = 0
	if fired:
		unlock("fired")
		add_xp(100)
		return last_gain
	count("weeks")
	if strikes == 0:
		unlock("week_clean")
	if earned >= 15000:
		unlock("rich")
	if weekly:
		unlock("weekly")
	add_xp(300 + earned / 20)
	return last_gain
