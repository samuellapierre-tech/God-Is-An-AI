extends Node
## Etat d'une semaine de travail (une partie = 5 jours).
## Survit au rechargement de la scene : le menu et main.tscn le partagent.

var DAYS := 5
const QUOTAS := [2, 3, 3, 4, 5]
var SHIFT_SECONDS := 330.0
const MAX_STRIKES := 2

const MOODS := ["memes", "wifi", "audit", "midlife", "update", "openhouse", "hungry", "monday", "rush", "bighead", "squeaky"]

# id : [prix, type]   type = "power" (nouveau signe divin) ou "up" (amelioration)
const SHOP := {
	"frogs": [400, "power"],
	"cat": [350, "power"],
	"dream": [300, "power"],
	"jingle": [250, "power"],
	"turbo": [300, "up"],
	"jammer": [450, "up"],
	"sales": [400, "up"],
	"coffee": [200, "up"],
	"intern": [350, "up"],
	"second": [500, "up"],
}

var rng := RandomNumberGenerator.new()
var weekly := false
var week_key := ""

var day := 1
var wallet := 0
var earned := 0
var strikes := 0
var mood := ""
var owned := {}            # id -> true (second : nombre)
var converted := []        # fideles convertis (dictionnaires) pour rappels + gazette
var today := []            # convertis du jour : [{b, sold, headline}]
var gazette := []          # titres a afficher au debut du prochain jour
var fired := false
var finished := false

var stats := {}
var mission_news := []    # unes de la Gazette : missions reussies
var xp_days := {}         # journees deja comptees pour l'experience
var highlights := []      # moments forts de la semaine : {key, cap, day, img}
var best_quote := {}


func _ready() -> void:
	preload("res://scripts/believers.gd").load_mods()
	_write_mod_example()
	new_run(false)


func _write_mod_example() -> void:
	# exemple pour la communaute (cree une seule fois)
	var p := "user://mods/LISEZMOI_MODS.txt"
	if FileAccess.file_exists(p):
		return
	var f := FileAccess.open(p, FileAccess.WRITE)
	if f == null:
		return
	f.store_string("MODS GOD IS AN AI\n\nMets des fichiers .json dans ce dossier pour ajouter tes propres fideles et confessions.\n" +
		"Put .json files in this folder to add your own believers and confessions.\n\n" +
		"Exemple / example (mon_mod.json) :\n" +
		"{\n  \"fr\": {\n    \"shames\": [\"d'avoir mange le lunch de son coloc en lui disant que c'etait Dieu\"],\n" +
		"    \"first_m\": [\"Ti-Guy\"],\n    \"places\": [\"Chibougamau\"]\n  },\n" +
		"  \"en\": {\n    \"shames\": [\"replying 'you too' to a waiter who said enjoy your meal, 400 times\"]\n  }\n}\n\n" +
		"Listes / lists : first_m, first_f, last, places, shames, relations\n")


func new_run(is_weekly: bool, forced_seed := 0) -> void:
	weekly = is_weekly
	week_key = current_week_key()
	if weekly:
		rng.seed = hash("OHMYGOD-" + week_key)
	elif forced_seed != 0:
		rng.seed = forced_seed
	else:
		rng.randomize()
	day = 1
	wallet = 0
	earned = 0
	strikes = 0
	mood = ""
	owned = {}
	converted = []
	highlights = []
	xp_days = {}
	mission_news = []
	today = []
	gazette = []
	fired = false
	finished = false
	stats = {
		"calls": 0, "conversions": 0, "missed": 0, "hangups": 0, "max_expo": 0.0,
		"coffee_ok": 0, "coffee_bad": 0, "powers": 0, "red": 0, "rules_broken": 0,
		"longest": 0, "conferences": 0, "callbacks": 0, "sold": [],
	}
	best_quote = {"line": "", "who": "", "score": -1}
	roll_mood()


func current_week_key() -> String:
	var d := Time.get_date_dict_from_system()
	var unix := Time.get_unix_time_from_system()
	var week := int(floor((unix / 86400.0 + 3.0) / 7.0))   # semaines depuis 1970, debut lundi
	return "%d-S%d" % [int(d["year"]), week]


func quota() -> int:
	var q: int = QUOTAS[clamp(day - 1, 0, QUOTAS.size() - 1)]
	if mood == "openhouse":
		q += 1
	if Net.active and Net.count() > 1:
		q = int(ceil(float(q) * (1.0 + 0.6 * float(Net.count() - 1))))
	return q


func roll_mood() -> void:
	if day == 1:
		mood = "normal"
		return
	var m: String = MOODS[rng.randi() % MOODS.size()]
	var guard := 0
	while m == mood and guard < 10:
		m = MOODS[rng.randi() % MOODS.size()]
		guard += 1
	mood = m


func has(id: String) -> bool:
	return owned.has(id) and owned[id]


func can_buy(id: String) -> bool:
	if not SHOP.has(id):
		return false
	if id != "second" and has(id):
		return false
	return wallet >= int(SHOP[id][0])


func buy(id: String) -> bool:
	if not can_buy(id):
		return false
	wallet -= int(SHOP[id][0])
	if id == "second":
		owned["second"] = int(owned.get("second", 0)) + 1
	else:
		owned[id] = true
	return true


func owned_powers() -> Array:
	var out := []
	for id in ["frogs", "cat", "dream", "jingle"]:
		if has(id):
			out.append(id)
	return out


func add_money(v: int) -> void:
	wallet += v
	earned += v


func note_quote(line: String, who: String, score: int) -> void:
	if score > int(best_quote.get("score", -1)):
		best_quote = {"line": line, "who": who, "score": score}


## Fin du quart. Retourne "ok", "strike", "fired" ou "week_done".
func end_day(solved: int) -> String:
	var res := "ok"
	if solved < quota():
		strikes += 1
		res = "strike"
		if strikes >= MAX_STRIKES and int(owned.get("second", 0)) > 0:
			owned["second"] = int(owned["second"]) - 1
			strikes -= 1
			res = "saved"
	gazette = today.duplicate(true)
	for e in today:
		converted.append(e["b"])
	today = []
	if strikes >= MAX_STRIKES:
		fired = true
		finished = true
		return "fired"
	if day >= DAYS:
		finished = true
		return "week_done"
	return res


func next_day() -> void:
	day += 1
	roll_mood()


func pick_callback():
	if converted.is_empty():
		return null
	# on prefere rappeler ceux qui ont accompli une mission absurde (les consequences !)
	var mis := []
	for b in converted:
		if typeof(b) == TYPE_DICTIONARY and (b.has("mission_news") or b.has("promises")) and not b.has("cb_done"):
			mis.append(b)
	if not mis.is_empty() and rng.randf() < 0.75:
		var pick: Dictionary = mis[rng.randi() % mis.size()]
		pick["cb_done"] = true
		return pick
	return converted[rng.randi() % converted.size()]


func rank_title() -> String:
	if fired:
		return Loc.t("title_fired")
	if earned >= 25000:
		return Loc.t("title_4")
	if earned >= 14000:
		return Loc.t("title_3")
	if earned >= 6000:
		return Loc.t("title_2")
	return Loc.t("title_1")


func weekly_best() -> int:
	var cf := ConfigFile.new()
	if cf.load(Loc.SETTINGS_PATH) != OK:
		return 0
	return int(cf.get_value("weekly", current_week_key(), 0))


func save_weekly() -> bool:
	if not weekly:
		return false
	var cf := ConfigFile.new()
	cf.load(Loc.SETTINGS_PATH)
	var prev := int(cf.get_value("weekly", week_key, 0))
	if earned > prev:
		cf.set_value("weekly", week_key, earned)
		cf.save(Loc.SETTINGS_PATH)
		return true
	return false
