extends Node
## Gestionnaire de sons (pack audio genere par tools/gen_audio.py).
##   Sfx.play("sale")                     son 2D ponctuel
##   Sfx.play_at("step0", position)       son 3D ponctuel
##   Sfx.loop("amb", "amb_office", -8)    boucle nommee (Sfx.stop("amb"))
##   Sfx.loop_at("ring", "phone_ring", node3d)

const LOOPING := ["amb_office", "music_menu", "phone_ring", "typing", "heartbeat",
	"radio_lounge", "radio_organ", "radio_chip", "disco", "roll"]

var cache := {}
var loops := {}
var pool := []
var pool3d := []
var sfx_db := 0.0
var music_db := 0.0


func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	for i in 12:
		var p := AudioStreamPlayer.new()
		add_child(p)
		pool.append(p)


func stream(name: String) -> AudioStream:
	if cache.has(name):
		return cache[name]
	var path := "res://audio/%s.ogg" % name
	var s: AudioStream = null
	if ResourceLoader.exists(path):
		s = load(path)
	if s is AudioStreamOggVorbis:
		(s as AudioStreamOggVorbis).loop = name in LOOPING
	cache[name] = s
	return s


func play(name: String, db := 0.0, pitch := 1.0) -> void:
	var s := stream(name)
	if s == null:
		return
	for p in pool:
		var pl: AudioStreamPlayer = p
		if not pl.playing:
			pl.stream = s
			pl.volume_db = db + sfx_db
			pl.pitch_scale = pitch
			pl.play()
			return


func play_at(name: String, pos: Vector3, db := 0.0, pitch := 1.0) -> void:
	var s := stream(name)
	var scene := get_tree().current_scene
	if s == null or scene == null or not (scene is Node3D):
		return
	var p := AudioStreamPlayer3D.new()
	p.stream = s
	p.volume_db = db + sfx_db
	p.pitch_scale = pitch
	p.unit_size = 4.0
	p.max_distance = 40.0
	scene.add_child(p)
	p.global_position = pos
	p.finished.connect(p.queue_free)
	p.play()
	# filet de securite : certains pilotes audio ne signalent jamais la fin
	get_tree().create_timer(s.get_length() / maxf(0.1, pitch) + 1.0, false).timeout.connect(_free_id.bind(p.get_instance_id()))


func loop(key: String, name: String, db := 0.0, is_music := false) -> AudioStreamPlayer:
	stop(key)
	var s := stream(name)
	if s == null:
		return null
	var p := AudioStreamPlayer.new()
	p.stream = s
	p.volume_db = db + (music_db if is_music else sfx_db)
	if is_music:
		p.bus = "Music"
	add_child(p)
	p.play()
	loops[key] = p
	return p


func loop_at(key: String, name: String, parent: Node3D, db := 0.0, offset := 0.0) -> AudioStreamPlayer3D:
	stop(key)
	var s := stream(name)
	if s == null or parent == null:
		return null
	var p := AudioStreamPlayer3D.new()
	p.stream = s
	p.volume_db = db + sfx_db
	p.unit_size = 3.0
	p.max_distance = 30.0
	parent.add_child(p)
	p.play(offset)
	loops[key] = p
	return p


func set_loop_db(key: String, db: float) -> void:
	if loops.has(key) and is_instance_valid(loops[key]):
		loops[key].volume_db = db


func stop(key: String) -> void:
	if loops.has(key):
		var p = loops[key]
		if is_instance_valid(p):
			p.queue_free()
		loops.erase(key)


func stop_all() -> void:
	for k in loops.keys():
		stop(k)


func _free_id(id: int) -> void:
	var o := instance_from_id(id)
	if o != null and is_instance_valid(o) and o is Node:
		(o as Node).queue_free()
