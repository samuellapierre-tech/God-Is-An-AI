extends Node
## Outils de developpement : captures d'ecran automatiques et tests.
## Ne fait RIEN en jeu normal. S'active seulement avec des arguments :
##   godot -- --shot=/tmp/a.png --wait=3 --start --view=desk|center|coffee|board|call
## (utilise pour verifier le rendu sans ouvrir l'editeur)

var args := {}
var t := 0.0
var done := false
var prepared := false


func _ready() -> void:
	for a in OS.get_cmdline_user_args():
		var s := str(a).trim_prefix("--")
		var i := s.find("=")
		if i >= 0:
			args[s.substr(0, i)] = s.substr(i + 1)
		else:
			args[s] = "1"
	if args.is_empty():
		set_process(false)
		return
	process_mode = Node.PROCESS_MODE_ALWAYS
	if args.has("lang"):
		Loc.lang = str(args["lang"])
	if args.has("quality"):
		Loc.quality = int(args["quality"])


func _process(dt: float) -> void:
	t += dt
	var main := get_tree().current_scene
	if main == null:
		return
	if not prepared and t > 0.3 and main.has_method("dev_prepare"):
		prepared = true
		main.dev_prepare(args)
	if done:
		return
	if args.has("trace") and int(t / 20.0) != int((t - dt) / 20.0):
		print("TRACE t=", int(t), " nodes=", get_tree().get_node_count(), " objs=", Performance.get_monitor(Performance.OBJECT_COUNT), " mem=", int(Performance.get_monitor(Performance.MEMORY_STATIC) / 1048576.0), "Mo scene=", main.name, " jour=", Game.day)
		if args.has("census"):
			var c := {}
			_census(main, c)
			var ks := c.keys()
			ks.sort_custom(func(a, b): return c[a] > c[b])
			var line := "CENSUS "
			for k in ks.slice(0, 25):
				line += "%s=%d " % [k, c[k]]
			print(line)
	if t >= float(args.get("wait", "3")):
		done = true
		print("NODES ", get_tree().get_node_count(), "  DRAW CALLS ", RenderingServer.get_rendering_info(RenderingServer.RENDERING_INFO_TOTAL_DRAW_CALLS_IN_FRAME), "  OBJECTS ", RenderingServer.get_rendering_info(RenderingServer.RENDERING_INFO_TOTAL_OBJECTS_IN_FRAME), "  FPS ", Engine.get_frames_per_second())
		if args.has("shot"):
			await RenderingServer.frame_post_draw
			var img := get_viewport().get_texture().get_image()
			img.save_png(str(args["shot"]))
			print("SHOT ", args["shot"])
		get_tree().quit()


func _census(n: Node, c: Dictionary) -> void:
	for ch in n.get_children():
		var k: String = ch.get_class() + "@" + str(n.name).substr(0, 18)
		c[k] = int(c.get(k, 0)) + 1
		_census(ch, c)
