extends Node
## Integration Steam (facultative) : inviter ses amis en un clic, sans IP ni port.
##
## Fonctionne seulement si l'extension GodotSteam est installee dans le projet
## (AssetLib de Godot : « GodotSteam GDExtension » + « GodotSteam MultiplayerPeer »
## si elle est separee dans ta version) ET que Steam est ouvert.
## Sans GodotSteam, ce script ne fait rien et le jeu marche comme avant (IP).
##
## Tout passe par des appels dynamiques : le projet compile sans l'extension.
## APP_ID 480 = « Spacewar », l'app de test de Valve. Remplace-le par ton
## propre App ID quand ta page Steam sera creee (et dans steam_appid.txt).

signal changed
signal invite_accepted

const APP_ID := 480
const LOBBY_FRIENDS_ONLY := 1
const MAX_MEMBERS := 4

var st: Object = null            # le singleton « Steam » de GodotSteam
var ready_ok := false
var lobby_id := 0
var my_steam_id := 0
var persona := ""
var pending_join := 0
var status_text := ""


func _ready() -> void:
	if not Engine.has_singleton("Steam"):
		return
	st = Engine.get_singleton("Steam")
	OS.set_environment("SteamAppId", str(APP_ID))
	OS.set_environment("SteamGameId", str(APP_ID))
	var res = null
	if st.has_method("steamInitEx"):
		res = _callx("steamInitEx", {"app_id": APP_ID, "embed_callbacks": false, "retrieve_stats": false})
	elif st.has_method("steamInit"):
		res = _callx("steamInit", {"app_id": APP_ID, "embed_callbacks": false, "retrieve_stats": false})
	var ok := false
	if typeof(res) == TYPE_DICTIONARY:
		var code := int(res.get("status", -1))
		var verbal := str(res.get("verbal", "")).to_lower()
		ok = code == 0 or (code == 1 and (verbal.contains("active") or verbal.contains("success")))
	elif typeof(res) == TYPE_BOOL:
		ok = res
	if not ok and st.has_method("isSteamRunning"):
		ok = bool(st.call("isSteamRunning")) and st.has_method("getSteamID") and int(st.call("getSteamID")) != 0
	if not ok:
		print("Steam : non disponible (", res, ")")
		st = null
		return
	ready_ok = true
	my_steam_id = int(st.call("getSteamID"))
	persona = str(st.call("getPersonaName"))
	if Loc.player_name == "" or Loc.player_name == "JOUEUR":
		Loc.player_name = persona.to_upper().substr(0, 12)
	_sig("lobby_created", _on_lobby_created)
	_sig("lobby_joined", _on_lobby_joined)
	_sig("join_requested", _on_join_requested)
	_sig("lobby_join_requested", _on_join_requested)
	# lance via une invitation alors que le jeu etait ferme : +connect_lobby <id>
	var args := OS.get_cmdline_args()
	for i in args.size():
		if str(args[i]) == "+connect_lobby" and i + 1 < args.size():
			pending_join = int(args[i + 1])
	print("Steam : connecte en tant que ", persona)
	presence("menu")


func available() -> bool:
	return ready_ok and st != null


func can_p2p() -> bool:
	return available() and ClassDB.class_exists("SteamMultiplayerPeer")


func _process(_dt: float) -> void:
	if st == null:
		return
	st.call("run_callbacks")
	if pending_join != 0 and get_tree().current_scene != null and get_tree().current_scene.name == "Menu":
		var id := pending_join
		pending_join = 0
		join_lobby(id)


func _sig(name: String, cb: Callable) -> void:
	if st.has_signal(name) and not st.is_connected(name, cb):
		st.connect(name, cb)


## Appelle une methode de GodotSteam en s'adaptant a sa signature (elle change selon les versions).
func _callx(method: String, named: Dictionary, obj: Object = null) -> Variant:
	var o: Object = obj if obj != null else st
	for m in o.get_method_list():
		if str(m["name"]) != method:
			continue
		var args := []
		for a in m["args"]:
			var n := str(a["name"])
			if named.has(n):
				args.append(named[n])
			else:
				match int(a["type"]):
					TYPE_INT: args.append(0)
					TYPE_FLOAT: args.append(0.0)
					TYPE_BOOL: args.append(false)
					TYPE_STRING: args.append("")
					TYPE_ARRAY: args.append([])
					TYPE_DICTIONARY: args.append({})
					_: args.append(null)
		return o.callv(method, args)
	return o.call(method)


# ------------------------------------------------------------- presence (liste d'amis)

func presence(key: String, detail := "") -> void:
	if not available():
		return
	var txt := Loc.t("rp_" + key)
	if detail != "":
		txt += " " + detail
	st.call("setRichPresence", "status", txt)


# ------------------------------------------------------------- salon

func host_lobby() -> void:
	if not available():
		return
	status_text = Loc.t("steam_creating")
	changed.emit()
	st.call("createLobby", LOBBY_FRIENDS_ONLY, MAX_MEMBERS)


func _on_lobby_created(result = 0, id = 0, _a = null, _b = null) -> void:
	if int(result) != 1:
		status_text = Loc.t("steam_fail")
		changed.emit()
		return
	lobby_id = int(id)
	st.call("setLobbyJoinable", lobby_id, true)
	st.call("setLobbyData", lobby_id, "name", Loc.player_name)
	st.call("setLobbyData", lobby_id, "game", "ohmygod")
	if can_p2p():
		var peer: Object = ClassDB.instantiate("SteamMultiplayerPeer")
		var err = _callx("create_host", {"virtual_port": 0, "port": 0}, peer)
		if int(err) != OK:
			status_text = Loc.t("steam_fail")
			changed.emit()
			return
		Net.host_with_peer(Loc.player_name, peer as MultiplayerPeer)
	else:
		# pas de P2P Steam : on partage l'IP par le salon (il faut alors le port 7777 ouvert)
		if Net.host(Loc.player_name) != OK:
			status_text = Loc.t("steam_fail")
			changed.emit()
			return
		st.call("setLobbyData", lobby_id, "ip", Net._local_ips().split(",")[0].strip_edges())
	status_text = Loc.t("steam_hosting")
	changed.emit()
	invite()


func invite() -> void:
	if available() and lobby_id != 0:
		st.call("activateGameOverlayInviteDialog", lobby_id)


func _on_join_requested(id = 0, _friend = 0, _a = null, _b = null) -> void:
	# accepte depuis l'overlay Steam
	if get_tree().current_scene == null or get_tree().current_scene.name != "Menu":
		pending_join = int(id)
		return
	join_lobby(int(id))


func join_lobby(id: int) -> void:
	if not available():
		return
	status_text = Loc.t("steam_joining")
	invite_accepted.emit()
	changed.emit()
	st.call("joinLobby", id)


func _on_lobby_joined(id = 0, _perm = 0, _locked = false, response = 1) -> void:
	if int(response) != 1:
		status_text = Loc.t("steam_fail")
		changed.emit()
		return
	lobby_id = int(id)
	var owner := int(st.call("getLobbyOwner", lobby_id))
	if owner == my_steam_id:
		return     # c'est mon propre salon
	if can_p2p():
		var peer: Object = ClassDB.instantiate("SteamMultiplayerPeer")
		var err = _callx("create_client", {"steam_id": owner, "identity_remote": owner, "remote_steam_id": owner, "virtual_port": 0, "port": 0}, peer)
		if int(err) != OK:
			status_text = Loc.t("steam_fail")
			changed.emit()
			return
		Net.join_with_peer(Loc.player_name, peer as MultiplayerPeer)
	else:
		var ip := str(st.call("getLobbyData", lobby_id, "ip"))
		if ip != "":
			Net.join(Loc.player_name, ip)
	status_text = Loc.f("steam_joined", [str(st.call("getFriendPersonaName", owner))])
	changed.emit()


func leave_lobby() -> void:
	if available() and lobby_id != 0:
		st.call("leaveLobby", lobby_id)
	lobby_id = 0
	changed.emit()
