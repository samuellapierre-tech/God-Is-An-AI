extends Control
## Mini-jeu du terminal entre deux appels : "Chasse aux peches".
## Des peches apparaissent sur l'ecran, clique-les avant qu'ils disparaissent.

signal finished(score: int)

const DURATION := 20.0

var running := false
var left := 0.0
var spawn_t := 0.0
var score := 0
var targets := []
var info: Label


func _ready() -> void:
	mouse_filter = Control.MOUSE_FILTER_STOP
	clip_contents = true
	var bg := ColorRect.new()
	bg.color = Color(0.02, 0.01, 0.0, 0.92)
	bg.set_anchors_preset(Control.PRESET_FULL_RECT)
	bg.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(bg)
	info = Label.new()
	info.add_theme_font_override("font", Loc.font("term"))
	info.add_theme_font_size_override("font_size", 28)
	info.add_theme_color_override("font_color", Color(1.0, 0.6, 0.2))
	info.position = Vector2(12, 6)
	add_child(info)
	visible = false


func start() -> void:
	for tg in targets:
		if is_instance_valid(tg[0]):
			tg[0].queue_free()
	targets = []
	running = true
	visible = true
	left = DURATION
	spawn_t = 0.0
	score = 0


func stop() -> int:
	running = false
	visible = false
	for tg in targets:
		if is_instance_valid(tg[0]):
			tg[0].queue_free()
	targets = []
	return score


func _process(dt: float) -> void:
	if not running:
		return
	left -= dt
	spawn_t -= dt
	info.text = Loc.f("mg_info", [score, max(0, int(ceil(left)))])
	if spawn_t <= 0.0:
		spawn_t = randf_range(0.3, 0.6) * (0.75 if left < 8.0 else 1.0)
		_spawn()
	for tg in targets.duplicate():
		var b: Button = tg[0]
		if not is_instance_valid(b):
			targets.erase(tg)
			continue
		tg[1] = float(tg[1]) - dt
		b.modulate.a = clamp(float(tg[1]) / 0.4, 0.0, 1.0)
		b.position.y -= dt * 12.0
		if float(tg[1]) <= 0.0:
			b.queue_free()
			targets.erase(tg)
	if left <= 0.0:
		var s := stop()
		finished.emit(s)


func _spawn() -> void:
	var words := Loc.list("mg_sins")
	var b := Button.new()
	var good := randf() < 0.18
	b.text = str(Loc.pick("mg_virtues")) if good else str(words[randi() % words.size()])
	b.flat = false
	b.focus_mode = Control.FOCUS_NONE
	b.add_theme_font_override("font", Loc.font("title"))
	b.add_theme_font_size_override("font_size", randi_range(20, 30))
	var col := Color(0.5, 1.0, 0.55) if good else Color(1.0, 0.35, 0.25)
	b.add_theme_color_override("font_color", col)
	b.add_theme_color_override("font_hover_color", Color(1, 1, 1))
	var sb := StyleBoxFlat.new()
	sb.bg_color = Color(0.1, 0.03, 0.02, 0.85)
	sb.border_color = col
	sb.set_border_width_all(2)
	sb.set_content_margin_all(6)
	b.add_theme_stylebox_override("normal", sb)
	b.add_theme_stylebox_override("hover", sb)
	b.add_theme_stylebox_override("pressed", sb)
	add_child(b)
	var sz := size
	b.position = Vector2(randf_range(10, max(20.0, sz.x - 200.0)), randf_range(50, max(60.0, sz.y - 60.0)))
	b.pressed.connect(_hit.bind(b, good))
	targets.append([b, randf_range(1.0, 1.6)])


func _hit(b: Button, good: bool) -> void:
	if not running or not is_instance_valid(b):
		return
	if good:
		score = max(0, score - 2)
		Sfx.play("error", -10.0)
	else:
		score += 1
		Sfx.play("ui_click", -4.0, randf_range(1.2, 1.6))
	for tg in targets:
		if tg[0] == b:
			targets.erase(tg)
			break
	b.queue_free()
