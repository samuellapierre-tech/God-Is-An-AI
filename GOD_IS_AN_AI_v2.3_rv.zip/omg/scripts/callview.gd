extends SubViewport
## Appel video : on VOIT le fidele dans sa situation (en auto, au karaoke,
## chez le dentiste...). Il parle, reagit selon sa conviction, et les signes
## divins apparaissent pour vrai dans son decor.
##
##   var cv := CallView.new(); add_child(cv)
##   texture_rect.texture = cv.get_texture()
##   cv.start_call(believer_dict)  /  cv.line(text)  /  cv.set_conviction(c)
##   cv.power_fx("frogs")  /  cv.end_call(converted)

const Character := preload("res://scripts/character.gd")

var world_root: Node3D
var stage: Node3D
var cam: Camera3D
var key_light: OmniLight3D
var fill_light: DirectionalLight3D
var env: Environment
var people := []          # personnages a l'ecran
var extras := []          # personnages de decor (voisin, maman...)
var b := {}
var t := 0.0
var shake := 0.0
var flash := 0.0
var flash_col := Color.WHITE
var flash_rect: MeshInstance3D
var movers := []          # [node, vitesse, type]
var active := false
var cam_base := Vector3.ZERO
var call_id := 0


func _init() -> void:
	size = Vector2i(512, 384)
	own_world_3d = true
	transparent_bg = false
	render_target_update_mode = SubViewport.UPDATE_ALWAYS
	msaa_3d = Viewport.MSAA_2X


func _ready() -> void:
	world_root = Node3D.new()
	add_child(world_root)
	var we := WorldEnvironment.new()
	env = Environment.new()
	env.background_mode = Environment.BG_COLOR
	env.background_color = Color(0.05, 0.05, 0.06)
	env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	env.ambient_light_color = Color(0.6, 0.6, 0.65)
	env.ambient_light_energy = 0.45
	env.tonemap_mode = Environment.TONE_MAPPER_ACES
	env.glow_enabled = true
	env.glow_intensity = 0.6
	we.environment = env
	world_root.add_child(we)
	cam = Camera3D.new()
	cam.fov = 48
	world_root.add_child(cam)
	key_light = OmniLight3D.new()
	key_light.position = Vector3(-0.6, 1.5, -1.0)
	key_light.omni_range = 5.0
	key_light.light_energy = 1.4
	world_root.add_child(key_light)
	fill_light = DirectionalLight3D.new()
	fill_light.rotation_degrees = Vector3(-30, 160, 0)
	fill_light.light_energy = 0.5
	world_root.add_child(fill_light)
	# voile plein ecran pour les flashs (eclair, lumiere divine)
	flash_rect = MeshInstance3D.new()
	var qm := QuadMesh.new()
	qm.size = Vector2(4, 3)
	flash_rect.mesh = qm
	var fm := StandardMaterial3D.new()
	fm.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	fm.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	fm.albedo_color = Color(1, 1, 1, 0)
	fm.no_depth_test = true
	fm.render_priority = 100
	flash_rect.material_override = fm
	flash_rect.position = Vector3(0, 0, -0.3)
	flash_rect.rotation_degrees = Vector3(0, 180, 0)
	cam.add_child(flash_rect)
	_idle_screen()


# ------------------------------------------------------------- petites briques

func _m(c: Color, rough := 0.8, emit := 0.0) -> StandardMaterial3D:
	var m := StandardMaterial3D.new()
	m.albedo_color = c
	m.roughness = rough
	if emit > 0.0:
		m.emission_enabled = true
		m.emission = c
		m.emission_energy_multiplier = emit
	return m


func _box(pos: Vector3, sz: Vector3, c: Color, emit := 0.0, rot := Vector3.ZERO) -> MeshInstance3D:
	var mi := MeshInstance3D.new()
	var bm := BoxMesh.new()
	bm.size = sz
	mi.mesh = bm
	mi.material_override = _m(c, 0.8, emit)
	mi.position = pos
	mi.rotation_degrees = rot
	stage.add_child(mi)
	return mi


func _cyl(pos: Vector3, r: float, h: float, c: Color, emit := 0.0, rot := Vector3.ZERO, rt := -1.0) -> MeshInstance3D:
	var mi := MeshInstance3D.new()
	var cm := CylinderMesh.new()
	cm.top_radius = r if rt < 0.0 else rt
	cm.bottom_radius = r
	cm.height = h
	cm.radial_segments = 16
	mi.mesh = cm
	mi.material_override = _m(c, 0.6, emit)
	mi.position = pos
	mi.rotation_degrees = rot
	stage.add_child(mi)
	return mi


func _ball(pos: Vector3, r: float, c: Color, emit := 0.0, par: Node3D = null) -> MeshInstance3D:
	var mi := MeshInstance3D.new()
	var sm := SphereMesh.new()
	sm.radius = r
	sm.height = r * 2.0
	sm.radial_segments = 12
	sm.rings = 6
	mi.mesh = sm
	mi.material_override = _m(c, 0.7, emit)
	mi.position = pos
	(par if par != null else stage).add_child(mi)
	return mi


func _torus(pos: Vector3, r_in: float, r_out: float, c: Color, emit := 0.0, rot := Vector3.ZERO) -> MeshInstance3D:
	var mi := MeshInstance3D.new()
	var tm := TorusMesh.new()
	tm.inner_radius = r_in
	tm.outer_radius = r_out
	tm.rings = 24
	tm.ring_segments = 8
	mi.mesh = tm
	mi.material_override = _m(c, 0.5, emit)
	mi.position = pos
	mi.rotation_degrees = rot
	stage.add_child(mi)
	return mi


func _text(pos: Vector3, txt: String, sz: int, c: Color) -> Label3D:
	var l := Label3D.new()
	l.text = txt
	l.font_size = sz
	l.modulate = c
	l.position = pos
	l.rotation_degrees = Vector3(0, 180, 0)
	l.font = Loc.font("title")
	l.outline_size = 0
	stage.add_child(l)
	return l


func _light(pos: Vector3, c: Color, e: float, rng_v := 4.0) -> OmniLight3D:
	var l := OmniLight3D.new()
	l.position = pos
	l.light_color = c
	l.light_energy = e
	l.omni_range = rng_v
	stage.add_child(l)
	return l


func _particles(pos: Vector3, mesh: Mesh, amount: int, life: float, vel: Vector3, spread_box: Vector3, grav := Vector3.ZERO, one_shot := false) -> GPUParticles3D:
	var p := GPUParticles3D.new()
	var pm := ParticleProcessMaterial.new()
	pm.emission_shape = ParticleProcessMaterial.EMISSION_SHAPE_BOX
	pm.emission_box_extents = spread_box
	pm.direction = vel.normalized() if vel.length() > 0.0 else Vector3.UP
	pm.spread = 15.0
	pm.initial_velocity_min = vel.length() * 0.7
	pm.initial_velocity_max = vel.length() * 1.2
	pm.gravity = grav
	pm.angular_velocity_min = -180.0
	pm.angular_velocity_max = 180.0
	p.process_material = pm
	p.draw_pass_1 = mesh
	p.amount = amount
	p.lifetime = life
	p.one_shot = one_shot
	p.explosiveness = 0.6 if one_shot else 0.0
	p.position = pos
	p.local_coords = false
	stage.add_child(p)
	return p


# ------------------------------------------------------------- appels

func _clear() -> void:
	if stage != null:
		stage.queue_free()
	stage = Node3D.new()
	world_root.add_child(stage)
	people = []
	extras = []
	movers = []


func _idle_screen() -> void:
	# ecran d'attente : logo qui tourne
	_clear()
	active = false
	env.background_color = Color(0.03, 0.025, 0.02)
	cam.position = Vector3(0, 0.0, -2.0)
	cam.look_at(Vector3.ZERO, Vector3.UP)
	cam_base = cam.position
	var r := _torus(Vector3.ZERO, 0.42, 0.5, Color(1.0, 0.6, 0.2), 2.5, Vector3(90, 0, 0))
	movers.append([r, 1.0, "spin"])
	var r2 := _torus(Vector3.ZERO, 0.6, 0.64, Color(1.0, 0.5, 0.15), 1.5, Vector3(90, 0, 0))
	movers.append([r2, -0.6, "spin"])
	_ball(Vector3.ZERO, 0.16, Color(1.0, 0.85, 0.5), 4.0)


func start_call(believer: Dictionary) -> void:
	b = believer
	call_id += 1
	cam_roll = 0.0
	cam_zoom = 0.0
	_clear()
	active = true
	var rng := RandomNumberGenerator.new()
	rng.seed = int(b.get("look_seed", 1))
	var conf := str(b.get("kind", "")) == "conference"
	var main_c := _person(rng, b, Vector3(-0.33 if conf else 0.0, 0, 0))
	people.append(main_c)
	if conf:
		var o: Dictionary = b["other"]
		var r2 := RandomNumberGenerator.new()
		r2.seed = int(o.get("look_seed", 2))
		var c2 := _person(r2, o, Vector3(0.33, 0, 0))
		c2.rotation.y = 0.25
		main_c.rotation.y = -0.25
		people.append(c2)
		c2.set_emotion("angry")
	cam.position = Vector3(0, 0.98, -1.55 if not conf else -1.95)
	cam.look_at(Vector3(0, 0.84, 0), Vector3.UP)
	cam_base = cam.position
	_backdrop(str(b.get("sit_id", "zoom")))
	set_conviction(int(b.get("start", 0)))


func _person(rng: RandomNumberGenerator, info: Dictionary, pos: Vector3) -> Node3D:
	var c := Character.new()
	stage.add_child(c)
	var lk := Character.random_look(rng, {"fem": bool(info.get("fem", false)), "age": int(info.get("age", 40))})
	c.build(lk, "bust")
	c.position = pos
	c.rotation.y = 0.0
	c.look_target = cam
	return c


func line(text: String) -> void:
	if people.is_empty():
		return
	var secs: float = clamp(float(text.length()) * 0.055, 1.0, 7.0)
	if people.size() > 1 and text.find("/") >= 0:
		people[0].say(secs * 0.5)
		people[1].say(secs)
	else:
		people[0].say(secs)


func set_conviction(c: int) -> void:
	b["_conv"] = c
	var pers := str(b.get("pers", ""))
	var e := "neutral"
	if c < 20:
		match pers:
			"angry", "lawyer":
				e = "fury"
			"anxious", "shy", "kid":
				e = "cry"
			"skeptic":
				e = "angry"
			_:
				e = "sad"
	elif c < 45:
		e = "worried"
	elif c < 70:
		e = "neutral" if pers != "naive" else "happy"
	elif c < 88:
		e = "happy"
	else:
		e = "love"
	for i in people.size():
		if i == 1 and c < 60:
			people[i].set_emotion("fury" if c < 25 else "angry")
		else:
			people[i].set_emotion(e)


func end_call(converted: bool) -> void:
	if converted:
		for p in people:
			p.set_emotion("laugh")
			p.emote("dance")
		_fx_flash(Color(1.0, 0.85, 0.4), 0.6)
		_confetti()
	else:
		_fx_flash(Color(0.1, 0.1, 0.1), 1.0)
	var my_id := call_id
	await get_tree().create_timer(2.5).timeout
	if my_id != call_id:
		return
	_idle_screen()


func hang_up() -> void:
	call_id += 1
	_fx_flash(Color(0, 0, 0), 1.0)
	_idle_screen()


# ------------------------------------------------------------- decors

func _backdrop(id: String) -> void:
	var dark := Color(0.05, 0.05, 0.06)
	match id:
		"car":
			env.background_color = Color(0.02, 0.03, 0.08)
			_box(Vector3(0, 0.55, 0.35), Vector3(0.9, 1.1, 0.25), Color(0.18, 0.16, 0.15))
			_box(Vector3(0, 1.15, 0.33), Vector3(0.45, 0.25, 0.22), Color(0.2, 0.18, 0.17))
			_torus(Vector3(0.0, 0.42, -0.55), 0.17, 0.2, Color(0.08, 0.08, 0.08), 0.0, Vector3(70, 0, 0))
			for i in 6:
				var st := _box(Vector3(1.4, 1.2 + randf() * 0.4, 2.0 + float(i) * 1.2), Vector3(0.08, 0.08, 0.6), Color(1.0, 0.7, 0.3), 6.0)
				movers.append([st, 5.0, "road"])
			_light(Vector3(0.8, 1.2, 0.2), Color(1.0, 0.6, 0.3), 1.2)
			_box(Vector3(0.65, 1.0, 0.0), Vector3(0.05, 1.0, 1.4), Color(0.1, 0.12, 0.2, 1.0))
		"closet":
			env.background_color = Color(0.04, 0.03, 0.03)
			_box(Vector3(0, 1.3, 0.55), Vector3(1.8, 0.03, 0.03), Color(0.6, 0.6, 0.6))
			for i in 9:
				var c := Color.from_hsv(randf(), 0.5, 0.55)
				_box(Vector3(-0.85 + float(i) * 0.21, 0.85, 0.6 + randf() * 0.1), Vector3(0.18, 0.85, 0.12), c, 0.0, Vector3(0, randf_range(-15, 15), 0))
			_light(Vector3(0.0, 1.6, -0.2), Color(1.0, 0.85, 0.6), 0.6, 2.5)
			key_light.light_energy = 0.5
		"karaoke":
			env.background_color = Color(0.12, 0.02, 0.18)
			for i in 5:
				var n := _box(Vector3(-1.0 + float(i) * 0.5, 0.4 + float(i % 2) * 0.9, 1.0), Vector3(0.05, 1.6, 0.05), Color.from_hsv(0.8 + float(i) * 0.05, 0.9, 1.0), 4.0)
				movers.append([n, 2.0 + float(i), "pulse"])
			var mic := _cyl(Vector3(0.12, 0.58, -0.28), 0.03, 0.22, Color(0.15, 0.15, 0.15), 0.0, Vector3(-60, 0, 0))
			_ball(mic.position + Vector3(0, 0.08, -0.06), 0.045, Color(0.5, 0.5, 0.55))
			var sp := _light(Vector3(0, 1.8, 0.4), Color(1.0, 0.3, 0.9), 2.0, 4.0)
			movers.append([sp, 1.0, "disco"])
			_text(Vector3(0, 1.45, 0.95), "KARAOKÉ", 64, Color(1.0, 0.5, 0.9))
		"plane":
			env.background_color = Color(0.5, 0.55, 0.6)
			_box(Vector3(0, 0.8, 0.5), Vector3(1.4, 1.8, 0.05), Color(0.78, 0.78, 0.75))
			_cyl(Vector3(0.45, 1.05, 0.47), 0.17, 0.03, Color(0.4, 0.65, 1.0), 2.0, Vector3(90, 0, 0))
			_torus(Vector3(0.45, 1.05, 0.46), 0.16, 0.2, Color(0.6, 0.6, 0.6), 0.0, Vector3(90, 0, 0))
			_box(Vector3(-0.4, 1.3, 0.46), Vector3(0.3, 0.12, 0.02), Color(1.0, 0.85, 0.3), 2.0)
			movers.append([cam, 1.0, "turbulence"])
		"tiktok":
			env.background_color = Color(0.08, 0.06, 0.1)
			_torus(Vector3(0, 0.95, 0.7), 0.42, 0.48, Color(1.0, 1.0, 1.0), 5.0, Vector3(90, 0, 0))
			_text(Vector3(0.5, 1.28, -0.5), "LIVE  14.2K", 40, Color(1.0, 0.2, 0.3))
			var qm := SphereMesh.new()
			qm.radius = 0.03
			qm.height = 0.06
			var hm := StandardMaterial3D.new()
			hm.albedo_color = Color(1.0, 0.25, 0.4)
			hm.emission_enabled = true
			hm.emission = Color(1.0, 0.2, 0.4)
			hm.emission_energy_multiplier = 2.0
			qm.material = hm
			_particles(Vector3(0.45, 0.3, -0.3), qm, 18, 2.5, Vector3(0, 0.5, 0), Vector3(0.05, 0.05, 0.05))
		"zoom":
			env.background_color = Color(0.25, 0.22, 0.2)
			_box(Vector3(0, 0.9, 0.7), Vector3(2.4, 2.0, 0.05), Color(0.62, 0.58, 0.5))
			for r in 3:
				_box(Vector3(-0.55, 0.6 + float(r) * 0.32, 0.6), Vector3(0.6, 0.03, 0.2), Color(0.35, 0.22, 0.12))
				for k in 6:
					_box(Vector3(-0.8 + float(k) * 0.09, 0.69 + float(r) * 0.32, 0.6), Vector3(0.06, 0.16, 0.14), Color.from_hsv(randf(), 0.5, 0.5))
			_box(Vector3(0.55, 1.15, 0.66), Vector3(0.35, 0.28, 0.02), Color(0.3, 0.4, 0.3))
			_ball(Vector3(0.7, 0.55, 0.5), 0.15, Color(0.25, 0.5, 0.25))
		"liquor":
			env.background_color = Color(0.85, 0.88, 0.9)
			for r in 4:
				_box(Vector3(0, 0.3 + float(r) * 0.36, 0.7), Vector3(2.2, 0.03, 0.3), Color(0.5, 0.5, 0.5))
				for k in 14:
					var bc: Color = [Color(0.3, 0.1, 0.15), Color(0.6, 0.45, 0.1), Color(0.2, 0.4, 0.2), Color(0.8, 0.8, 0.7)][randi() % 4]
					_cyl(Vector3(-1.0 + float(k) * 0.15, 0.42 + float(r) * 0.36, 0.7), 0.035, 0.2, bc)
			_box(Vector3(0, 1.75, 0.3), Vector3(1.6, 0.04, 0.12), Color(1, 1, 1), 4.0)
		"wedding":
			env.background_color = Color(0.9, 0.86, 0.82)
			var arch := _torus(Vector3(0, 0.8, 0.7), 0.85, 0.92, Color(0.95, 0.95, 0.92), 0.0, Vector3(90, 0, 0))
			arch.scale = Vector3(1, 1, 1)
			for i in 16:
				var a := PI * float(i) / 15.0
				_ball(Vector3(cos(a) * 0.88, 0.8 + sin(a) * 0.88, 0.66), 0.07, Color.from_hsv(0.95 + randf() * 0.08, 0.5, 1.0))
			_cyl(Vector3(-0.7, 0.4, 0.3), 0.03, 0.25, Color(1, 0.95, 0.85))
			_light(Vector3(-0.7, 0.6, 0.3), Color(1.0, 0.7, 0.4), 0.8, 2.0)
		"spa":
			env.background_color = Color(0.35, 0.25, 0.18)
			for i in 9:
				_box(Vector3(-1.2 + float(i) * 0.3, 0.9, 0.7), Vector3(0.28, 2.0, 0.05), Color(0.55, 0.38, 0.22).darkened(randf() * 0.2))
			var qm2 := SphereMesh.new()
			qm2.radius = 0.12
			qm2.height = 0.24
			var stm := StandardMaterial3D.new()
			stm.albedo_color = Color(1, 1, 1, 0.12)
			stm.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
			stm.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
			qm2.material = stm
			_particles(Vector3(0, 0.1, -0.2), qm2, 24, 4.0, Vector3(0, 0.15, 0), Vector3(0.8, 0.1, 0.3))
			if not people.is_empty():
				_ball(Vector3(0, 0.32, 0), 0.2, Color(1, 1, 1), 0.0, people[0].head)
		"dentist":
			env.background_color = Color(0.6, 0.8, 0.8)
			_box(Vector3(0, 0.9, 0.7), Vector3(2.4, 2.0, 0.05), Color(0.7, 0.88, 0.85))
			_cyl(Vector3(0.2, 1.45, -0.35), 0.14, 0.06, Color(1, 1, 0.9), 5.0, Vector3(-60, 0, 0))
			_light(Vector3(0.2, 1.4, -0.4), Color(1, 1, 0.95), 2.0, 2.5)
			_cyl(Vector3(-0.25, 0.75, -0.35), 0.01, 0.2, Color(0.8, 0.8, 0.85), 0.0, Vector3(0, 0, 60))
			if not people.is_empty():
				people[0].set_emotion("shock")
		"dogs":
			env.background_color = Color(0.55, 0.75, 0.95)
			_box(Vector3(0, -0.05, 1.5), Vector3(6, 0.1, 4), Color(0.3, 0.55, 0.25))
			for i in 4:
				_ball(Vector3(-1.2 + float(i) * 0.8, 1.0 + randf() * 0.3, 1.8), 0.4, Color(0.2, 0.45, 0.2))
			for i in 6:
				var dg := Node3D.new()
				dg.position = Vector3(-0.8 + float(i) * 0.32, 0.12, 0.5 + randf() * 0.4)
				stage.add_child(dg)
				var dc := Color.from_hsv(0.08, 0.5, randf_range(0.2, 0.9))
				_ball(Vector3.ZERO, 0.11, dc, 0.0, dg)
				_ball(Vector3(0, 0.1, -0.1), 0.07, dc, 0.0, dg)
				movers.append([dg, 3.0 + randf() * 3.0, "hop"])
		"mom":
			env.background_color = Color(0.85, 0.8, 0.7)
			_box(Vector3(0, 0.9, 0.8), Vector3(2.4, 2.0, 0.05), Color(0.95, 0.9, 0.75))
			for k in 4:
				_box(Vector3(-0.9 + float(k) * 0.45, 1.4, 0.7), Vector3(0.4, 0.4, 0.15), Color(0.6, 0.4, 0.25))
			_box(Vector3(0.9, 0.7, 0.6), Vector3(0.5, 1.6, 0.4), Color(0.9, 0.9, 0.92))
			var rng := RandomNumberGenerator.new()
			rng.seed = int(b.get("look_seed", 3)) + 99
			var mom := Character.new()
			stage.add_child(mom)
			mom.build(Character.random_look(rng, {"fem": true, "age": 74}), "bust")
			mom.position = Vector3(0.62, 0.0, 0.55)
			mom.rotation.y = 0.4
			mom.scale = Vector3(0.8, 0.8, 0.8)
			mom.set_emotion("shock")
			mom.look_target = cam
			extras.append(mom)
		"bingo":
			env.background_color = Color(0.4, 0.38, 0.3)
			_box(Vector3(0, 1.1, 0.75), Vector3(1.6, 0.9, 0.05), Color(0.1, 0.25, 0.15))
			var nums := ""
			for i in 3:
				nums += "B%d  I%d  N%d  G%d  O%d\n" % [randi_range(1, 15), randi_range(16, 30), randi_range(31, 45), randi_range(46, 60), randi_range(61, 75)]
			_text(Vector3(0, 1.1, 0.72), nums.strip_edges(), 40, Color(1.0, 0.9, 0.4))
			_box(Vector3(0, 0.35, -0.3), Vector3(1.6, 0.04, 0.5), Color(0.75, 0.72, 0.65))
		"night":
			env.background_color = Color(0.01, 0.015, 0.04)
			key_light.light_color = Color(0.5, 0.6, 1.0)
			key_light.light_energy = 0.7
			_box(Vector3(0.5, 1.2, 0.75), Vector3(0.5, 0.6, 0.02), Color(0.4, 0.5, 0.9), 1.5)
			var lump := _ball(Vector3(-0.6, 0.15, 0.4), 0.35, Color(0.3, 0.3, 0.5))
			lump.scale = Vector3(1.4, 0.6, 1.0)
			movers.append([lump, 0.8, "breathe"])
		_:
			env.background_color = dark
	if id != "night":
		key_light.light_color = Color(1.0, 0.95, 0.88)
		key_light.light_energy = 1.4 if id != "closet" else 0.5


# ------------------------------------------------------------- signes divins

func power_fx(id: String) -> void:
	if id.begins_with("gag_"):
		gag(id.substr(4))
		return
	shake = 0.4
	match id:
		"sky", "0", "god_yes":
			_fx_flash(Color(1.0, 0.85, 0.4), 0.9)
			var beam := _cyl(Vector3(0, 1.5, 0.2), 0.35, 4.0, Color(1.0, 0.85, 0.4), 3.0, Vector3.ZERO, 0.6)
			(beam.material_override as StandardMaterial3D).transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
			(beam.material_override as StandardMaterial3D).albedo_color.a = 0.35
			movers.append([beam, 0.0, "fade"])
			_sparkles(Color(1.0, 0.9, 0.5))
		"coincidence", "1":
			_fx_flash(Color(0.6, 1.0, 0.7), 0.5)
			for i in 6:
				var d := _box(Vector3(randf_range(-0.6, 0.6), 1.6 + randf(), randf_range(-0.2, 0.4)), Vector3(0.08, 0.08, 0.08), Color(0.95, 0.95, 0.95))
				movers.append([d, 1.0, "fall_spin"])
		"witness", "2":
			var rng := RandomNumberGenerator.new()
			rng.randomize()
			var w := Character.new()
			stage.add_child(w)
			w.build(Character.random_look(rng), "bust")
			w.position = Vector3(0.6, 0.0, 0.35)
			w.rotation.y = 0.3
			w.set_emotion("happy")
			w.say(3.0)
			w.look_target = cam
			extras.append(w)
		"smite", "3":
			var rng2 := RandomNumberGenerator.new()
			rng2.randomize()
			var n := Character.new()
			stage.add_child(n)
			n.build(Character.random_look(rng2), "bust")
			n.position = Vector3(-0.65, 0.0, 0.6)
			n.rotation.y = -0.3
			n.scale = Vector3(0.85, 0.85, 0.85)
			n.set_emotion("shock")
			extras.append(n)
			movers.append([n, 0.0, "smitten"])
			_fx_flash(Color(0.9, 0.95, 1.0), 1.0)
		"frogs":
			var fm := SphereMesh.new()
			fm.radius = 0.04
			fm.height = 0.06
			var mat := StandardMaterial3D.new()
			mat.albedo_color = Color(0.3, 0.8, 0.2)
			fm.material = mat
			var p := _particles(Vector3(0, 2.0, 0.1), fm, 60, 2.0, Vector3(0, -0.5, 0), Vector3(1.0, 0.1, 0.5), Vector3(0, -4.0, 0))
			movers.append([p, 0.0, "stop_later"])
		"cat":
			var cat := Node3D.new()
			cat.position = Vector3(0.28, 0.62, 0.0)
			stage.add_child(cat)
			var cc := Color(0.95, 0.55, 0.2)
			_ball(Vector3.ZERO, 0.09, cc, 0.0, cat)
			var hd := _ball(Vector3(0, 0.1, -0.04), 0.07, cc, 0.0, cat)
			for sx in [-1.0, 1.0]:
				var ear := MeshInstance3D.new()
				var em := CylinderMesh.new()
				em.top_radius = 0.0
				em.bottom_radius = 0.025
				em.height = 0.05
				ear.mesh = em
				ear.material_override = _m(cc)
				ear.position = Vector3(sx * 0.035, 0.06, 0)
				hd.add_child(ear)
				_ball(Vector3(sx * 0.025, 0.01, -0.06), 0.012, Color(0.1, 0.3, 0.1), 1.0, hd)
			var bub := _text(Vector3(0.62, 1.08, 0.25), Loc.t("cat_says"), 22, Color(1, 1, 1))
			bub.pixel_size = 0.003
			bub.outline_size = 8
			bub.outline_modulate = Color(0, 0, 0)
		"dream":
			env.background_color = Color(0.25, 0.12, 0.4)
			_sparkles(Color(0.7, 0.5, 1.0))
			for i in 5:
				var cl := _ball(Vector3(randf_range(-1, 1), randf_range(0.8, 1.5), 0.6), 0.25, Color(0.9, 0.85, 1.0), 0.6)
				cl.scale = Vector3(1.6, 0.8, 1.0)
				movers.append([cl, 0.2, "drift"])
		"jingle":
			for i in 8:
				var note := Node3D.new()
				note.position = Vector3(randf_range(-0.6, 0.6), randf_range(0.6, 1.3), -0.2)
				stage.add_child(note)
				_ball(Vector3.ZERO, 0.03, Color(1.0, 0.9, 0.2), 2.0, note)
				var stem := MeshInstance3D.new()
				var sbm := BoxMesh.new()
				sbm.size = Vector3(0.008, 0.09, 0.008)
				stem.mesh = sbm
				stem.material_override = _m(Color(1.0, 0.9, 0.2), 0.5, 2.0)
				stem.position = Vector3(0.025, 0.045, 0)
				note.add_child(stem)
				movers.append([note, 1.0 + randf(), "float_up"])
		"god_no":
			_fx_flash(Color(1.0, 0.1, 0.05), 0.8)
			shake = 0.8
	if not people.is_empty():
		people[0].set_emotion("shock")
		await get_tree().create_timer(1.2).timeout
		if active:
			set_conviction(int(b.get("_conv", 0)))


# ------------------------------------------------------------- gags de webcam

var cam_roll := 0.0
var _zoom_v := 0.0
var cam_zoom := 0.0
var lens := []


## Moments de webcam ridicules : telephone a l'envers, nez sur l'objectif,
## filtre de chien coince, image figee, eternuement sur la camera.
func gag(id: String) -> void:
	if people.is_empty():
		return
	var my_id := call_id
	var p0 = people[0]
	match id:
		"upside":
			cam_roll = PI
			_gag_end(my_id, 4.5, "roll")
		"nose":
			cam_zoom = 1.0
			p0.say(2.0)
			_gag_end(my_id, 3.5, "zoom")
		"filter":
			var hd: Node3D = p0.head
			if hd == null:
				return
			var brown := _m(Color(0.45, 0.28, 0.15), 0.9)
			var pink := _m(Color(1.0, 0.5, 0.6), 0.6)
			for sx in [-1.0, 1.0]:
				var ear := MeshInstance3D.new()
				var cm := CapsuleMesh.new()
				cm.radius = 0.045
				cm.height = 0.22
				ear.mesh = cm
				ear.material_override = brown
				ear.position = Vector3(sx * 0.17, 0.27, 0.0)
				ear.rotation_degrees = Vector3(0, 0, sx * 35.0)
				hd.add_child(ear)
			var nose := MeshInstance3D.new()
			var sm := SphereMesh.new()
			sm.radius = 0.028
			sm.height = 0.045
			nose.mesh = sm
			nose.material_override = _m(Color(0.05, 0.05, 0.05), 0.3)
			nose.position = Vector3(0, 0.0, -0.2)
			hd.add_child(nose)
			var tongue := MeshInstance3D.new()
			var tm := BoxMesh.new()
			tm.size = Vector3(0.045, 0.05, 0.01)
			tongue.mesh = tm
			tongue.material_override = pink
			tongue.position = Vector3(0, -0.115, -0.185)
			hd.add_child(tongue)
		"freeze":
			for p in people:
				p.process_mode = Node.PROCESS_MODE_DISABLED
			var tx := _text(Vector3(0, 0.25, -0.6), "CONNEXION INSTABLE" if Loc.lang == "fr" else "UNSTABLE CONNECTION", 40, Color(1, 0.3, 0.3))
			movers.append([tx, 0.0, "blink"])
			_gag_end(my_id, 3.0, "freeze", tx)
		"sneeze":
			p0.set_emotion("shock")
			await get_tree().create_timer(0.6).timeout
			if my_id != call_id:
				return
			_fx_flash(Color(0.7, 0.9, 0.6), 0.5)
			shake = 0.6
			for k in 9:
				var d := _ball(Vector3(randf_range(-0.25, 0.25), 0.78 + randf_range(-0.15, 0.15), cam.position.z + 0.12), randf_range(0.008, 0.025), Color(0.7, 0.85, 0.55, 0.8))
				(d.material_override as StandardMaterial3D).transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
				lens.append(d)
			_gag_end(my_id, 5.0, "lens")


func _gag_end(my_id: int, secs: float, what: String, node: Node = null) -> void:
	await get_tree().create_timer(secs).timeout
	if my_id != call_id:
		return
	match what:
		"roll":
			cam_roll = 0.0
		"zoom":
			cam_zoom = 0.0
		"freeze":
			for p in people:
				if is_instance_valid(p):
					p.process_mode = Node.PROCESS_MODE_INHERIT
			if node != null and is_instance_valid(node):
				node.queue_free()
		"lens":
			for d in lens:
				if is_instance_valid(d):
					d.queue_free()
			lens = []


func _sparkles(c: Color) -> void:
	var sm := SphereMesh.new()
	sm.radius = 0.012
	sm.height = 0.024
	var mat := StandardMaterial3D.new()
	mat.albedo_color = c
	mat.emission_enabled = true
	mat.emission = c
	mat.emission_energy_multiplier = 4.0
	mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	sm.material = mat
	var p := _particles(Vector3(0, 0.8, 0), sm, 50, 1.5, Vector3(0, 0.4, 0), Vector3(0.6, 0.5, 0.3), Vector3(0, 0.2, 0))
	movers.append([p, 0.0, "stop_later"])


func _confetti() -> void:
	var bm := BoxMesh.new()
	bm.size = Vector3(0.03, 0.03, 0.005)
	var mat := StandardMaterial3D.new()
	mat.albedo_color = Color(1.0, 0.8, 0.3)
	mat.vertex_color_use_as_albedo = true
	bm.material = mat
	var p := _particles(Vector3(0, 1.6, 0), bm, 80, 2.0, Vector3(0, -0.3, 0), Vector3(1.0, 0.1, 0.4), Vector3(0, -1.5, 0), true)
	(p.process_material as ParticleProcessMaterial).color_ramp = _rainbow()


func _rainbow() -> GradientTexture1D:
	var g := Gradient.new()
	g.set_color(0, Color(1, 0.3, 0.3))
	g.set_color(1, Color(0.3, 0.6, 1))
	g.add_point(0.33, Color(1, 0.9, 0.2))
	g.add_point(0.66, Color(0.3, 1, 0.4))
	var gt := GradientTexture1D.new()
	gt.gradient = g
	return gt


func _fx_flash(c: Color, amount: float) -> void:
	flash_col = c
	flash = amount


# ------------------------------------------------------------- boucle

func _process(dt: float) -> void:
	t += dt
	# camera de webcam : leger flottement + secousses
	shake = max(0.0, shake - dt)
	var off := Vector3(sin(t * 0.7) * 0.01, sin(t * 0.9) * 0.008, 0)
	if shake > 0.0:
		off += Vector3(randf_range(-1, 1), randf_range(-1, 1), 0) * shake * 0.05
	cam.position = cam_base + off + Vector3(0, -0.05, 0.82) * _zoom_v
	_zoom_v = lerpf(_zoom_v, cam_zoom, clampf(dt * 5.0, 0.0, 1.0))
	cam.rotation.z = lerp_angle(cam.rotation.z, cam_roll, clampf(dt * 6.0, 0.0, 1.0))
	flash = max(0.0, flash - dt * 1.5)
	var fm := flash_rect.material_override as StandardMaterial3D
	fm.albedo_color = Color(flash_col.r, flash_col.g, flash_col.b, clamp(flash, 0.0, 1.0))
	for mv in movers:
		if not is_instance_valid(mv[0]):
			continue
		var n: Node3D = mv[0]
		var sp: float = mv[1]
		match str(mv[2]):
			"spin":
				n.rotation.z += dt * sp
				n.rotation.y += dt * sp * 0.5
			"road":
				n.position.z -= dt * sp
				if n.position.z < -2.0:
					n.position.z += 7.0
			"pulse":
				var mat := n.get("material_override") as StandardMaterial3D
				if mat != null:
					mat.emission_energy_multiplier = 2.0 + sin(t * sp) * 2.0
			"disco":
				n.position = Vector3(sin(t * 2.0), 1.8, 0.4 + cos(t * 2.0) * 0.5)
				(n as OmniLight3D).light_color = Color.from_hsv(fmod(t * 0.3, 1.0), 0.8, 1.0)
			"turbulence":
				if randf() < dt * 0.4:
					shake = 0.5
			"hop":
				n.position.y = 0.12 + abs(sin(t * sp)) * 0.08
			"breathe":
				n.scale.y = 0.6 + sin(t * 1.4) * 0.04
			"fade":
				var bm := (n as MeshInstance3D).material_override as StandardMaterial3D
				bm.albedo_color.a = max(0.0, bm.albedo_color.a - dt * 0.15)
			"fall_spin":
				n.position.y -= dt * 1.2
				n.rotation += Vector3(dt * 4.0, dt * 3.0, 0)
			"smitten":
				mv[1] = sp + dt
				if sp > 0.3:
					n.rotation.z = lerp(n.rotation.z, -1.4, dt * 4.0)
					n.position.y = lerp(n.position.y, -0.4, dt * 2.0)
			"blink":
				n.visible = fmod(t, 0.6) < 0.4
			"drift":
				n.position.x += dt * sp
			"float_up":
				n.position.y += dt * 0.25
				n.position.x += sin(t * 3.0 * sp) * dt * 0.2
			"stop_later":
				mv[1] = sp + dt
				if sp > 2.5:
					(n as GPUParticles3D).emitting = false
