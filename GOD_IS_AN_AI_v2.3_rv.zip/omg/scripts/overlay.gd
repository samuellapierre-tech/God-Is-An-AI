extends CanvasLayer
## Ecrans entre les quarts : Gazette + humeur de Dieu, fin de quart + boutique,
## cérémonie de fin de semaine, pause. Style terminal orange (Lethal Company).

signal start_pressed
signal next_pressed
signal again_pressed
signal menu_pressed
signal resume_pressed

const GroupPhoto := preload("res://scripts/group_photo.gd")
const ORANGE := Color(1.0, 0.55, 0.16)
const DIM := Color(0.62, 0.34, 0.12)
const PALE := Color(1.0, 0.86, 0.66)
const RED := Color(1.0, 0.3, 0.22)
const GREEN := Color(0.55, 1.0, 0.6)

var root: Control
var panel: PanelContainer
var body: VBoxContainer
var mode := ""
var shop_rows := {}
var money_lbl: Label
var card_lbl: Label


func _ready() -> void:
	layer = 20
	process_mode = Node.PROCESS_MODE_ALWAYS
	root = Control.new()
	root.set_anchors_preset(Control.PRESET_FULL_RECT)
	root.mouse_filter = Control.MOUSE_FILTER_STOP
	add_child(root)
	var bg := ColorRect.new()
	bg.set_anchors_preset(Control.PRESET_FULL_RECT)
	bg.color = Color(0.0, 0.0, 0.0, 0.82)
	root.add_child(bg)
	root.visible = false


func is_open() -> bool:
	return root.visible or options_panel != null


func close() -> void:
	root.visible = false
	mode = ""
	if panel != null:
		panel.queue_free()
		panel = null


# ------------------------------------------------------------- briques

func _open(w: float, h: float) -> VBoxContainer:
	if panel != null:
		panel.queue_free()
	root.visible = true
	panel = PanelContainer.new()
	var sb := StyleBoxFlat.new()
	sb.bg_color = Color(0.03, 0.02, 0.015, 0.97)
	sb.border_color = ORANGE
	sb.set_border_width_all(2)
	sb.set_content_margin_all(26)
	panel.add_theme_stylebox_override("panel", sb)
	panel.anchor_left = 0.5
	panel.anchor_right = 0.5
	panel.anchor_top = 0.5
	panel.anchor_bottom = 0.5
	panel.offset_left = -w * 0.5
	panel.offset_right = w * 0.5
	panel.offset_top = -h * 0.5
	panel.offset_bottom = h * 0.5
	root.add_child(panel)
	var scroll := ScrollContainer.new()
	scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	panel.add_child(scroll)
	body = VBoxContainer.new()
	body.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	body.add_theme_constant_override("separation", 10)
	scroll.add_child(body)
	return body


func _lbl(par: Node, text: String, size: int, col: Color, center := false) -> Label:
	var l := Label.new()
	l.text = text
	l.add_theme_font_override("font", Loc.font("title" if size >= 26 else "mono"))
	l.add_theme_font_size_override("font_size", size)
	l.add_theme_color_override("font_color", col)
	l.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	l.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	if center:
		l.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	par.add_child(l)
	return l


func _sep(par: Node) -> void:
	var r := ColorRect.new()
	r.color = DIM
	r.custom_minimum_size = Vector2(0, 2)
	par.add_child(r)


func _btn(par: Node, text: String, cb: Callable, big := false) -> Button:
	var b := Button.new()
	b.text = text
	b.focus_mode = Control.FOCUS_ALL
	b.custom_minimum_size = Vector2(0, 54 if big else 40)
	b.add_theme_font_size_override("font_size", 24 if big else 18)
	b.add_theme_font_override("font", Loc.font("title" if big else "bold"))
	b.add_theme_color_override("font_color", ORANGE)
	b.add_theme_color_override("font_hover_color", Color(0.05, 0.03, 0.01))
	b.add_theme_color_override("font_focus_color", Color(0.05, 0.03, 0.01))
	b.add_theme_color_override("font_pressed_color", Color(0.05, 0.03, 0.01))
	b.add_theme_color_override("font_disabled_color", Color(0.35, 0.2, 0.08))
	b.add_theme_stylebox_override("normal", _box(Color(0.06, 0.035, 0.015), ORANGE))
	b.add_theme_stylebox_override("hover", _box(ORANGE, ORANGE))
	b.add_theme_stylebox_override("focus", _box(ORANGE, PALE))
	b.add_theme_stylebox_override("pressed", _box(PALE, PALE))
	b.add_theme_stylebox_override("disabled", _box(Color(0.04, 0.025, 0.01), Color(0.3, 0.17, 0.07)))
	b.pressed.connect(cb)
	b.mouse_entered.connect(Sfx.play.bind("ui_hover", -12.0, 1.0))
	b.pressed.connect(Sfx.play.bind("ui_click", -6.0, 1.0))
	par.add_child(b)
	return b


func _emit_start() -> void:
	start_pressed.emit()


func _emit_next() -> void:
	next_pressed.emit()


func _emit_again() -> void:
	again_pressed.emit()


func _emit_menu() -> void:
	menu_pressed.emit()


func _emit_resume() -> void:
	resume_pressed.emit()


func _quit() -> void:
	get_tree().quit()


func _box(bg: Color, border: Color) -> StyleBoxFlat:
	var sb := StyleBoxFlat.new()
	sb.bg_color = bg
	sb.border_color = border
	sb.set_border_width_all(2)
	sb.set_content_margin_all(8)
	return sb


func _day_name() -> String:
	if Reality.hooks.has("monday"):
		return Loc.f("echo_monday", [Game.day])
	var names := Loc.list("day_names")
	return str(names[clamp(Game.day - 1, 0, names.size() - 1)])


# ------------------------------------------------------------- debut de journee

func show_intro() -> void:
	mode = "intro"
	var v := _open(1000, 700)
	_lbl(v, Loc.f("intro_head", [_day_name(), Game.day, Game.DAYS]), 40, ORANGE)
	_lbl(v, Loc.f("intro_quota", [Game.quota(), Game.strikes, Game.MAX_STRIKES]), 20, PALE)
	if Game.weekly:
		_lbl(v, Loc.t("intro_weekly"), 18, GREEN)
	if Net.active and Net.satan_mode and Game.day == 1:
		if Net.i_am_satan():
			_lbl(v, Loc.t("satan_intro"), 20, RED)
		else:
			_lbl(v, Loc.t("satan_warn"), 18, RED)
	_sep(v)

	# humeur de Dieu
	var moods := Loc.dict("moods")
	var m: Array = moods.get(Game.mood, moods["normal"])
	_lbl(v, Loc.t("mood_head"), 18, DIM)
	_lbl(v, str(m[0]).to_upper(), 32, ORANGE)
	_lbl(v, str(m[1]), 20, PALE)
	_sep(v)

	# gazette : facon vieux journal
	var paper := PanelContainer.new()
	var psb := StyleBoxFlat.new()
	psb.bg_color = Color(0.9, 0.86, 0.76)
	psb.set_content_margin_all(16)
	psb.shadow_color = Color(0, 0, 0, 0.5)
	psb.shadow_size = 8
	paper.add_theme_stylebox_override("panel", psb)
	paper.rotation_degrees = -0.6
	v.add_child(paper)
	var pv := VBoxContainer.new()
	pv.add_theme_constant_override("separation", 6)
	paper.add_child(pv)
	var gh := _lbl(pv, Loc.t("gazette_head"), 26, Color(0.12, 0.1, 0.08), true)
	gh.add_theme_font_override("font", Loc.font("paper"))
	var ink := Color(0.15, 0.12, 0.1)
	var first := true
	for line in _gazette_lines():
		var gl := _lbl(pv, str(line), 24 if first else 18, ink)
		gl.add_theme_font_override("font", Loc.font("paper"))
		first = false
	_sep(v)
	_lbl(v, Loc.pick("tips"), 16, DIM)
	var b := _btn(v, Loc.t("btn_start"), _emit_start, true)
	_guest_lock(b)
	start_btn = b
	b.grab_focus.call_deferred()


func _gazette_lines() -> Array:
	var out := []
	for n in Game.mission_news:
		out.append(str(n))
	var tpl := Loc.list("gazette_tpl")
	for e in Game.gazette:
		var b: Dictionary = e["b"]
		var h := str(e.get("headline", ""))
		if h == "":
			h = str(tpl[Game.rng.randi() % tpl.size()]).format({
				"name": str(b.get("name", "?")), "place": str(b.get("place", "?")), "sold": str(e.get("sold", "?"))})
		else:
			h = h + "  (" + str(b.get("name", "")) + ", " + str(b.get("place", "")) + ")"
		out.append(h)
	if Game.day == 1 or out.is_empty():
		if Game.day > 1:
			out.append(Loc.t("gazette_empty"))
	var fill := Loc.list("gazette_filler")
	out.append(str(fill[Game.rng.randi() % fill.size()]))
	if Game.stats.get("max_expo", 0.0) > 60.0:
		out.append(Loc.t("gazette_expo"))
	return out


# ------------------------------------------------------------- fin de journee + boutique

func show_end(result: String, solved: int, quota: int) -> void:
	mode = "end"
	var v := _open(1100, 820)
	_lbl(v, Loc.f("end_head", [_day_name()]), 36, ORANGE)
	_lbl(v, Loc.f("end_result", [solved, quota]), 24, PALE)
	match result:
		"strike":
			_lbl(v, Loc.f("end_strike", [Game.strikes, Game.MAX_STRIKES]), 22, RED)
		"saved":
			_lbl(v, Loc.t("end_saved"), 22, GREEN)
		_:
			_lbl(v, Loc.t("end_ok"), 22, GREEN)
	money_lbl = _lbl(v, "", 22, ORANGE)
	var sh: Dictionary = Game.stats.get("shame", {})
	if not sh.is_empty() and Game.day < Game.DAYS:
		var me := str(sh.get("k", "")) == "peer" and int(sh.get("id", 0)) == Net.my_id()
		_lbl(v, Loc.t("shame_me") if me else Loc.f("shame_other", [str(sh.get("name", "?"))]), 20, RED)
	if not Game.xp_days.has(Game.day):
		Game.xp_days[Game.day] = Profile.day_done(solved, quota)
	_xp_block(v, int(Game.xp_days[Game.day]))
	_sep(v)
	_lbl(v, Loc.t("shop_head"), 28, ORANGE)
	shop_rows = {}
	var items := Loc.dict("shop")
	for id in Game.SHOP.keys():
		var row := HBoxContainer.new()
		row.add_theme_constant_override("separation", 14)
		v.add_child(row)
		var info := VBoxContainer.new()
		info.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		row.add_child(info)
		var it: Array = items.get(id, [id, ""])
		var tag := "[+] " if Game.SHOP[id][1] == "power" else "[^] "
		_lbl(info, tag + str(it[0]), 20, PALE)
		_lbl(info, str(it[1]), 15, DIM)
		var b := _btn(row, "", _buy.bind(id))
		b.custom_minimum_size = Vector2(220, 44)
		shop_rows[id] = b
	_sep(v)
	var nb := _btn(v, Loc.t("btn_next"), _emit_next, true)
	_guest_lock(nb)
	nb.grab_focus.call_deferred()
	_refresh_shop()


func _xp_block(v: VBoxContainer, gain: int) -> void:
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 14)
	v.add_child(row)
	var l := _lbl(row, Loc.f("xp_line", [gain, Profile.level(), Profile.title()]), 18, Color(0.55, 0.85, 1.0))
	l.autowrap_mode = TextServer.AUTOWRAP_OFF
	var bar := ProgressBar.new()
	bar.min_value = 0.0
	bar.max_value = 1.0
	bar.value = Profile.progress()
	bar.show_percentage = false
	bar.custom_minimum_size = Vector2(260, 14)
	bar.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	var fill := StyleBoxFlat.new()
	fill.bg_color = Color(0.4, 0.75, 1.0)
	bar.add_theme_stylebox_override("fill", fill)
	var bgs := StyleBoxFlat.new()
	bgs.bg_color = Color(0.1, 0.12, 0.16)
	bar.add_theme_stylebox_override("background", bgs)
	row.add_child(bar)
	if Profile.last_lvl_up > 0:
		_lbl(v, Loc.f("xp_levelup", [Profile.last_lvl_up]), 20, GREEN)


func _buy(id: String) -> void:
	if Net.active and not Net.is_host():
		get_parent().request_buy(id)
		return
	if Game.buy(id):
		_refresh_shop()


func _guest_lock(b: Button) -> void:
	# en co-op, seul l'hote fait avancer la journee
	if Net.active and not Net.is_host():
		b.disabled = true
		b.text = Loc.t("net_wait_host")


var _shop_t := 0.0
var vote_btns := []
var vote_lbl: Label = null


func _vote(id: int) -> void:
	for b in vote_btns:
		(b as Button).disabled = true
	if vote_lbl != null:
		vote_lbl.text = Loc.t("vote_sent")
	get_parent().net_vote(id)


func show_vote_result(res: Dictionary) -> void:
	if vote_lbl == null:
		return
	var me_satan := Net.i_am_satan()
	if bool(res.get("caught", false)) and not me_satan:
		Profile.unlock("satan_caught")
	elif not bool(res.get("caught", false)) and me_satan:
		Profile.unlock("satan_win")
	if bool(res.get("caught", false)):
		vote_lbl.text = Loc.f("vote_caught", [str(res["satan"])])
		vote_lbl.add_theme_color_override("font_color", GREEN)
		Sfx.play("cheer", -4.0)
	else:
		vote_lbl.text = Loc.f("vote_escaped", [str(res["accused"]), str(res["satan"])])
		vote_lbl.add_theme_color_override("font_color", RED)
		Sfx.play("trombone", -4.0)
var start_btn: Button = null


func _process(dt: float) -> void:
	# l'hote attend que tous les joueurs aient charge le bureau
	if mode == "intro" and Net.active and Net.is_host() and start_btn != null and is_instance_valid(start_btn):
		var ok := Net.all_loaded()
		start_btn.disabled = not ok
		start_btn.text = Loc.t("btn_start") if ok else Loc.f("net_wait_players", [Net.ready_peers.size(), Net.players.size()])
	if mode == "end" and Net.active:
		_shop_t += dt
		if _shop_t > 0.3:
			_shop_t = 0.0
			_refresh_shop()


func _refresh_shop() -> void:
	if money_lbl != null:
		money_lbl.text = Loc.f("end_money", [Game.wallet, Game.earned])
	for id in shop_rows:
		var b: Button = shop_rows[id]
		var price := int(Game.SHOP[id][0])
		if id != "second" and Game.has(id):
			b.text = Loc.t("shop_owned")
			b.disabled = true
		else:
			b.text = Loc.f("shop_buy", [price])
			if id == "second" and int(Game.owned.get("second", 0)) > 0:
				b.text += "  (" + Loc.f("shop_have", [int(Game.owned["second"])]) + ")"
			b.disabled = not Game.can_buy(id)


# ------------------------------------------------------------- fin de semaine

func show_review(record: bool) -> void:
	mode = "review"
	var v := _open(1100, 840)
	if Game.fired:
		_lbl(v, Loc.t("rev_fired"), 64, RED, true)
		_lbl(v, Loc.t("rev_fired_sub"), 20, PALE, true)
	else:
		_lbl(v, Loc.t("rev_done"), 56, ORANGE, true)
		_lbl(v, Loc.t("rev_done_sub"), 20, DIM, true)
	_lbl(v, Loc.f("rev_title", [Game.rank_title()]), 30, GREEN if not Game.fired else RED, true)
	if record:
		_lbl(v, Loc.t("rev_record"), 22, GREEN, true)
	if not Game.xp_days.has("week"):
		Game.xp_days["week"] = Profile.week_done(Game.fired, Game.earned, Game.strikes, Game.weekly)
	_xp_block(v, int(Game.xp_days["week"]))
	var photo := GroupPhoto.new()
	photo.custom_minimum_size = Vector2(1040, 380)
	v.add_child(photo)
	var conv: Array = Game.converted
	photo.setup(conv.slice(max(0, conv.size() - 7)), Game.fired)
	_lbl(v, Loc.f("rev_photo", [conv.size()]), 16, DIM, true)
	_sep(v)

	var st: Dictionary = Game.stats
	var grid := GridContainer.new()
	grid.columns = 2
	grid.add_theme_constant_override("h_separation", 40)
	grid.add_theme_constant_override("v_separation", 6)
	v.add_child(grid)
	var rows := [
		[Loc.t("aw_sales"), "%d $" % Game.earned if Loc.lang == "fr" else "$%d" % Game.earned],
		[Loc.t("aw_conv"), str(int(st.get("conversions", 0)))],
		[Loc.t("aw_expo"), Loc.f("aw_expo_v", [int(st.get("max_expo", 0.0))])],
		[Loc.t("aw_hang"), str(int(st.get("hangups", 0)))],
		[Loc.t("aw_coffee"), Loc.f("aw_coffee_v", [int(st.get("coffee_ok", 0)), int(st.get("coffee_bad", 0))])],
		[Loc.t("aw_long"), Loc.f("aw_long_v", [int(st.get("longest", 0))])],
		[Loc.t("aw_powers"), str(int(st.get("powers", 0)))],
		[Loc.t("aw_farts"), str(int(st.get("farts", 0)))],
		[Loc.t("aw_slips"), str(int(st.get("slips", 0)))],
		[Loc.t("aw_hoops"), str(int(st.get("hoops", 0)))],
		[Loc.t("aw_missions"), str(int(st.get("missions", 0)))],
	]
	if Net.active:
		rows.append([Loc.t("aw_steals"), str(int(st.get("steals", 0)))])
	var bp: Dictionary = st.get("by_player", {})
	if Net.active and bp.size() > 1:
		var best := ""
		var best_v := -1
		for k in bp:
			if int(bp[k]) > best_v:
				best_v = int(bp[k])
				best = str(k)
		rows.append([Loc.t("aw_best_seller"), "%s  (%d $)" % [best, best_v]])
	var vw: Array = st.get("viewers", [])
	if not vw.is_empty():
		rows.append([Loc.t("aw_viewers"), ", ".join(PackedStringArray(vw.slice(0, 5)))])
	var sold: Array = st.get("sold", [])
	if not sold.is_empty():
		rows.append([Loc.t("aw_sold"), str(sold[sold.size() - 1])])
	for r in rows:
		var l1 := _lbl(grid, str(r[0]), 20, DIM)
		l1.autowrap_mode = TextServer.AUTOWRAP_OFF
		var l2 := _lbl(grid, str(r[1]), 20, PALE)
		l2.autowrap_mode = TextServer.AUTOWRAP_OFF

	if str(Game.best_quote.get("line", "")) != "":
		_sep(v)
		_lbl(v, Loc.t("aw_quote"), 18, DIM, true)
		_lbl(v, "« " + str(Game.best_quote["line"]) + " »", 24, ORANGE, true)
		_lbl(v, "— " + str(Game.best_quote["who"]), 18, PALE, true)
	_sep(v)
	if Net.active and Net.satan_mode:
		_lbl(v, Loc.t("vote_title"), 30, RED, true)
		var vrow := HBoxContainer.new()
		vrow.add_theme_constant_override("separation", 10)
		v.add_child(vrow)
		vote_btns = []
		for id in Net.players:
			var vb := _btn(vrow, str(Net.players[id]["name"]), _vote.bind(int(id)))
			vb.size_flags_horizontal = Control.SIZE_EXPAND_FILL
			vote_btns.append(vb)
		vote_lbl = _lbl(v, "", 22, PALE, true)
		_sep(v)
	card_lbl = _lbl(v, "", 16, GREEN, true)
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 12)
	v.add_child(row)
	var b1 := _btn(row, Loc.t("btn_card"), _save_card)
	b1.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	var bm := _btn(row, Loc.f("btn_moments", [Game.highlights.size()]), _open_moments)
	bm.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	var ba := _btn(row, Loc.t("btn_archives"), _open_archives)
	ba.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	var b2 := _btn(row, Loc.t("btn_again"), _emit_again)
	_guest_lock(b2)
	b2.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	var b3 := _btn(row, Loc.t("btn_menu"), _emit_menu)
	b3.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	b2.grab_focus.call_deferred()


func _open_archives() -> void:
	var m := get_parent()
	if m != null and m.get("viral") != null:
		m.viral.open_archives()


func _open_moments() -> void:
	var m := get_parent()
	if m != null and m.get("viral") != null:
		m.viral.open_gallery()


func _save_card() -> void:
	await RenderingServer.frame_post_draw
	var img := get_viewport().get_texture().get_image()
	DirAccess.make_dir_recursive_absolute("user://cartes")
	var stamp := Time.get_datetime_string_from_system().replace(":", "-")
	var path := "user://cartes/carte_%s.png" % stamp
	img.save_png(path)
	var abs_path := ProjectSettings.globalize_path(path)
	if card_lbl != null:
		card_lbl.text = Loc.f("card_saved", [abs_path])
	OS.shell_show_in_file_manager(abs_path)


# ------------------------------------------------------------- pause

func show_pause() -> void:
	mode = "pause"
	var v := _open(560, 420)
	_lbl(v, Loc.t("pause_title"), 48, ORANGE, true)
	_sep(v)
	var b := _btn(v, Loc.t("pause_resume"), _emit_resume, true)
	_btn(v, Loc.t("menu_options"), _open_options, true)
	_btn(v, Loc.t("pause_menu"), _emit_menu, true)
	_btn(v, Loc.t("pause_quit"), _quit, true)
	b.grab_focus.call_deferred()


var options_panel = null


func _open_options() -> void:
	if options_panel != null:
		return
	root.visible = false
	options_panel = preload("res://scripts/options.gd").new()
	add_child(options_panel)
	options_panel.closed.connect(_on_options_closed)


func _on_options_closed() -> void:
	options_panel = null
	root.visible = true


func _unhandled_input(e: InputEvent) -> void:
	if not root.visible:
		return
	if e is InputEventKey and e.pressed and not e.echo:
		if mode == "pause" and e.keycode == KEY_ESCAPE:
			get_viewport().set_input_as_handled()
			resume_pressed.emit()
