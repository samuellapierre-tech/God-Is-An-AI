extends Node
## Chat vocal de proximite.
## Micro -> 11 kHz mono -> compression mu-law (8 bits) -> reseau.
## Chez les autres, la voix sort de la tete de ton avatar (son 3D :
## plus tu es loin, moins on t'entend). Touche B = talkie-walkie (tout le monde).
##
## Modes (Loc.voice_mode) : 0 appuyer sur V pour parler, 1 micro ouvert, 2 coupe.

const RATE := 11025.0
const OPEN_MIC_GATE := 0.02

var main: Node
var capture: AudioEffectCapture
var mic_player: AudioStreamPlayer
var mic_bus := -1
var level := 0.0
var transmitting := false
var radio := false
var fake_tone := false
var fake_amp := 0.3
var pitch := 1.0            # helium / diable (le vrai micro passe par AudioEffectPitchShift)
var _phase := 0.0
var _acc := PackedFloat32Array()
var radio_players := {}     # peer -> AudioStreamPlayer (talkie-walkie, non positionnel)
var sent_frames := 0
var recv_frames := 0


func _ready() -> void:
	fake_tone = Dev.args.has("fakemic") or Dev.args.has("fakeshout")
	if Dev.args.has("fakeshout"):
		fake_amp = 0.9
	_setup_buses()
	if not fake_tone:
		mic_player = AudioStreamPlayer.new()
		mic_player.stream = AudioStreamMicrophone.new()
		mic_player.bus = "Mic"
		add_child(mic_player)
		mic_player.play()


func _setup_buses() -> void:
	mic_bus = AudioServer.get_bus_index("Mic")
	if mic_bus < 0:
		AudioServer.add_bus()
		mic_bus = AudioServer.bus_count - 1
		AudioServer.set_bus_name(mic_bus, "Mic")
		AudioServer.add_bus_effect(mic_bus, AudioEffectCapture.new())
		AudioServer.set_bus_mute(mic_bus, true)
	capture = AudioServer.get_bus_effect(mic_bus, 0) as AudioEffectCapture
	if AudioServer.get_bus_index("Radio") < 0:
		AudioServer.add_bus()
		AudioServer.set_bus_name(AudioServer.bus_count - 1, "Radio")
	var rb := AudioServer.get_bus_index("Radio")
	if AudioServer.get_bus_effect_count(rb) == 0:
		var bpf := AudioEffectBandPassFilter.new()
		bpf.cutoff_hz = 1600.0
		AudioServer.add_bus_effect(rb, bpf)
		var dist := AudioEffectDistortion.new()
		dist.mode = AudioEffectDistortion.MODE_LOFI
		dist.drive = 0.35
		AudioServer.add_bus_effect(rb, dist)


func _wants_talk() -> bool:
	if Loc.voice_mode == 2:
		return false
	if Loc.voice_mode == 1 or fake_tone:
		return level > OPEN_MIC_GATE
	# V (ou B pour le talkie) ; si on ecrit dans le terminal : bouton lateral de la souris
	var typing: bool = main != null and main.pc_input != null and main.pc_input.has_focus()
	var side := Input.is_mouse_button_pressed(MOUSE_BUTTON_XBUTTON1) or Input.is_mouse_button_pressed(MOUSE_BUTTON_XBUTTON2)
	if typing:
		return side
	return side or Input.is_physical_key_pressed(KEY_V) or Input.is_physical_key_pressed(KEY_B)


func _process(dt: float) -> void:
	if main == null or not Net.active:
		return
	var samples := _read_input(dt)
	if samples.is_empty():
		level = lerp(level, 0.0, 0.2)
		transmitting = false
		return
	var sum := 0.0
	for v in samples:
		sum += v * v
	level = sqrt(sum / float(samples.size()))
	radio = Input.is_physical_key_pressed(KEY_B) and Loc.voice_mode != 2 and not (main.pc_input != null and main.pc_input.has_focus())
	transmitting = _wants_talk()
	main.voice_level = level if transmitting else 0.0
	if not transmitting:
		return
	if main.listener != null:
		main.listener.feed_pcm(samples)
	_acc.append_array(samples)
	while _acc.size() >= 256:
		var chunk := _acc.slice(0, 256)
		_acc = _acc.slice(256)
		var bytes := encode(chunk)
		if main.echoes != null:
			main.echoes.feed(Net.my_id(), bytes, level)
		bytes.append(1 if radio else 0)
		main.sync.bcast(&"voice", [bytes, level])
		sent_frames += 1


func _read_input(dt: float) -> PackedFloat32Array:
	var out := PackedFloat32Array()
	if fake_tone:
		# micro simule pour les tests : une petite melodie
		var n := int(RATE * dt)
		for i in n:
			_phase += pitch * 440.0 * (1.0 + 0.5 * float(int(float(Time.get_ticks_msec()) / 400.0) % 3)) / RATE
			out.append(sin(_phase * TAU) * fake_amp)
		return out
	if capture == null:
		return out
	var avail := capture.get_frames_available()
	if avail <= 0:
		return out
	var buf := capture.get_buffer(avail)
	var mix := AudioServer.get_mix_rate()
	var step := mix / RATE
	var pos := 0.0
	while int(pos) < buf.size():
		var i := int(pos)
		var s := (buf[i].x + buf[i].y) * 0.5
		out.append(s)
		pos += step
	return out


# ------------------------------------------------------------- mu-law

static func encode(samples: PackedFloat32Array) -> PackedByteArray:
	var out := PackedByteArray()
	out.resize(samples.size())
	var mu := 255.0
	var lmu := log(1.0 + mu)
	for i in samples.size():
		var x: float = clampf(samples[i], -1.0, 1.0)
		var y := log(1.0 + mu * absf(x)) / lmu
		var q := int(round(y * 127.0))
		out[i] = (q | 128) if x < 0.0 else q
	return out


static func decode(bytes: PackedByteArray, n: int) -> PackedVector2Array:
	var out := PackedVector2Array()
	out.resize(n)
	var mu := 255.0
	for i in n:
		var b := bytes[i]
		var y := float(b & 127) / 127.0
		var x := (pow(1.0 + mu, y) - 1.0) / mu
		if b & 128:
			x = -x
		out[i] = Vector2(x, x)
	return out


func receive(id: int, bytes: PackedByteArray, lvl: float, avatar: Dictionary) -> void:
	if bytes.size() < 2 or avatar.is_empty():
		return
	recv_frames += 1
	var is_radio := bytes[bytes.size() - 1] == 1
	var frames := decode(bytes, bytes.size() - 1)
	if main != null and main.echoes != null:
		main.echoes.feed(id, bytes.slice(0, bytes.size() - 1), lvl)
	var player: Node = avatar.get("voice", null)
	if is_radio:
		player = _radio_player(id)
	if player == null:
		return
	var pb = player.get_stream_playback()
	if pb == null:
		return
	if pb.can_push_buffer(frames.size()):
		pb.push_buffer(frames)
	avatar["talk"] = lvl


func _radio_player(id: int) -> AudioStreamPlayer:
	if radio_players.has(id):
		return radio_players[id]
	var p := AudioStreamPlayer.new()
	var gen := AudioStreamGenerator.new()
	gen.mix_rate = RATE
	gen.buffer_length = 0.5
	p.stream = gen
	p.bus = "Radio"
	add_child(p)
	p.play()
	radio_players[id] = p
	return p
