extends Node3D
## LE VESTIAIRE : choisis ton employe (Ted, Nova, Benoit...) et personnalise
## sa tenue piece par piece. Sauvegarde dans le profil (Profile.outfit) et
## visible par les autres joueurs en co-op.

const Character := preload("res://scripts/character.gd")
const CLAY := preload("res://shaders/clay.gdshader")
const ENV := "res://models/env/"

const ORANGE := Color(1.0, 0.56, 0.18)
const PALE := Color(1.0, 0.88, 0.7)
const DIM := Color(0.62, 0.45, 0.3)
const PANEL := Color(0.05, 0.035, 0.025, 0.86)

# categories : [id, [[cle, type, valeurs], ...]]
const CATS := [
	["employee", []],
	["body", [["skin", "color", "SKINS"], ["body", "choice", ["reg", "slim", "fat"]]]],
	["hair", [["style", "choice", "style"], ["hair", "color", "HAIRS"]]],
	["face", [["glasses", "choice", "glasses"], ["glasses_col", "color", "FRAMES"], ["mustache", "choice", "mustache"],
		["face_t", "toggles", ["beard", "teeth", "freckles", "lids", "googly", "earrings"]]]],
	["head", [["hat", "choice", "hat"], ["hat_col", "color", "TIES"], ["head_t", "toggles", ["headset"]]]],
	["top", [["top", "choice", ["shirt", "hoodie"]], ["sleeves", "choice", ["long", "short"]], ["shirt", "color", "SHIRTS"], ["shirt_pat", "choice", [0.0, 1.0, 2.0, 3.0]]]],
	["neck", [["neck", "choice", "neck"], ["tie_col", "color", "TIES"], ["tie_pat", "choice", [0.0, 1.0, 5.0, 6.0]]]],
	["legs", [["legs", "choice", "legs"], ["pants", "color", "PANTS"], ["belt", "color", "BELTS"], ["suspenders", "color_none", "TIES"]]],
	["feet", [["shoes", "choice", "shoes"], ["shoe_col", "color", "SHOES"], ["socks", "color", "SHIRTS"], ["sock_pat", "choice", [0.0, 1.0, 3.0]]]],
	["extra", [["wings", "choice", "wings"], ["pin", "choice", "pin"], ["held", "choice", "held"], ["extra_t", "toggles", ["badge", "pens"]]]],
]

const N := {
	"fr": {
		"title_sub": "PRÉPARE-TOI POUR LA MISSION DU JOUR", "mission": "MISSION", "center": "Centre de traitement des prières",
		"shift": "Quart de nuit", "ready": "PRÊT  >", "back": "Esc  RETOUR", "random": "ALÉATOIRE", "career": "CARRIÈRE",
		"employees": "TON EMPLOYÉ", "drag": "glisse pour tourner", "locked": "VERROUILLÉ", "none": "aucun", "lvl": "Niveau %d — %s",
		"cat_employee": "EMPLOYÉ", "cat_body": "CORPS", "cat_hair": "CHEVEUX", "cat_face": "VISAGE", "cat_head": "TÊTE",
		"cat_top": "HAUT", "cat_neck": "CRAVATE", "cat_legs": "BAS", "cat_feet": "PIEDS", "cat_extra": "EXTRAS",
		"row_skin": "Peau", "row_body": "Silhouette", "row_style": "Coiffure", "row_hair": "Couleur", "row_glasses": "Lunettes",
		"row_glasses_col": "Monture", "row_mustache": "Moustache", "row_face_t": "Détails", "row_hat": "Chapeau",
		"row_hat_col": "Couleur", "row_head_t": "Accessoire", "row_top": "Haut", "row_sleeves": "Manches", "row_shirt": "Couleur",
		"row_shirt_pat": "Motif", "row_neck": "Au cou", "row_tie_col": "Couleur", "row_tie_pat": "Motif", "row_legs": "Bas",
		"row_pants": "Couleur", "row_belt": "Ceinture", "row_suspenders": "Bretelles", "row_shoes": "Chaussures",
		"row_shoe_col": "Couleur", "row_socks": "Chaussettes", "row_sock_pat": "Motif", "row_wings": "Ailes (dos)",
		"row_pin": "Épinglette", "row_held": "En main", "row_extra_t": "Bureau",
		"body:reg": "normal", "body:slim": "mince", "body:fat": "dodu",
		"style:curly": "frisé", "style:bun": "chignon tressé", "style:sidepart": "raie dégarnie", "style:mohawk": "crête",
		"style:bob": "carré", "style:bowl": "bol", "style:puff": "touffe", "style:long": "long", "style:buns2": "2 chignons",
		"style:messy": "bouclettes", "style:afro": "afro", "style:short": "court", "style:bald": "chauve",
		"glasses:round": "rondes", "glasses:square": "carrées", "glasses:heart": "cœurs", "glasses:star": "étoiles", "glasses:3d": "3D",
		"mustache:walrus": "morse", "mustache:thin": "fine", "mustache:curly": "en guidon",
		"beard": "barbe", "teeth": "dents de lapin", "freckles": "taches de rousseur", "lids": "air blasé", "googly": "gros yeux", "earrings": "boucles d'oreilles",
		"hat:halo": "auréole", "hat:crown": "couronne", "hat:cap": "casquette", "hat:tophat": "haut-de-forme", "hat:tinfoil": "papier alu",
		"hat:beanie": "tuque", "hat:propeller": "hélice", "hat:antenna": "antennes", "hat:star": "étoiles", "hat:horns": "cornes", "hat:headband": "cravate de front",
		"headset": "casque d'écoute", "top:shirt": "chemise", "top:hoodie": "kangourou", "sleeves:long": "longues", "sleeves:short": "courtes",
		"pat:0": "uni", "pat:1": "rayé", "pat:2": "carreaux", "pat:3": "pois", "pat:5": "arc-en-ciel", "pat:6": "yeux",
		"neck:tie": "cravate", "neck:double": "DEUX cravates", "neck:bowtie": "nœud papillon",
		"legs:long": "pantalon", "legs:cuffed": "revers", "legs:shorts": "short", "legs:skirt": "jupe",
		"shoes:oxford": "souliers", "shoes:sneaker": "espadrilles", "shoes:sandal": "sandales", "shoes:croc": "sabots", "shoes:boot": "bottes", "shoes:bunny": "pantoufles lapin",
		"wings:white": "ange", "wings:black": "chauve-souris", "wings:gold": "or", "pin:star": "étoile", "pin:flower": "fleur", "pin:butterfly": "papillon",
		"held:mug": "tasse GOD FUEL", "held:book": "livre sacré", "badge": "badge G.O.D", "pens": "stylos de poche",
	},
	"en": {
		"title_sub": "PREPARE FOR TODAY'S MISSION", "mission": "MISSION", "center": "Prayer Processing Center",
		"shift": "Night Shift", "ready": "READY  >", "back": "Esc  BACK", "random": "RANDOM", "career": "CAREER",
		"employees": "YOUR EMPLOYEE", "drag": "drag to rotate", "locked": "LOCKED", "none": "none", "lvl": "Level %d — %s",
		"cat_employee": "EMPLOYEE", "cat_body": "BODY", "cat_hair": "HAIR", "cat_face": "FACE", "cat_head": "HEAD",
		"cat_top": "TOP", "cat_neck": "TIE", "cat_legs": "BOTTOM", "cat_feet": "FEET", "cat_extra": "EXTRAS",
		"row_skin": "Skin", "row_body": "Build", "row_style": "Haircut", "row_hair": "Color", "row_glasses": "Glasses",
		"row_glasses_col": "Frame", "row_mustache": "Mustache", "row_face_t": "Details", "row_hat": "Hat",
		"row_hat_col": "Color", "row_head_t": "Gear", "row_top": "Top", "row_sleeves": "Sleeves", "row_shirt": "Color",
		"row_shirt_pat": "Pattern", "row_neck": "Neck", "row_tie_col": "Color", "row_tie_pat": "Pattern", "row_legs": "Bottom",
		"row_pants": "Color", "row_belt": "Belt", "row_suspenders": "Suspenders", "row_shoes": "Shoes",
		"row_shoe_col": "Color", "row_socks": "Socks", "row_sock_pat": "Pattern", "row_wings": "Wings (back)",
		"row_pin": "Pin", "row_held": "In hand", "row_extra_t": "Office",
		"body:reg": "regular", "body:slim": "slim", "body:fat": "chubby",
		"style:curly": "curly", "style:bun": "braided bun", "style:sidepart": "comb-over", "style:mohawk": "mohawk",
		"style:bob": "bob", "style:bowl": "bowl cut", "style:puff": "puff", "style:long": "long", "style:buns2": "space buns",
		"style:messy": "messy curls", "style:afro": "afro", "style:short": "short", "style:bald": "bald",
		"glasses:round": "round", "glasses:square": "square", "glasses:heart": "hearts", "glasses:star": "stars", "glasses:3d": "3D",
		"mustache:walrus": "walrus", "mustache:thin": "thin", "mustache:curly": "handlebar",
		"beard": "beard", "teeth": "buck teeth", "freckles": "freckles", "lids": "unimpressed", "googly": "big eyes", "earrings": "earrings",
		"hat:halo": "halo", "hat:crown": "crown", "hat:cap": "cap", "hat:tophat": "top hat", "hat:tinfoil": "tinfoil",
		"hat:beanie": "beanie", "hat:propeller": "propeller", "hat:antenna": "antennae", "hat:star": "stars", "hat:horns": "horns", "hat:headband": "forehead tie",
		"headset": "headset", "top:shirt": "shirt", "top:hoodie": "hoodie", "sleeves:long": "long", "sleeves:short": "short",
		"pat:0": "plain", "pat:1": "striped", "pat:2": "checkered", "pat:3": "dots", "pat:5": "rainbow", "pat:6": "eyes",
		"neck:tie": "tie", "neck:double": "TWO ties", "neck:bowtie": "bowtie",
		"legs:long": "pants", "legs:cuffed": "cuffed", "legs:shorts": "shorts", "legs:skirt": "skirt",
		"shoes:oxford": "oxfords", "shoes:sneaker": "sneakers", "shoes:sandal": "sandals", "shoes:croc": "clogs", "shoes:boot": "boots", "shoes:bunny": "bunny slippers",
		"wings:white": "angel", "wings:black": "bat", "wings:gold": "gold", "pin:star": "star", "pin:flower": "flower", "pin:butterfly": "butterfly",
		"held:mug": "GOD FUEL mug", "held:book": "holy book", "badge": "G.O.D badge", "pens": "pocket pens",
	},
}

var look := {}
var ch: Node3D
var cam: Camera3D
var ui: Control
var cat_i := 1
var rows_box: VBoxContainer
var tabs_box: HBoxContainer
var portraits := {}
var info_name: Label
var info_title: Label
var dragging := false
var spin := 0.0
var spin_v := 0.0
var t := 0.0
var emote_cd := 3.0


func tr2(k: String) -> String:
	var d: Dictionary = N.get(Loc.lang, N["fr"])
	return str(d.get(k, N["fr"].get(k, k)))


func _ready() -> void:
	look = Profile.my_look()
	if Dev.args.has("lockcat"):
		cat_i = int(Dev.args["lockcat"])
	_build_room()
	_build_ui()
	_rebuild_char("wave")
	_render_portraits()
	Sfx.play("shimmer", -8.0, 1.1)


# ------------------------------------------------------------- la piece

func _m(c: Color, rough := 0.6, opts := {}) -> ShaderMaterial:
	return Character.clay(c, rough, opts)


func _env_mesh(par: Node3D, name: String, mat: Material, pos: Vector3, rot := Vector3.ZERO, sc := Vector3.ONE) -> MeshInstance3D:
	var mi := MeshInstance3D.new()
	var p := ENV + name + ".obj"
	if ResourceLoader.exists(p):
		mi.mesh = load(p)
	else:
		var bm := BoxMesh.new()
		mi.mesh = bm
	mi.material_override = mat
	mi.position = pos
	mi.rotation = rot
	mi.scale = sc
	par.add_child(mi)
	return mi


func _build_room() -> void:
	var we := WorldEnvironment.new()
	var e := Environment.new()
	e.background_mode = Environment.BG_COLOR
	e.background_color = Color(0.06, 0.035, 0.02)
	e.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	e.ambient_light_color = Color(0.7, 0.52, 0.4)
	e.ambient_light_energy = 0.3
	e.tonemap_mode = Environment.TONE_MAPPER_FILMIC
	e.tonemap_exposure = 1.05
	e.glow_enabled = true
	e.glow_intensity = 0.7
	e.glow_bloom = 0.12
	e.glow_hdr_threshold = 1.2
	e.ssao_enabled = true
	e.ssao_radius = 0.8
	e.ssao_intensity = 1.6
	e.fog_enabled = true
	e.fog_light_color = Color(0.45, 0.25, 0.12)
	e.fog_density = 0.005
	e.adjustment_enabled = true
	e.adjustment_saturation = 0.98
	e.adjustment_contrast = 1.1
	we.environment = e
	add_child(we)

	# sol : planches sombres vernies
	var floor_m := _m(Color(0.2, 0.11, 0.06), 0.28, {"bumps": 0.15, "pattern": 1.0, "pattern_col": Color(0.17, 0.09, 0.05), "scale": 2.2})
	var fl := MeshInstance3D.new()
	var pm := PlaneMesh.new()
	pm.size = Vector2(16, 12)
	fl.mesh = pm
	fl.material_override = floor_m
	add_child(fl)
	# murs
	var wall_m := _m(Color(0.16, 0.1, 0.08), 0.9, {"bumps": 0.6})
	var wall := MeshInstance3D.new()
	var bm := BoxMesh.new()
	bm.size = Vector3(16, 6, 0.2)
	wall.mesh = bm
	wall.material_override = wall_m
	wall.position = Vector3(0, 3, 3.6)
	add_child(wall)
	# casiers en arc derriere le personnage
	var lock_m := _m(Color(0.34, 0.22, 0.17), 0.4, {"metal": 0.4, "bumps": 0.05})
	var lock_m2 := _m(Color(0.3, 0.2, 0.16), 0.44, {"metal": 0.4, "bumps": 0.05})
	for i in 11:
		var a := (float(i) - 5.0) * 0.16
		var pos := Vector3(sin(a) * 3.3, 0, cos(a) * 3.3 - 0.2)
		var lk := _env_mesh(self, "locker", lock_m if i % 2 == 0 else lock_m2, pos, Vector3(0, a + PI, 0))
		if i in [2, 8]:
			# casier entrouvert avec une chemise qui pend
			_env_mesh(lk, "hanging_shirt", _m(Character.SHIRTS[i % 12], 0.8), Vector3(0, 1.75, -0.05))
	# l'enseigne-oeil au-dessus des casiers
	var glow := _m(Color(1.0, 0.86, 0.55), 0.4, {"emit": Color(1.0, 0.75, 0.35), "energy": 1.0, "bumps": 0.0})
	var sign := _env_mesh(self, "eye_sign", glow, Vector3(0, 3.05, 3.3), Vector3(0, PI, 0), Vector3.ONE * 0.6)
	_env_mesh(sign, "eye_iris", _m(Color(0.95, 0.55, 0.15), 0.4, {"emit": Color(1.0, 0.55, 0.15), "energy": 2.0}), Vector3(0, 0, -0.06), Vector3.ZERO, Vector3.ONE * 1.25)
	var pupil := MeshInstance3D.new()
	var sm := SphereMesh.new()
	sm.radius = 0.2
	sm.height = 0.1
	pupil.mesh = sm
	pupil.material_override = _m(Color(0.03, 0.02, 0.02), 0.3)
	pupil.position = Vector3(0, 0, -0.12)
	sign.add_child(pupil)
	var sl := OmniLight3D.new()
	sl.light_color = Color(1.0, 0.7, 0.35)
	sl.light_energy = 2.2
	sl.omni_range = 6.0
	sl.position = Vector3(0, 2.6, 2.6)
	add_child(sl)
	# miroirs de loge (ampoules) a gauche et a droite
	for sx in [-1.0, 1.0]:
		var mr := Node3D.new()
		mr.position = Vector3(sx * 3.0, 0.75, 1.3)
		mr.rotation.y = PI - sx * 0.9
		add_child(mr)
		_env_mesh(mr, "mirror_frame", _m(Color(0.3, 0.17, 0.1), 0.5, {"bumps": 0.3}), Vector3.ZERO)
		var glass := MeshInstance3D.new()
		var qm := QuadMesh.new()
		qm.size = Vector2(0.78, 1.3)
		glass.mesh = qm
		var gm := StandardMaterial3D.new()
		gm.albedo_color = Color(0.25, 0.2, 0.18)
		gm.metallic = 0.9
		gm.roughness = 0.08
		glass.material_override = gm
		glass.position = Vector3(0, 0.74, 0.01)
		glass.rotation.y = PI
		mr.add_child(glass)
		var bulb_m := _m(Color(1.0, 0.95, 0.8), 0.3, {"emit": Color(1.0, 0.85, 0.55), "energy": 4.0, "bumps": 0.0})
		for k in 6:
			_env_mesh(mr, "bulb", bulb_m, Vector3(-0.47, 0.18 + k * 0.23, -0.04))
			_env_mesh(mr, "bulb", bulb_m, Vector3(0.47, 0.18 + k * 0.23, -0.04))
		var ml := OmniLight3D.new()
		ml.light_color = Color(1.0, 0.82, 0.55)
		ml.light_energy = 1.6
		ml.omni_range = 4.0
		ml.position = Vector3(0, 0.8, -0.4)
		mr.add_child(ml)
		# banc + vetements plies + tasse
		var bench := _env_mesh(self, "bench", _m(Color(0.36, 0.2, 0.1), 0.5, {"bumps": 0.4}), Vector3(sx * 2.0, 0, 0.3), Vector3(0, -sx * 0.5, 0))
		_env_mesh(bench, "folded", _m(Character.SHIRTS[3 if sx < 0 else 1], 0.8), Vector3(0.3, 0.48, 0))
		_env_mesh(bench, "folded", _m(Character.PANTS[2], 0.8), Vector3(-0.3, 0.48, 0.02))
		_env_mesh(bench, "mug_prop", _m(Color(0.96, 0.95, 0.92), 0.35), Vector3(0.62, 0.48, 0))
		# plante
		var pot := _env_mesh(self, "pot", _m(Color(0.55, 0.32, 0.2), 0.7), Vector3(sx * 3.4, 0, 2.4))
		_env_mesh(pot, "leaves", _m(Color(0.22, 0.42, 0.18), 0.6, {"bumps": 0.3}), Vector3.ZERO)
	# neons au plafond
	for sx in [-1.0, 1.0]:
		var tl := _env_mesh(self, "tube_light", _m(Color(1.0, 0.95, 0.85), 0.3, {"emit": Color(1.0, 0.9, 0.7), "energy": 3.0, "bumps": 0.0}), Vector3(sx * 1.6, 3.3, 1.6), Vector3(0, sx * 0.4, 0))
		var spot := SpotLight3D.new()
		spot.light_color = Color(1.0, 0.85, 0.65)
		spot.light_energy = 1.1
		spot.spot_range = 6.0
		spot.spot_angle = 48.0
		spot.shadow_enabled = true
		spot.shadow_normal_bias = 2.0
		spot.rotation_degrees = Vector3(-80, 0, 0)
		spot.position = tl.position + Vector3(0, -0.15, 0)
		add_child(spot)
	# tapis rond sous le personnage + projecteur
	_env_mesh(self, "rug", _m(Color(0.42, 0.12, 0.1), 0.95, {"bumps": 1.0, "pattern": 3.0, "pattern_col": Color(0.55, 0.2, 0.15), "scale": 6.0}), Vector3(0, 0, 0), Vector3.ZERO, Vector3(0.7, 1, 0.7))
	var key := SpotLight3D.new()
	key.light_color = Color(1.0, 0.92, 0.82)
	key.light_energy = 1.35
	key.spot_range = 8.0
	key.spot_angle = 26.0
	key.shadow_enabled = true
	key.shadow_normal_bias = 2.0
	key.position = Vector3(-1.2, 3.2, -2.4)
	add_child(key)
	key.look_at(Vector3(0, 1.0, 0), Vector3.UP)
	var rim := DirectionalLight3D.new()
	rim.light_color = Color(1.0, 0.65, 0.35)
	rim.light_energy = 0.7
	rim.rotation_degrees = Vector3(-25, 165, 0)
	add_child(rim)
	cam = Camera3D.new()
	cam.position = Vector3(0.25, 1.25, -4.1)
	cam.fov = 42
	add_child(cam)
	cam.look_at(Vector3(0.25, 0.72, 0), Vector3.UP)
	cam.current = true


# ------------------------------------------------------------- personnage

func _rebuild_char(emote := "") -> void:
	var old_rot := 0.0
	if ch != null and is_instance_valid(ch):
		old_rot = ch.rotation.y
		ch.queue_free()
	ch = Character.new()
	add_child(ch)
	ch.build(look, "stand")
	ch.position = Vector3(0, 0.78 * float(look.get("height", 1.0)), 0)
	ch.rotation.y = old_rot
	ch.look_target = cam
	if emote != "":
		ch.emote(emote)
	else:
		ch.set_emotion("happy")
	_refresh_info()


func _setk(key: String, val) -> void:
	look[key] = val
	Sfx.play("ui_click", -6.0, randf_range(0.95, 1.15))
	_rebuild_char()
	if randf() < 0.35:
		ch.emote(["flex", "wave", "dance"][randi() % 3])
	_build_rows()


func _pick_preset(id: String) -> void:
	look = Character.preset(id)
	look["headset"] = true
	Sfx.play("shimmer", -6.0, 1.2)
	_rebuild_char("wave")
	_build_rows()


func _randomize() -> void:
	var rng := RandomNumberGenerator.new()
	rng.randomize()
	var base := Character.preset(Character.PRESET_ORDER[rng.randi() % 12])
	var r := Character.random_look(rng, {"age": rng.randi_range(22, 50)})
	for k in ["style", "hair", "skin", "body", "shirt", "pants", "neck", "tie_col", "glasses", "mustache", "hat", "hat_col", "shoes", "shoe_col", "legs", "suspenders", "fem"]:
		base[k] = r[k]
	for k in ["hat", "wings", "glasses", "shoes"]:
		if not Profile.outfit_ok(k, str(base.get(k, ""))):
			base[k] = "" if k != "shoes" else "oxford"
	base["badge"] = true
	base["headset"] = true
	base.erase("preset")
	look = base
	Sfx.play("pop", -4.0)
	_rebuild_char("dance")
	_build_rows()


func _ready_go() -> void:
	Profile.set_outfit(look)
	Sfx.play("score", -4.0)
	get_tree().change_scene_to_file("res://scenes/menu.tscn")


func _process(dt: float) -> void:
	t += dt
	if ch != null and is_instance_valid(ch):
		if not dragging:
			spin_v = lerpf(spin_v, 0.0, dt * 2.0)
			ch.rotation.y += spin_v * dt
		emote_cd -= dt
		if emote_cd <= 0.0:
			emote_cd = randf_range(6.0, 11.0)
			if ch.cur_emote == "":
				ch.emote(["wave", "flex", "dance", "laugh"][randi() % 4])


func _unhandled_input(ev: InputEvent) -> void:
	if ev is InputEventMouseButton and ev.button_index == MOUSE_BUTTON_LEFT:
		dragging = ev.pressed
	elif ev is InputEventMouseMotion and dragging and ch != null:
		ch.rotation.y += ev.relative.x * 0.012
		spin_v = ev.relative.x * 0.6
	elif ev.is_action_pressed("ui_cancel"):
		_ready_go()


# ------------------------------------------------------------- interface

func _font_lbl(par: Node, text: String, size: int, col: Color, font := "mono") -> Label:
	var l := Label.new()
	l.text = text
	l.add_theme_font_override("font", Loc.font(font))
	l.add_theme_font_size_override("font_size", size)
	l.add_theme_color_override("font_color", col)
	l.add_theme_color_override("font_shadow_color", Color(0, 0, 0, 0.7))
	l.add_theme_constant_override("shadow_offset_y", 2)
	par.add_child(l)
	return l


func _box(bg: Color, border: Color, bw := 2, r := 10) -> StyleBoxFlat:
	var sb := StyleBoxFlat.new()
	sb.bg_color = bg
	sb.border_color = border
	sb.set_border_width_all(bw)
	sb.set_corner_radius_all(r)
	sb.set_content_margin_all(10)
	return sb


func _btn(par: Node, text: String, size := 16, w := 0) -> Button:
	var b := Button.new()
	b.text = text
	b.add_theme_font_override("font", Loc.font("bold"))
	b.add_theme_font_size_override("font_size", size)
	b.add_theme_color_override("font_color", PALE)
	b.add_theme_color_override("font_hover_color", Color(0.08, 0.04, 0.02))
	b.add_theme_color_override("font_pressed_color", Color(0.08, 0.04, 0.02))
	b.add_theme_color_override("font_disabled_color", Color(0.45, 0.35, 0.28))
	b.add_theme_stylebox_override("normal", _box(Color(0.12, 0.07, 0.04, 0.9), Color(0.55, 0.3, 0.12), 2, 8))
	b.add_theme_stylebox_override("hover", _box(Color(1.0, 0.62, 0.25), Color(1.0, 0.85, 0.6), 2, 8))
	b.add_theme_stylebox_override("pressed", _box(Color(1.0, 0.8, 0.5), Color(1, 1, 1), 2, 8))
	b.add_theme_stylebox_override("focus", _box(Color(0, 0, 0, 0), Color(1.0, 0.85, 0.5), 2, 8))
	b.add_theme_stylebox_override("disabled", _box(Color(0.08, 0.05, 0.04, 0.8), Color(0.25, 0.17, 0.1), 2, 8))
	if w > 0:
		b.custom_minimum_size = Vector2(w, 0)
	par.add_child(b)
	return b


func _build_ui() -> void:
	var cl := CanvasLayer.new()
	add_child(cl)
	ui = Control.new()
	ui.set_anchors_preset(Control.PRESET_FULL_RECT)
	ui.mouse_filter = Control.MOUSE_FILTER_IGNORE
	cl.add_child(ui)
	# titre
	var tl := _font_lbl(ui, "GOD IS AN AI", 64, ORANGE, "title")
	tl.position = Vector2(48, 26)
	var st := _font_lbl(ui, tr2("title_sub"), 18, Color(0.85, 0.6, 0.35))
	st.position = Vector2(52, 106)
	# encadre mission (en haut a droite)
	var mp := PanelContainer.new()
	mp.add_theme_stylebox_override("panel", _box(Color(0.04, 0.025, 0.015, 0.75), Color(0.7, 0.42, 0.18), 2, 8))
	mp.anchor_left = 1.0
	mp.anchor_right = 1.0
	mp.offset_left = -400
	mp.offset_right = -40
	mp.offset_top = 30
	ui.add_child(mp)
	var mv := VBoxContainer.new()
	mp.add_child(mv)
	_font_lbl(mv, tr2("mission"), 18, ORANGE, "bold")
	_font_lbl(mv, tr2("center"), 16, PALE)
	_font_lbl(mv, tr2("shift"), 16, DIM)
	info_name = _font_lbl(mv, "", 30, Color(1.0, 0.8, 0.45), "title")
	info_title = _font_lbl(mv, "", 15, PALE)
	# employes (portraits) a gauche
	var lp := PanelContainer.new()
	lp.add_theme_stylebox_override("panel", _box(PANEL, Color(0.45, 0.25, 0.1), 2, 12))
	lp.position = Vector2(40, 150)
	ui.add_child(lp)
	var lv := VBoxContainer.new()
	lv.add_theme_constant_override("separation", 6)
	lp.add_child(lv)
	_font_lbl(lv, tr2("employees"), 20, ORANGE, "bold")
	var grid := GridContainer.new()
	grid.columns = 3
	grid.add_theme_constant_override("h_separation", 8)
	grid.add_theme_constant_override("v_separation", 4)
	lv.add_child(grid)
	for id in Character.PRESET_ORDER:
		var cell := VBoxContainer.new()
		cell.add_theme_constant_override("separation", 0)
		grid.add_child(cell)
		var tb := TextureButton.new()
		tb.custom_minimum_size = Vector2(84, 84)
		tb.ignore_texture_size = true
		tb.stretch_mode = TextureButton.STRETCH_KEEP_ASPECT_CENTERED
		tb.pressed.connect(_pick_preset.bind(id))
		tb.mouse_entered.connect(func(): Sfx.play("ui_click", -14.0, 1.4))
		cell.add_child(tb)
		portraits[id] = tb
		var nl := _font_lbl(cell, str(Character.PRESETS[id]["name"]), 13, PALE, "bold")
		nl.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	var rb := _btn(lv, tr2("random"), 16)
	rb.pressed.connect(_randomize)
	var cb := _btn(lv, tr2("career"), 16)
	cb.pressed.connect(_open_career)
	# panneau du bas : onglets + rangees d'options
	var bp := PanelContainer.new()
	bp.add_theme_stylebox_override("panel", _box(PANEL, Color(0.45, 0.25, 0.1), 2, 12))
	bp.anchor_top = 1.0
	bp.anchor_bottom = 1.0
	bp.anchor_left = 0.0
	bp.anchor_right = 1.0
	bp.offset_left = 330
	bp.offset_right = -300
	bp.offset_top = -270
	bp.offset_bottom = -24
	ui.add_child(bp)
	var bv := VBoxContainer.new()
	bv.add_theme_constant_override("separation", 8)
	bp.add_child(bv)
	tabs_box = HBoxContainer.new()
	tabs_box.add_theme_constant_override("separation", 4)
	bv.add_child(tabs_box)
	var sc := ScrollContainer.new()
	sc.size_flags_vertical = Control.SIZE_EXPAND_FILL
	sc.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	bv.add_child(sc)
	rows_box = VBoxContainer.new()
	rows_box.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	rows_box.add_theme_constant_override("separation", 6)
	sc.add_child(rows_box)
	# PRET
	var go := _btn(ui, tr2("ready"), 38)
	go.add_theme_font_override("font", Loc.font("title"))
	go.add_theme_color_override("font_color", ORANGE)
	go.add_theme_stylebox_override("normal", _box(Color(0.06, 0.03, 0.015, 0.85), ORANGE, 3, 10))
	go.anchor_left = 1.0
	go.anchor_right = 1.0
	go.anchor_top = 1.0
	go.anchor_bottom = 1.0
	go.offset_left = -270
	go.offset_right = -40
	go.offset_top = -120
	go.offset_bottom = -30
	go.pressed.connect(_ready_go)
	var hint := _font_lbl(ui, tr2("back") + "    ·    " + tr2("drag"), 14, DIM)
	hint.anchor_left = 1.0
	hint.anchor_right = 1.0
	hint.anchor_top = 1.0
	hint.anchor_bottom = 1.0
	hint.offset_left = -600
	hint.offset_right = -40
	hint.offset_top = -150
	hint.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	_build_tabs()
	_build_rows()
	go.grab_focus.call_deferred()


func _build_tabs() -> void:
	for c in tabs_box.get_children():
		c.queue_free()
	for i in range(1, CATS.size()):
		var b := _btn(tabs_box, tr2("cat_" + str(CATS[i][0])), 15)
		b.toggle_mode = true
		b.button_pressed = i == cat_i
		if i == cat_i:
			b.add_theme_stylebox_override("normal", _box(Color(1.0, 0.56, 0.18), Color(1.0, 0.85, 0.6), 2, 8))
			b.add_theme_color_override("font_color", Color(0.1, 0.05, 0.02))
		b.pressed.connect(_set_cat.bind(i))


func _set_cat(i: int) -> void:
	cat_i = i
	Sfx.play("ui_click", -8.0, 0.9)
	_build_tabs()
	_build_rows()


func _palette(name: String) -> Array:
	match name:
		"SKINS":
			return Character.SKINS
		"HAIRS":
			return Character.HAIRS + Character.DYED + [Color(0.92, 0.92, 0.94)]
		"SHIRTS":
			return Character.SHIRTS
		"PANTS":
			return Character.PANTS
		"TIES":
			return Character.TIES + [Color(0.98, 0.98, 0.98), Color(0.45, 0.25, 0.75)]
		"FRAMES":
			return [Color(0.07, 0.07, 0.08), Color(0.98, 0.78, 0.15), Color(0.85, 0.15, 0.2), Color(0.95, 0.5, 0.75), Color(0.3, 0.55, 0.95), Color(0.95, 0.95, 0.95)]
		"BELTS":
			return [Color(0.12, 0.09, 0.08), Color(0.45, 0.28, 0.14), Color(0.82, 0.6, 0.25), Color(0.85, 0.15, 0.15), Color(0.95, 0.95, 0.95)]
		"SHOES":
			return [Color(0.12, 0.09, 0.08), Color(0.45, 0.28, 0.14), Color(0.95, 0.95, 0.95), Color(0.3, 0.38, 0.55), Color(0.85, 0.15, 0.15), Color(0.98, 0.82, 0.15), Color(0.25, 0.6, 0.35), Color(0.96, 0.6, 0.75)]
	return []


func _values(spec) -> Array:
	if typeof(spec) == TYPE_ARRAY:
		return spec
	var cat: Array = Character.CATALOG.get(str(spec), [])
	return cat


func _item_name(key: String, val) -> String:
	if key.ends_with("_pat"):
		return tr2("pat:%d" % int(val))
	if str(val) == "":
		return tr2("none")
	return tr2("%s:%s" % [key, str(val)])


func _build_rows() -> void:
	for c in rows_box.get_children():
		c.queue_free()
	var rows: Array = CATS[cat_i][1]
	for r in rows:
		var key: String = r[0]
		var kind: String = r[1]
		var row := HBoxContainer.new()
		row.add_theme_constant_override("separation", 6)
		rows_box.add_child(row)
		var lbl := _font_lbl(row, tr2("row_" + key), 15, Color(0.85, 0.65, 0.42), "bold")
		lbl.custom_minimum_size = Vector2(130, 0)
		var flow := HFlowContainer.new()
		flow.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		flow.add_theme_constant_override("h_separation", 5)
		flow.add_theme_constant_override("v_separation", 5)
		row.add_child(flow)
		match kind:
			"choice":
				for v in _values(r[2]):
					var ok: bool = Profile.outfit_ok(key, str(v))
					var b := _btn(flow, _item_name(key, v) + ("" if ok else "  [x]"), 14)
					var cur = look.get(key, "")
					var sel: bool = (str(cur) == str(v)) if typeof(v) != TYPE_FLOAT else (absf(float(cur) - float(v)) < 0.01)
					if sel:
						b.add_theme_stylebox_override("normal", _box(Color(1.0, 0.56, 0.18), Color(1.0, 0.85, 0.6), 2, 8))
						b.add_theme_color_override("font_color", Color(0.1, 0.05, 0.02))
					if not ok:
						b.disabled = true
						b.tooltip_text = Profile.outfit_lock_text(key, str(v))
					else:
						b.pressed.connect(_setk.bind(key, v))
			"color", "color_none":
				if kind == "color_none":
					var nb := _btn(flow, tr2("none"), 13)
					nb.pressed.connect(_setk.bind(key, null))
				for c in _palette(str(r[2])):
					var sw := Button.new()
					sw.custom_minimum_size = Vector2(34, 34)
					var cur2 = look.get(key, null)
					var sel2: bool = typeof(cur2) == TYPE_COLOR and (cur2 as Color).is_equal_approx(c)
					sw.add_theme_stylebox_override("normal", _box(c, Color(1, 1, 1) if sel2 else Color(0, 0, 0, 0.6), 3 if sel2 else 2, 17))
					sw.add_theme_stylebox_override("hover", _box(c.lightened(0.15), Color(1.0, 0.85, 0.5), 3, 17))
					sw.add_theme_stylebox_override("pressed", _box(c, Color(1, 1, 1), 3, 17))
					sw.pressed.connect(_setk.bind(key, c))
					flow.add_child(sw)
			"toggles":
				for k in r[2]:
					var on := false
					var v2 = look.get(k, false)
					if typeof(v2) == TYPE_BOOL:
						on = v2
					elif typeof(v2) in [TYPE_FLOAT, TYPE_INT]:
						on = float(v2) > 0.0
					var tb := _btn(flow, ("[X] " if on else "[  ] ") + tr2(k), 14)
					tb.pressed.connect(_toggle.bind(k))


func _toggle(k: String) -> void:
	var v = look.get(k, false)
	var on: bool = (v if typeof(v) == TYPE_BOOL else float(v) > 0.0) if v != null else false
	match k:
		"freckles":
			_setk(k, 0.0 if on else 0.85)
		"lids":
			_setk(k, 0.0 if on else 0.45)
		"googly":
			_setk(k, 0.0 if on else 0.9)
		_:
			_setk(k, not on)


func _refresh_info() -> void:
	if info_name == null:
		return
	var pid := str(look.get("preset", ""))
	if pid != "" and Character.PRESETS.has(pid):
		info_name.text = str(Character.PRESETS[pid]["name"])
		info_title.text = str(Character.PRESETS[pid]["fr" if Loc.lang == "fr" else "en"]) + "   ·   " + tr2("lvl") % [Profile.level(), Profile.title()]
	else:
		info_name.text = Net.my_name if Net.my_name != "" else "?"
		info_title.text = tr2("lvl") % [Profile.level(), Profile.title()]


# ------------------------------------------------------------- portraits des employes

func _render_portraits() -> void:
	var vp := SubViewport.new()
	vp.size = Vector2i(192, 192)
	vp.own_world_3d = true
	vp.transparent_bg = true
	vp.render_target_update_mode = SubViewport.UPDATE_ALWAYS
	add_child(vp)
	var root := Node3D.new()
	vp.add_child(root)
	var e := Environment.new()
	e.background_mode = Environment.BG_COLOR
	e.background_color = Color(0, 0, 0, 0)
	e.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	e.ambient_light_color = Color(0.9, 0.75, 0.6)
	e.ambient_light_energy = 0.6
	e.tonemap_mode = Environment.TONE_MAPPER_FILMIC
	var we := WorldEnvironment.new()
	we.environment = e
	root.add_child(we)
	var l := DirectionalLight3D.new()
	l.rotation_degrees = Vector3(-25, -30, 0)
	l.light_energy = 1.3
	l.light_color = Color(1.0, 0.9, 0.78)
	root.add_child(l)
	var pc := Camera3D.new()
	pc.position = Vector3(0, 1.66, -1.05)
	pc.fov = 30
	root.add_child(pc)
	pc.look_at(Vector3(0, 1.64, 0), Vector3.UP)
	pc.current = true
	for id in Character.PRESET_ORDER:
		var c := Character.new()
		root.add_child(c)
		c.build(Character.preset(id), "bust")
		c.position = Vector3(0, 0.78, 0)
		c.set_emotion("happy")
		await RenderingServer.frame_post_draw
		await RenderingServer.frame_post_draw
		var img := vp.get_texture().get_image()
		var tex := ImageTexture.create_from_image(img)
		var tb: TextureButton = portraits[id]
		tb.texture_normal = tex
		c.queue_free()
		await get_tree().process_frame
	vp.queue_free()


func _open_career() -> void:
	var cp = preload("res://scripts/career.gd").new()
	var cl := CanvasLayer.new()
	cl.layer = 5
	add_child(cl)
	cl.add_child(cp)
	cp.closed.connect(cl.queue_free)
