extends Node3D
## PERSONNAGES « PATE A MODELER » (v3).
## Figurines modulaires : grosse tete, yeux 3D brillants, vetements et
## accessoires interchangeables (pieces generees par tools/gen_models.py).
##
##   var c := Character.new()
##   add_child(c)
##   c.build(Character.preset("ted"), "sit")      # ou random_look(rng, opts)
##   c.say(2.0)                 # bouge la bouche 2 s
##   c.set_emotion("happy")     # neutral, happy, worried, angry, shock, sad,
##                              # laugh, cry, love, fury, dizzy, proud
##   c.emote("wave")            # wave, dance, laugh, facepalm, pray, point, flex, tpose, chicken
##   c.look_target = some_node3d

const FACE := preload("res://shaders/face_clay.gdshader")
const CLAY := preload("res://shaders/clay.gdshader")
const EYE := preload("res://shaders/eye.gdshader")
const MDIR := "res://models/char/"

const SKINS := [Color(0.99, 0.84, 0.72), Color(0.96, 0.77, 0.63), Color(0.88, 0.66, 0.5), Color(0.78, 0.55, 0.39),
	Color(0.62, 0.41, 0.28), Color(0.47, 0.3, 0.2), Color(0.35, 0.22, 0.15), Color(0.97, 0.82, 0.68)]
const HAIRS := [Color(0.08, 0.06, 0.05), Color(0.24, 0.15, 0.09), Color(0.42, 0.26, 0.14), Color(0.66, 0.46, 0.24),
	Color(0.96, 0.82, 0.48), Color(0.72, 0.3, 0.12), Color(0.14, 0.11, 0.1)]
const DYED := [Color(0.98, 0.45, 0.65), Color(0.35, 0.6, 0.98), Color(0.5, 0.88, 0.55), Color(0.66, 0.4, 0.9), Color(0.92, 0.22, 0.2)]
const SHIRTS := [Color(0.96, 0.92, 0.84), Color(0.62, 0.42, 0.85), Color(0.18, 0.7, 0.75), Color(0.86, 0.2, 0.2),
	Color(0.98, 0.78, 0.25), Color(0.25, 0.68, 0.6), Color(0.35, 0.5, 0.82), Color(0.95, 0.55, 0.3),
	Color(0.2, 0.2, 0.24), Color(0.94, 0.94, 0.96), Color(0.56, 0.75, 0.4), Color(0.9, 0.55, 0.7)]
const PANTS := [Color(0.16, 0.18, 0.26), Color(0.25, 0.2, 0.16), Color(0.32, 0.36, 0.5), Color(0.55, 0.45, 0.3),
	Color(0.12, 0.12, 0.14), Color(0.5, 0.12, 0.16), Color(0.82, 0.72, 0.56), Color(0.35, 0.38, 0.25)]
const TIES := [Color(0.85, 0.1, 0.12), Color(0.15, 0.32, 0.85), Color(0.08, 0.08, 0.1), Color(0.98, 0.78, 0.15),
	Color(0.96, 0.5, 0.72), Color(0.6, 0.5, 0.25), Color(0.15, 0.55, 0.3)]

## Catalogue du vestiaire (cle de look -> valeurs possibles). "" = rien.
const CATALOG := {
	"style": ["curly", "bun", "sidepart", "mohawk", "bob", "bowl", "puff", "long", "buns2", "messy", "afro", "short", "bald"],
	"body": ["reg", "slim", "fat"],
	"glasses": ["", "round", "square", "heart", "star", "3d"],
	"mustache": ["", "walrus", "thin", "curly"],
	"hat": ["", "halo", "crown", "cap", "tophat", "tinfoil", "beanie", "propeller", "antenna", "star", "horns", "headband"],
	"neck": ["", "tie", "double", "bowtie"],
	"legs": ["long", "cuffed", "shorts", "skirt"],
	"shoes": ["oxford", "sneaker", "sandal", "croc", "boot", "bunny"],
	"wings": ["", "white", "black", "gold"],
	"pin": ["", "star", "flower", "butterfly"],
	"held": ["", "mug", "book"],
}

## LES 12 EMPLOYES (planches de reference du jeu).
const PRESETS := {
	"ted": {"name": "TED", "fr": "L'optimiste", "en": "The Optimist", "look": {
		"skin": Color(0.99, 0.84, 0.72), "hair": Color(0.97, 0.83, 0.47), "style": "curly", "body": "reg",
		"shirt": Color(0.96, 0.92, 0.84), "pants": Color(0.25, 0.32, 0.52), "legs": "cuffed", "shoes": "sneaker", "shoe_col": Color(0.3, 0.38, 0.55),
		"neck": "tie", "tie_col": Color(0.86, 0.1, 0.12), "hat": "headband", "hat_col": Color(0.86, 0.1, 0.12),
		"badge": true, "pin": "star", "belt": Color(0.15, 0.1, 0.08)}},
	"nova": {"name": "NOVA", "fr": "L'analyste", "en": "The Analyst", "look": {
		"fem": true, "skin": Color(0.42, 0.26, 0.17), "hair": Color(0.1, 0.07, 0.06), "style": "bun", "body": "reg",
		"shirt": Color(0.62, 0.42, 0.85), "pants": Color(0.62, 0.48, 0.28), "legs": "shorts", "socks": Color(0.95, 0.95, 0.95), "sock_pat": 3.0,
		"shoes": "sandal", "shoe_col": Color(0.12, 0.1, 0.09), "neck": "bowtie", "tie_col": Color(0.92, 0.15, 0.15),
		"suspenders": Color(0.95, 0.93, 0.88), "glasses": "round", "badge": true}},
	"benoit": {"name": "BENOÎT", "fr": "Le vétéran", "en": "The Veteran", "look": {
		"skin": Color(0.97, 0.79, 0.66), "hair": Color(0.42, 0.26, 0.15), "style": "sidepart", "body": "reg", "age": 55,
		"shirt": Color(0.96, 0.92, 0.84), "pants": Color(0.24, 0.22, 0.22), "shoes": "oxford", "neck": "tie", "tie_col": Color(0.86, 0.12, 0.12),
		"mustache": "walrus", "pens": true, "held": "mug", "belt": Color(0.12, 0.1, 0.08), "buckle": "eye"}},
	"ziggy": {"name": "ZIGGY", "fr": "Le stagiaire", "en": "The Intern", "look": {
		"skin": Color(0.47, 0.3, 0.2), "hair": Color(0.1, 0.07, 0.06), "style": "mohawk", "body": "slim", "height": 0.94,
		"shirt": Color(0.18, 0.72, 0.78), "pants": Color(0.12, 0.12, 0.16), "shoes": "oxford", "neck": "tie", "tie_col": Color(0.08, 0.08, 0.1),
		"glasses": "round", "badge": true}},
	"angel": {"name": "ANGEL", "fr": "L'employé modèle", "en": "The People Person", "look": {
		"fem": true, "skin": Color(0.99, 0.84, 0.72), "hair": Color(0.98, 0.85, 0.5), "style": "bob", "body": "reg",
		"shirt": Color(0.88, 0.16, 0.16), "collar": Color(0.97, 0.95, 0.9), "pants": Color(0.86, 0.77, 0.6), "shoes": "oxford",
		"hat": "halo", "pin": "butterfly", "badge": true}},
	"marc": {"name": "MARC", "fr": "Le surproductif", "en": "The Overachiever", "look": {
		"skin": Color(0.98, 0.84, 0.7), "hair": Color(0.08, 0.06, 0.06), "style": "bowl", "body": "reg",
		"shirt": Color(0.98, 0.78, 0.22), "pants": Color(0.12, 0.13, 0.18), "shoes": "oxford", "neck": "double",
		"tie_col": Color(0.15, 0.32, 0.85), "tie2_col": Color(0.88, 0.12, 0.12), "glasses": "round", "teeth": true, "pens": true}},
	"ray": {"name": "RAY", "fr": "La tendance", "en": "The Trendsetter", "look": {
		"fem": true, "skin": Color(0.4, 0.25, 0.16), "hair": Color(0.97, 0.85, 0.5), "style": "puff", "body": "reg",
		"shirt": Color(0.96, 0.92, 0.84), "sleeves": "short", "pants": Color(0.5, 0.1, 0.14), "shoes": "oxford",
		"belt": Color(0.82, 0.6, 0.25), "belt_pat": 4.0, "earrings": true, "lids": 0.5, "badge": true}},
	"gus": {"name": "GUS", "fr": "Le soutien", "en": "The Support", "look": {
		"skin": Color(0.99, 0.86, 0.74), "hair": Color(0.08, 0.06, 0.06), "style": "bowl", "body": "fat",
		"shirt": Color(0.25, 0.68, 0.6), "pants": Color(0.4, 0.3, 0.22), "legs": "cuffed", "socks": Color(0.95, 0.95, 0.95), "sock_pat": 1.0,
		"shoes": "bunny", "neck": "tie", "tie_col": Color(0.96, 0.52, 0.72), "suspenders": Color(0.3, 0.2, 0.14), "pin": "flower"}},
	"sophie": {"name": "SOPHIE", "fr": "La croyante", "en": "The Believer", "look": {
		"fem": true, "skin": Color(0.99, 0.85, 0.74), "hair": Color(0.45, 0.27, 0.15), "style": "long", "body": "slim", "height": 0.96,
		"shirt": Color(0.96, 0.93, 0.86), "pants": Color(0.2, 0.18, 0.18), "legs": "skirt", "socks": Color(0.97, 0.97, 0.97),
		"shoes": "oxford", "wings": "white", "held": "book", "badge": true}},
	"diego": {"name": "DIEGO", "fr": "Le facilitateur", "en": "The Facilitator", "look": {
		"skin": Color(0.5, 0.32, 0.21), "hair": Color(0.1, 0.07, 0.06), "style": "short", "body": "reg",
		"shirt": Color(0.6, 0.42, 0.85), "pants": Color(0.12, 0.12, 0.15), "shoes": "croc", "shoe_col": Color(0.98, 0.82, 0.15),
		"neck": "tie", "tie_col": Color(0.66, 0.55, 0.3), "glasses": "round", "mustache": "thin", "headset": true, "badge": true}},
	"lea": {"name": "LÉA", "fr": "La créative", "en": "The Creative", "look": {
		"fem": true, "skin": Color(0.99, 0.84, 0.74), "hair": Color(0.98, 0.45, 0.68), "style": "buns2", "body": "slim",
		"shirt": Color(0.96, 0.92, 0.84), "pants": Color(0.1, 0.1, 0.12), "shoes": "sneaker", "shoe_col": Color(0.12, 0.12, 0.12), "shoe_pat": 2.0,
		"neck": "tie", "tie_col": Color(0.9, 0.3, 0.3), "tie_pat": 5.0, "glasses": "star", "glasses_col": Color(0.98, 0.8, 0.15), "earrings": true, "badge": true}},
	"sam": {"name": "SAM", "fr": "Le dissident", "en": "The Dissident", "look": {
		"skin": Color(0.98, 0.84, 0.72), "hair": Color(0.45, 0.25, 0.12), "style": "messy", "body": "reg",
		"shirt": Color(0.12, 0.12, 0.14), "top": "hoodie", "pants": Color(0.35, 0.38, 0.25), "shoes": "sneaker", "shoe_col": Color(0.82, 0.15, 0.15),
		"neck": "tie", "tie_col": Color(0.82, 0.12, 0.12), "hat": "beanie", "hat_col": Color(0.78, 0.15, 0.15), "held": "mug", "lids": 0.45, "badge": true}},
}
const PRESET_ORDER := ["ted", "nova", "benoit", "ziggy", "angel", "marc", "ray", "gus", "sophie", "diego", "lea", "sam"]

const BODY := {
	"reg": {"w": 1.1, "d": 1.05, "front": -0.03},
	"fat": {"w": 1.22, "d": 1.12, "front": -0.085},
	"slim": {"w": 0.86, "d": 0.9, "front": 0.016},
}
const HEAD_Y := 0.88
const HEAD_R := 0.25

static var _mesh_cache := {}
static var _mat_cache := {}
static var big_heads := false   # humeur du jour « TETES ENORMES »

var look := {}
var head: Node3D
var torso: Node3D
var arms := []          # [[epaule, coude], ...] gauche puis droite
var legs := []          # pivots de hanche
var knees := []
var face_mat: ShaderMaterial
var eye_mats := []
var lids := []
var brows := []
var look_target: Node3D = null
var look_point := Vector3.ZERO
var pose := "stand"

var _talk := 0.0
var _blink_t := 2.0
var _t := 0.0
var _emo := {"smile": 0.0, "brow": 0.0, "raise": 0.0}
var _emo_target := {"smile": 0.0, "brow": 0.0, "raise": 0.0}
var _gesture := 0.0
var typing := false
var walking := false
var _walk := 0.0
var anim_speed := 1.0
var emo_name := "neutral"
var root_node: Node3D
var spinner: Node3D = null
var pompom: Node3D = null
var steam: GPUParticles3D = null
var wings_node: Node3D = null
var cur_emote := ""
var emote_t := 0.0
var _last_pos := Vector3.ZERO
var _vel := Vector3.ZERO
var _wob := Vector2.ZERO
var _wob_v := Vector2.ZERO
var bounce := 0.0
var daze_t := 0.0
var stars: Node3D = null
var head_spin := 0.0
var lid_rest := 0.35


# ------------------------------------------------------------- apparences

static func preset(id: String) -> Dictionary:
	var p: Dictionary = PRESETS.get(id, PRESETS["ted"])
	var lk := default_look()
	for k in p["look"]:
		lk[k] = p["look"][k]
	lk["preset"] = id
	lk["badge_name"] = p["name"]
	return lk


static func default_look() -> Dictionary:
	return {
		"fem": false, "age": 32, "kid": false, "skin": SKINS[0], "hair": HAIRS[1], "style": "short",
		"body": "reg", "height": 1.0, "shirt": SHIRTS[0], "collar": null, "sleeves": "long", "top": "shirt",
		"shirt_pat": 0.0, "pants": PANTS[0], "legs": "long", "socks": Color(0.95, 0.95, 0.95), "sock_pat": 0.0,
		"shoes": "oxford", "shoe_col": Color(0.12, 0.09, 0.08), "shoe_pat": 0.0,
		"neck": "", "tie_col": TIES[0], "tie2_col": TIES[1], "tie_pat": 0.0, "suspenders": null,
		"belt": Color(0.12, 0.09, 0.08), "belt_pat": 0.0, "buckle": "plain",
		"glasses": "", "glasses_col": Color(0.07, 0.07, 0.08), "mustache": "", "beard": false,
		"hat": "", "hat_col": Color(0.85, 0.15, 0.15), "headset": false, "badge": false, "pin": "", "pens": false,
		"wings": "", "held": "", "earrings": false, "teeth": false, "lids": 0.0, "eye": 1.0,
		"freckles": 0.0, "lipstick": 0.0, "blush": 0.3, "googly": 0.0,
	}


## Un humain qui prie (ou un collegue sans nom) : vetements civils varies.
static func random_look(rng: RandomNumberGenerator, opts := {}) -> Dictionary:
	var lk := default_look()
	var fem: bool = opts.get("fem", rng.randf() < 0.5)
	var age: int = int(opts.get("age", rng.randi_range(20, 70)))
	var kid := age < 13
	lk["fem"] = fem
	lk["age"] = age
	lk["kid"] = kid
	lk["skin"] = SKINS[rng.randi() % SKINS.size()]
	var hc: Color = HAIRS[rng.randi() % HAIRS.size()]
	if age > 62:
		hc = Color(0.8, 0.8, 0.82).lerp(Color(0.97, 0.97, 0.97), rng.randf())
	elif age > 48 and rng.randf() < 0.5:
		hc = hc.lerp(Color(0.72, 0.72, 0.74), 0.5)
	elif rng.randf() < 0.1:
		hc = DYED[rng.randi() % DYED.size()]
	lk["hair"] = hc
	var sm := ["short", "bowl", "messy", "mohawk", "sidepart", "afro", "curly", "bald", "short"]
	var sf := ["bob", "long", "bun", "buns2", "puff", "afro", "curly", "long", "bob"]
	lk["style"] = (sf if fem else sm)[rng.randi() % (sf if fem else sm).size()]
	if age > 58 and not fem and rng.randf() < 0.5:
		lk["style"] = ["bald", "sidepart"][rng.randi() % 2]
	if kid and lk["style"] in ["bald", "sidepart"]:
		lk["style"] = "short"
	var bw := rng.randf()
	lk["body"] = "fat" if bw < 0.28 and not kid else ("slim" if bw > 0.75 else "reg")
	lk["height"] = rng.randf_range(0.93, 1.06) if not kid else 0.66
	lk["shirt"] = SHIRTS[rng.randi() % SHIRTS.size()]
	lk["sleeves"] = "short" if rng.randf() < 0.3 else "long"
	lk["top"] = "hoodie" if rng.randf() < 0.15 else "shirt"
	if rng.randf() < 0.15:
		lk["shirt_pat"] = float([1, 2, 3][rng.randi() % 3])
		lk["shirt_pat_col"] = SHIRTS[rng.randi() % SHIRTS.size()]
	lk["pants"] = PANTS[rng.randi() % PANTS.size()]
	lk["legs"] = ["long", "long", "long", "shorts", "cuffed"][rng.randi() % 5]
	if fem and rng.randf() < 0.3:
		lk["legs"] = "skirt"
	lk["shoes"] = ["oxford", "sneaker", "sneaker", "sandal", "croc", "boot"][rng.randi() % 6]
	lk["shoe_col"] = [Color(0.12, 0.09, 0.08), Color(0.95, 0.95, 0.95), Color(0.3, 0.38, 0.55), Color(0.85, 0.2, 0.2), Color(0.45, 0.3, 0.18)][rng.randi() % 5]
	lk["socks"] = SHIRTS[rng.randi() % SHIRTS.size()]
	if not kid and rng.randf() < 0.3:
		lk["neck"] = ["tie", "tie", "bowtie"][rng.randi() % 3]
		lk["tie_col"] = TIES[rng.randi() % TIES.size()]
	lk["glasses"] = (["round", "square", "round", "heart"][rng.randi() % 4]) if rng.randf() < (0.45 if age > 45 else 0.2) else ""
	if not fem and not kid and rng.randf() < 0.3:
		lk["mustache"] = ["walrus", "thin", "curly"][rng.randi() % 3]
	lk["beard"] = not fem and not kid and rng.randf() < 0.15
	if rng.randf() < 0.15:
		lk["hat"] = ["cap", "beanie", "tophat", "propeller", "crown", "tinfoil"][rng.randi() % 6]
		lk["hat_col"] = TIES[rng.randi() % TIES.size()]
	lk["suspenders"] = TIES[rng.randi() % TIES.size()] if rng.randf() < 0.12 else null
	lk["earrings"] = fem and rng.randf() < 0.4
	lk["lipstick"] = rng.randf_range(0.4, 1.0) if fem and not kid and rng.randf() < 0.5 else 0.0
	lk["freckles"] = rng.randf_range(0.5, 1.0) if rng.randf() < 0.2 else 0.0
	lk["googly"] = rng.randf_range(0.5, 1.0) if rng.randf() < 0.15 else 0.0
	lk["eye"] = rng.randf_range(0.9, 1.15) * (1.2 if kid else 1.0)
	lk["teeth"] = rng.randf() < 0.08
	lk["lids"] = rng.randf_range(0.3, 0.5) if rng.randf() < 0.12 else 0.0
	return lk


## Ancien format (v1/v2) -> nouveau format. Les profils sauvegardes restent valides.
static func normalize_look(src: Dictionary) -> Dictionary:
	var lk := default_look()
	for k in src:
		lk[k] = src[k]
	if typeof(lk.get("glasses")) == TYPE_BOOL:
		lk["glasses"] = "round" if lk["glasses"] else ""
	if typeof(lk.get("mustache")) == TYPE_BOOL:
		lk["mustache"] = "walrus" if lk["mustache"] else ""
	if typeof(lk.get("tie")) == TYPE_BOOL and lk["tie"] and str(lk["neck"]) == "":
		lk["neck"] = "tie"
	if typeof(lk.get("bowtie")) == TYPE_BOOL and lk["bowtie"]:
		lk["neck"] = "bowtie"
	var old_style := {"receding": "sidepart", "spiky": "messy", "slick": "short", "cap_hat": "short", "ponytail": "long", "curly": "curly"}
	if old_style.has(str(lk["style"])):
		lk["style"] = old_style[str(lk["style"])]
	if not (str(lk["style"]) in CATALOG["style"]):
		lk["style"] = "short"
	if src.has("width") and not src.has("body"):
		var w := float(src["width"])
		lk["body"] = "fat" if (w > 1.15 or bool(src.get("belly", false))) else ("slim" if w < 0.9 else "reg")
	if not BODY.has(str(lk["body"])):
		lk["body"] = "reg"
	return lk


# ------------------------------------------------------------- briques

static func mesh(name: String) -> Mesh:
	if _mesh_cache.has(name):
		return _mesh_cache[name]
	var m: Mesh = null
	var p := MDIR + name + ".obj"
	if ResourceLoader.exists(p):
		m = load(p)
	_mesh_cache[name] = m
	return m


## Matiere « pate a modeler » partagee (cache : peu de materiaux differents).
static func clay(c: Color, rough := 0.62, opts := {}) -> ShaderMaterial:
	var key := "%s|%.2f|%s" % [c.to_html(), rough, str(opts)]
	if _mat_cache.has(key):
		return _mat_cache[key]
	var m := ShaderMaterial.new()
	m.shader = CLAY
	m.set_shader_parameter("albedo", c)
	# style « RV There Yet? » : tout est mat et doux (sauf le metal)
	m.set_shader_parameter("rough", maxf(rough, 0.55 if float(opts.get("metal", 0.0)) > 0.4 else 0.78))
	m.set_shader_parameter("bumps", float(opts.get("bumps", 0.35)))
	m.set_shader_parameter("fabric", float(opts.get("fabric", 0.0)))
	m.set_shader_parameter("metal", float(opts.get("metal", 0.0)))
	m.set_shader_parameter("pattern", float(opts.get("pattern", 0.0)))
	m.set_shader_parameter("pattern_col", opts.get("pattern_col", Color(1, 1, 1)))
	m.set_shader_parameter("pattern_scale", float(opts.get("scale", 18.0)))
	if opts.has("rim"):
		m.set_shader_parameter("rim_amt", float(opts["rim"]))
	if opts.has("emit"):
		m.set_shader_parameter("emit", opts["emit"])
		m.set_shader_parameter("emit_energy", float(opts.get("energy", 2.0)))
	_mat_cache[key] = m
	return m


func _put(par: Node3D, mname: String, mat: Material, pos := Vector3.ZERO, rot := Vector3.ZERO, sc := Vector3.ONE) -> MeshInstance3D:
	var m := mesh(mname)
	var mi := MeshInstance3D.new()
	if m == null:
		# piece manquante (modeles pas encore importes) : petite sphere de secours
		var sm := SphereMesh.new()
		sm.radius = 0.05
		sm.height = 0.1
		m = sm
	mi.mesh = m
	mi.material_override = mat
	mi.position = pos
	mi.rotation = rot
	mi.scale = sc
	par.add_child(mi)
	return mi


func _col(k: String, dflt: Color) -> Color:
	var v = look.get(k, dflt)
	return v if typeof(v) == TYPE_COLOR else dflt


func _fabric(c: Color, pat := 0.0, pat_col := Color(1, 1, 1)) -> ShaderMaterial:
	return clay(c, 0.8, {"bumps": 0.22, "pattern": pat, "pattern_col": pat_col})


# ------------------------------------------------------------- construction

## p_pose : "stand", "sit" (assis), "bust" (haut du corps seulement)
func build(lk: Dictionary, p_pose := "stand") -> void:
	look = normalize_look(lk)
	pose = p_pose
	for c in get_children():
		c.queue_free()
	arms = []
	legs = []
	knees = []
	eye_mats = []
	lids = []
	brows = []
	spinner = null
	pompom = null
	steam = null
	wings_node = null
	stars = null
	var b: Dictionary = BODY[str(look["body"])]
	var w: float = b["w"]
	var front: float = b["front"]
	var hs: float = float(look.get("height", 1.0))
	var kid: bool = bool(look.get("kid", false))
	var body_id := str(look["body"])

	var skin_c := _col("skin", SKINS[0])
	var skin_m := clay(skin_c, 0.55, {"bumps": 0.25})
	var shirt_c := _col("shirt", SHIRTS[0])
	var shirt_m := _fabric(shirt_c, float(look.get("shirt_pat", 0.0)), _col("shirt_pat_col", Color(1, 1, 1)))
	var pants_m := _fabric(_col("pants", PANTS[0]))
	var hair_c := _col("hair", HAIRS[1])
	var hair_m := clay(hair_c, 0.85, {"bumps": 0.35, "rim": 0.12 + hair_c.v * 0.25})

	var root := Node3D.new()
	root.scale = Vector3(hs, hs, hs)
	add_child(root)
	root_node = root
	torso = Node3D.new()
	root.add_child(torso)

	# ---- tronc
	_put(torso, "torso_" + body_id, shirt_m)
	if pose != "bust":
		_put(torso, "hips_" + body_id, pants_m)
	if str(look["top"]) == "hoodie":
		_put(torso, "hoodie_hood", shirt_m)
	var collar_c: Color = _col("collar", shirt_c.lightened(0.06))
	_put(torso, "collar", _fabric(collar_c))
	_put(torso, "neck", skin_m)
	if pose != "bust" or true:
		var belt_c := _col("belt", Color(0.12, 0.09, 0.08))
		_put(torso, "belt_" + body_id, clay(belt_c, 0.45, {"bumps": 0.1, "pattern": float(look.get("belt_pat", 0.0)), "pattern_col": Color(0.95, 0.75, 0.35), "scale": 30.0}))
		var gold := clay(Color(0.98, 0.76, 0.28), 0.25, {"metal": 0.85, "bumps": 0.05})
		var bz := -0.162 * (float(b["d"]) * (1.16 if body_id == "reg" else 1.0)) + front * 0.4 - 0.02
		_put(torso, "buckle_eye" if str(look["buckle"]) == "eye" else "buckle", gold, Vector3(0, 0.11, bz))
	var tz := front   # decalage vers l'avant (ventre)
	match str(look["neck"]):
		"tie":
			_put(torso, "tie", _fabric(_col("tie_col", TIES[0]), float(look.get("tie_pat", 0.0)), Color(0.98, 0.9, 0.7)), Vector3(0, 0, tz))
		"double":
			_put(torso, "tie", _fabric(_col("tie_col", TIES[1])), Vector3(-0.055, 0, tz), Vector3(0, 0, -0.08))
			_put(torso, "tie", _fabric(_col("tie2_col", TIES[0])), Vector3(0.055, -0.02, tz - 0.004), Vector3(0, 0, 0.1))
		"bowtie":
			_put(torso, "bowtie", clay(_col("tie_col", TIES[0]), 0.6, {"bumps": 0.2}), Vector3(0, 0, 0.0))
	if look.get("suspenders") != null and typeof(look["suspenders"]) == TYPE_COLOR:
		_put(torso, "suspenders_" + body_id, clay(look["suspenders"], 0.55, {"bumps": 0.15}))
	if bool(look.get("badge", false)):
		_put(torso, "lanyard", clay(Color(0.12, 0.14, 0.3), 0.7), Vector3(0, 0, tz * 0.6))
		var card := _put(torso, "badge", clay(Color(0.97, 0.97, 0.95), 0.4, {"bumps": 0.05}), Vector3(0, 0.33, -0.19 * float(b["d"]) + tz * 0.6))
		var eye_l := Label3D.new()
		eye_l.text = "G.O.D"
		eye_l.font = Loc.font("title")
		eye_l.font_size = 30
		eye_l.pixel_size = 0.0009
		eye_l.outline_size = 0
		eye_l.modulate = Color(0.15, 0.15, 0.2)
		eye_l.position = Vector3(0, -0.035, -0.006)
		eye_l.rotation_degrees = Vector3(0, 180, 0)
		eye_l.no_depth_test = false
		card.add_child(eye_l)
	if bool(look.get("pens", false)):
		_put(torso, "pocket_pens", clay(shirt_c.darkened(0.08), 0.8), Vector3(0.11 * w, 0.42, -0.155 * float(b["d"]) + front * 0.3), Vector3(0.15, 0, 0))
	match str(look["pin"]):
		"star":
			_put(torso, "pin_star", clay(Color(0.98, 0.8, 0.25), 0.3, {"metal": 0.7}), Vector3(-0.12 * w, 0.42, -0.155 * float(b["d"]) + front * 0.3), Vector3(0.15, 0, 0))
		"flower":
			_put(torso, "pin_flower", clay(Color(0.98, 0.95, 0.9), 0.5), Vector3(-0.12 * w, 0.42, -0.16 * float(b["d"]) + front * 0.3), Vector3(0.15, 0, 0))
		"butterfly":
			_put(torso, "pin_butterfly", clay(Color(0.98, 0.78, 0.2), 0.35, {"metal": 0.5}), Vector3(-0.12 * w, 0.42, -0.155 * float(b["d"]) + front * 0.3), Vector3(0.15, 0, 0))
	match str(look["wings"]):
		"white", "black", "gold":
			var wc: Color = {"white": Color(0.98, 0.97, 0.94), "black": Color(0.1, 0.1, 0.12), "gold": Color(0.98, 0.78, 0.3)}[str(look["wings"])]
			wings_node = _put(torso, "wings", clay(wc, 0.5 if str(look["wings"]) != "gold" else 0.3, {"bumps": 0.6, "metal": 0.6 if str(look["wings"]) == "gold" else 0.0}), Vector3(0, 0, 0.0))

	# ---- tete
	head = Node3D.new()
	var hscale := 1.32 if kid else 1.14
	head.position = Vector3(0, HEAD_Y, 0)
	head.scale = Vector3.ONE * hscale
	torso.add_child(head)
	face_mat = ShaderMaterial.new()
	face_mat.shader = FACE
	face_mat.set_shader_parameter("skin", skin_c)
	face_mat.set_shader_parameter("lipstick", float(look.get("lipstick", 0.0)))
	face_mat.set_shader_parameter("lip_col", Color(0.75, 0.12, 0.22))
	face_mat.set_shader_parameter("blush", float(look.get("blush", 0.3)))
	face_mat.set_shader_parameter("freckles", float(look.get("freckles", 0.0)))
	face_mat.set_shader_parameter("wrinkles", clampf((float(look.get("age", 30)) - 48.0) / 30.0, 0.0, 1.0))
	face_mat.set_shader_parameter("mouth_w", 0.2)
	_put(head, "head", face_mat)
	_put(head, "nose", skin_m, Vector3(0, -0.02, -0.245))
	# yeux 3D
	var es := float(look.get("eye", 1.0)) * (1.0 + float(look.get("googly", 0.0)) * 0.3)
	lid_rest = lerpf(1.0, -0.55, clampf(float(look.get("lids", 0.0)) * 1.6, 0.0, 1.0))
	for sx in [-1.0, 1.0]:
		var em := ShaderMaterial.new()
		em.shader = EYE
		em.set_shader_parameter("skin", skin_c)
		em.set_shader_parameter("side", sx)
		em.set_shader_parameter("pupil", 0.5 if float(look.get("googly", 0.0)) < 0.5 else 0.36)
		var e := _put(head, "eye", em, Vector3(sx * 0.088, 0.03, -0.212), Vector3.ZERO, Vector3(0.8, 1.0, 0.75) * es * (1.0 + float(look.get("googly", 0.0)) * 0.5))
		eye_mats.append(em)
		var lid := _put(e, "lid", skin_m, Vector3.ZERO, Vector3(lid_rest, 0, 0))
		lids.append(lid)
		var br := _put(head, "brow", clay(_col("hair", HAIRS[1]).darkened(0.3), 0.8), Vector3(sx * 0.095, 0.125, -0.225), Vector3(0, 0, -sx * 0.1))
		brows.append(br)
	if bool(look.get("teeth", false)):
		_put(head, "teeth", clay(Color(0.99, 0.98, 0.95), 0.3, {"bumps": 0.0}), Vector3(0, -0.085, -0.238))
	match str(look["mustache"]):
		"walrus", "thin", "curly":
			_put(head, "mustache_" + str(look["mustache"]), hair_m, Vector3(0, -0.062, -0.238))
	if bool(look.get("beard", false)):
		_put(head, "beard", hair_m)
	if str(look["style"]) != "bald":
		_put(head, "hair_" + str(look["style"]), hair_m)
	if bool(look.get("earrings", false)):
		var gold2 := clay(Color(0.98, 0.78, 0.3), 0.25, {"metal": 0.85})
		for sx in [-1.0, 1.0]:
			_put(head, "earring", gold2, Vector3(sx * 0.252, -0.05, 0.02))
	var gl := str(look["glasses"])
	if gl != "":
		var gc := _col("glasses_col", Color(0.07, 0.07, 0.08))
		var gm := clay(gc, 0.3, {"bumps": 0.05, "metal": 0.3 if gl == "star" else 0.0})
		_put(head, "glasses_" + gl, gm)
		if gl in ["heart", "star"]:
			var lens := StandardMaterial3D.new()
			lens.albedo_color = Color(0.9, 0.2, 0.35, 0.55) if gl == "heart" else Color(0.15, 0.1, 0.05, 0.6)
			lens.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
			lens.roughness = 0.1
			for sx in [-1.0, 1.0]:
				_put(head, "lens_round", lens, Vector3(sx * 0.085, 0.035, -0.255), Vector3.ZERO, Vector3(0.85, 0.85, 1.0))
	if bool(look.get("headset", false)):
		_put(head, "headset", clay(Color(0.1, 0.1, 0.12), 0.35, {"bumps": 0.05}))
	_hat(head, str(look["hat"]))

	# ---- bras (pivot a l'epaule)
	var short := str(look["sleeves"]) == "short"
	for i in 2:
		var sx := -1.0 if i == 0 else 1.0
		var sh := Node3D.new()
		sh.position = Vector3(sx * 0.25 * w, 0.5, 0)
		torso.add_child(sh)
		_put(sh, "arm_up", shirt_m, Vector3.ZERO, Vector3.ZERO, Vector3(1, 1 if not short else 0.55, 1))
		if short:
			_put(sh, "arm_lo", skin_m, Vector3(0, -0.1, 0), Vector3.ZERO, Vector3(0.85, 0.9, 0.85))
		var el := Node3D.new()
		el.position = Vector3(0, -0.26, 0)
		sh.add_child(el)
		_put(el, "arm_lo", skin_m if short else shirt_m)
		if not short:
			_put(el, "cuff", _fabric(collar_c))
		var hand := _put(el, "hand", skin_m, Vector3.ZERO, Vector3.ZERO, Vector3(-sx, 1, 1))
		if i == 1:
			match str(look["held"]):
				"mug":
					var mug := _put(el, "mug", clay(Color(0.97, 0.96, 0.93), 0.35, {"bumps": 0.05}), Vector3(-0.02, -0.31, -0.07), Vector3(0, PI * 0.5, 0))
					var lb := Label3D.new()
					lb.text = "GOD\nFUEL"
					lb.font = Loc.font("title")
					lb.font_size = 22
					lb.pixel_size = 0.0012
					lb.modulate = Color(0.1, 0.1, 0.1)
					lb.position = Vector3(0, 0.0, -0.057)
					lb.rotation_degrees = Vector3(0, 180, 0)
					mug.add_child(lb)
				"book":
					_put(el, "book", clay(Color(0.15, 0.4, 0.22), 0.6), Vector3(0, -0.3, -0.06), Vector3(0, 0, 0.2))
		arms.append([sh, el])

	# ---- jambes
	if pose != "bust":
		var legs_kind := str(look["legs"])
		if legs_kind == "skirt":
			_put(torso, "skirt", pants_m, Vector3(0, 0.0, 0), Vector3.ZERO, Vector3(w, 1, float(b["d"])))
		var sock_m := _fabric(_col("socks", Color(0.95, 0.95, 0.95)), float(look.get("sock_pat", 0.0)), Color(0.85, 0.2, 0.25))
		var shoe_m := clay(_col("shoe_col", Color(0.12, 0.09, 0.08)), 0.35, {"bumps": 0.1, "pattern": float(look.get("shoe_pat", 0.0)), "pattern_col": Color(0.95, 0.95, 0.95), "scale": 30.0})
		for i in 2:
			var sx := -1.0 if i == 0 else 1.0
			var hip := Node3D.new()
			hip.position = Vector3(sx * 0.11 * w, -0.02, 0)
			torso.add_child(hip)
			legs.append(hip)
			var bare_thigh := legs_kind == "skirt"
			_put(hip, "thigh", skin_m if bare_thigh else pants_m, Vector3.ZERO, Vector3.ZERO, Vector3(0.62, 1, 0.62) if bare_thigh else Vector3.ONE)
			var knee := Node3D.new()
			knee.position = Vector3(0, -0.3, 0)
			hip.add_child(knee)
			knees.append(knee)
			match legs_kind:
				"shorts", "skirt":
					if legs_kind == "shorts":
						_put(knee, "short_hem", pants_m, Vector3(0, 0.07, 0))
					_put(knee, "shin_skin", skin_m)
					_put(knee, "sock", sock_m)
				"cuffed":
					_put(knee, "shin", pants_m, Vector3.ZERO, Vector3.ZERO, Vector3(1, 0.93, 1))
					_put(knee, "pant_cuff", _fabric(_col("pants", PANTS[0]).lightened(0.12)), Vector3(0, 0.0, 0))
					_put(knee, "sock", sock_m, Vector3(0, -0.01, 0), Vector3.ZERO, Vector3(0.95, 0.6, 0.95))
				_:
					_put(knee, "shin", pants_m)
			match str(look["shoes"]):
				"sneaker":
					_put(knee, "shoe_sneaker", shoe_m)
					_put(knee, "sneaker_sole", clay(Color(0.97, 0.96, 0.93), 0.5, {"bumps": 0.05}))
				"sandal":
					_put(knee, "foot_bare", skin_m)
					_put(knee, "sandal", clay(_col("shoe_col", Color(0.3, 0.2, 0.12)), 0.5))
				"croc":
					_put(knee, "croc", clay(_col("shoe_col", Color(0.98, 0.82, 0.15)), 0.45, {"bumps": 0.05}))
				"boot":
					_put(knee, "boot", shoe_m)
				"bunny":
					_put(knee, "slipper_bunny", clay(Color(0.98, 0.7, 0.8), 0.95, {"bumps": 1.2}))
				_:
					_put(knee, "shoe_oxford", shoe_m)
	_set_pose_legs()
	_set_arm_rest()
	if big_heads:
		set_big_head(true)


func _set_pose_legs() -> void:
	for i in legs.size():
		var hip: Node3D = legs[i]
		var knee: Node3D = knees[i]
		if pose == "sit":
			hip.rotation = Vector3(PI * 0.5, 0, 0)
			knee.rotation = Vector3(-PI * 0.5, 0, 0)
		else:
			hip.rotation = Vector3.ZERO
			knee.rotation = Vector3.ZERO


func _hat(h: Node3D, kind: String) -> void:
	var hc := _col("hat_col", Color(0.85, 0.15, 0.15))
	var gold := clay(Color(0.99, 0.78, 0.28), 0.25, {"metal": 0.85, "bumps": 0.05})
	var top := Vector3(0, HEAD_R * 0.92, 0)
	match kind:
		"halo":
			var hm := clay(Color(1.0, 0.86, 0.4), 0.3, {"emit": Color(1.0, 0.8, 0.35), "energy": 2.5, "bumps": 0.0})
			spinner = _put(h, "halo", hm, Vector3(0, 0.39, 0.01))
		"crown":
			_put(h, "crown", gold, top + Vector3(0, -0.05, 0))
		"cap":
			_put(h, "cap", clay(hc, 0.75, {"bumps": 0.2, "fabric": 1.0}), Vector3(0, 0.07, 0))
		"tophat":
			_put(h, "tophat", clay(Color(0.08, 0.08, 0.1), 0.6, {"bumps": 0.1}), top + Vector3(0, -0.03, 0))
		"tinfoil":
			_put(h, "tinfoil", clay(Color(0.86, 0.88, 0.92), 0.25, {"metal": 0.9, "bumps": 0.2}), top + Vector3(0, -0.08, 0))
		"beanie":
			_put(h, "beanie", clay(hc, 0.9, {"fabric": 1.0, "bumps": 0.3}), Vector3(0, 0.07, 0))
		"propeller":
			_put(h, "propeller_cap", clay(Color(0.25, 0.45, 0.95), 0.6, {"pattern": 1.0, "pattern_col": Color(0.98, 0.85, 0.2), "scale": 10.0}), Vector3(0, 0.07, 0))
			spinner = Node3D.new()
			spinner.position = Vector3(0, 0.34, 0)
			h.add_child(spinner)
			_put(spinner, "propeller", clay(Color(0.95, 0.25, 0.25), 0.4))
			_put(spinner, "propeller", clay(Color(0.25, 0.8, 0.35), 0.4), Vector3.ZERO, Vector3(0, PI * 0.5, 0))
		"antenna":
			_put(h, "antenna", clay(Color(0.1, 0.1, 0.12), 0.4), Vector3.ZERO)
			pompom = h.get_child(h.get_child_count() - 1)
		"star":
			_put(h, "star_band", clay(Color(0.98, 0.8, 0.2), 0.3, {"metal": 0.6}))
		"horns":
			_put(h, "horns", clay(Color(0.85, 0.1, 0.1), 0.4))
		"headband":
			_put(h, "headband_tie", _fabric(hc))
		# anciens chapeaux (recompenses de succes)
		"party":
			var pm := clay(Color.from_hsv(randf(), 0.7, 0.95), 0.6, {"pattern": 1.0, "pattern_col": Color(1, 0.95, 0.4), "scale": 25.0})
			var cone := MeshInstance3D.new()
			var cm := CylinderMesh.new()
			cm.top_radius = 0.0
			cm.bottom_radius = 0.11
			cm.height = 0.26
			cone.mesh = cm
			cone.material_override = pm
			cone.position = top + Vector3(0.03, 0.1, 0)
			cone.rotation_degrees = Vector3(0, 0, -12)
			h.add_child(cone)
		"cowboy", "bowler", "wizard", "chef", "mitre", "viking":
			_put(h, "tophat", clay({"cowboy": Color(0.5, 0.32, 0.16), "bowler": Color(0.08, 0.08, 0.1), "wizard": Color(0.3, 0.18, 0.6),
				"chef": Color(0.97, 0.97, 0.95), "mitre": Color(0.96, 0.94, 0.88), "viking": Color(0.55, 0.55, 0.6)}[kind], 0.6), top + Vector3(0, -0.03, 0), Vector3.ZERO, Vector3(1.0, 0.7, 1.0))
		"flower":
			_put(h, "pin_flower", clay(Color.from_hsv(randf(), 0.6, 1.0), 0.5), Vector3(0.16, 0.14, -0.17), Vector3.ZERO, Vector3.ONE * 2.2)


# ------------------------------------------------------------- animation

func emote(id: String) -> void:
	cur_emote = id
	emote_t = 2.6
	match id:
		"laugh":
			set_emotion("laugh")
			say(2.4)
		"dance":
			set_emotion("happy")
		"facepalm":
			set_emotion("sad")
		"pray":
			set_emotion("love")
		"flex":
			set_emotion("proud")
		"tpose":
			set_emotion("neutral")
		"chicken":
			set_emotion("laugh")
		_:
			set_emotion("happy")


func _set_arm_rest() -> void:
	for i in arms.size():
		var sh: Node3D = arms[i][0]
		var el: Node3D = arms[i][1]
		var sx := -1.0 if i == 0 else 1.0
		if pose == "sit" or typing:
			sh.rotation = Vector3(-0.9, 0, sx * 0.12)
			el.rotation = Vector3(-0.7, 0, 0)
		else:
			sh.rotation = Vector3(0.05, 0, sx * 0.12)
			el.rotation = Vector3(-0.2, 0, 0)
		if i == 1 and str(look.get("held", "")) != "" and not typing:
			el.rotation = Vector3(-1.2, 0, 0)


func say(seconds: float) -> void:
	_talk = max(_talk, seconds)


func is_talking() -> bool:
	return _talk > 0.0


func set_emotion(e: String) -> void:
	match e:
		"happy":
			_emo_target = {"smile": 0.9, "brow": 0.0, "raise": 0.3}
		"worried":
			_emo_target = {"smile": -0.4, "brow": -0.9, "raise": 0.4}
		"angry":
			_emo_target = {"smile": -0.7, "brow": 1.0, "raise": 0.0}
		"shock":
			_emo_target = {"smile": -0.2, "brow": -0.3, "raise": 1.0}
		"sad":
			_emo_target = {"smile": -0.9, "brow": -1.0, "raise": 0.2}
		"laugh", "proud":
			_emo_target = {"smile": 1.0, "brow": -0.2, "raise": 0.4}
		"cry":
			_emo_target = {"smile": -1.0, "brow": -1.0, "raise": 0.5}
		"love":
			_emo_target = {"smile": 0.8, "brow": -0.3, "raise": 0.5}
		"fury":
			_emo_target = {"smile": -0.8, "brow": 1.0, "raise": 0.0}
		"dizzy":
			_emo_target = {"smile": -0.3, "brow": -0.5, "raise": 0.6}
		_:
			_emo_target = {"smile": 0.4, "brow": 0.0, "raise": 0.0}
	emo_name = e
	var mode := 0
	match e:
		"laugh":
			mode = 1
		"love":
			mode = 2
		"dizzy":
			mode = 3
	for em in eye_mats:
		(em as ShaderMaterial).set_shader_parameter("mode", mode)
	if face_mat != null:
		face_mat.set_shader_parameter("tears", 1.0 if e == "cry" else 0.0)
		face_mat.set_shader_parameter("fury", 1.0 if e == "fury" else 0.0)
		face_mat.set_shader_parameter("sweat", 1.0 if e in ["worried", "shock"] else 0.0)
		face_mat.set_shader_parameter("blush", 0.65 if e in ["love", "laugh", "happy"] else float(look.get("blush", 0.3)))
	if e == "fury":
		_make_steam()
	elif steam != null and is_instance_valid(steam):
		steam.emitting = false
	if e in ["shock", "laugh"]:
		bounce = 1.0


func _make_steam() -> void:
	if head == null:
		return
	if steam != null and is_instance_valid(steam):
		steam.emitting = true
		return
	steam = GPUParticles3D.new()
	var pm := ParticleProcessMaterial.new()
	pm.direction = Vector3(0, 1, 0)
	pm.spread = 25.0
	pm.initial_velocity_min = 0.3
	pm.initial_velocity_max = 0.6
	pm.gravity = Vector3(0, 0.2, 0)
	pm.scale_min = 0.6
	pm.scale_max = 1.4
	steam.process_material = pm
	var sm := SphereMesh.new()
	sm.radius = 0.04
	sm.height = 0.08
	var mat := StandardMaterial3D.new()
	mat.albedo_color = Color(1, 1, 1, 0.5)
	mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	sm.material = mat
	steam.draw_pass_1 = sm
	steam.amount = 16
	steam.lifetime = 0.8
	steam.position = Vector3(0, 0.3, 0)
	head.add_child(steam)


func _process(dt: float) -> void:
	if face_mat == null:
		return
	dt *= anim_speed
	_t += dt
	# clignement (les paupieres 3D descendent)
	_blink_t -= dt
	var closed := 0.0
	if _blink_t < 0.0:
		closed = 1.0
		if _blink_t < -0.12:
			_blink_t = randf_range(1.8, 5.5)
	if emo_name in ["laugh", "love", "dizzy"]:
		closed = 0.0
	var lid_x := lerpf(lid_rest, -PI * 0.5, closed)
	if emo_name == "shock":
		lid_x = 0.6
	for l in lids:
		(l as Node3D).rotation.x = lerpf((l as Node3D).rotation.x, lid_x, clampf(dt * 30.0, 0.0, 1.0))
	# emotions (lissees)
	for k in _emo:
		_emo[k] = lerp(float(_emo[k]), float(_emo_target[k]), clamp(dt * 4.0, 0.0, 1.0))
	face_mat.set_shader_parameter("smile", _emo["smile"])
	# sourcils 3D : montent (surprise), se froncent (colere), s'inclinent (inquietude)
	for i in brows.size():
		var br: Node3D = brows[i]
		var sx := -1.0 if i == 0 else 1.0
		br.position.y = 0.125 + float(_emo["raise"]) * 0.03 - maxf(float(_emo["brow"]), 0.0) * 0.012
		br.rotation.z = -sx * (0.1 + float(_emo["brow"]) * 0.35)
	# bouche
	var mo := 0.0
	if _talk > 0.0:
		_talk -= dt
		mo = clamp(0.25 + 0.55 * abs(sin(_t * 13.0)) * (0.6 + 0.4 * sin(_t * 3.1)), 0.0, 1.0)
		_gesture = lerp(_gesture, 1.0, dt * 3.0)
	else:
		_gesture = lerp(_gesture, 0.0, dt * 2.0)
	if _emo_target["raise"] > 0.9:
		mo = max(mo, 0.6)
	if emo_name == "laugh":
		mo = max(mo, 0.5 + 0.4 * abs(sin(_t * 18.0)))
	elif emo_name == "cry":
		mo = max(mo, 0.3 + 0.25 * abs(sin(_t * 9.0)))
	face_mat.set_shader_parameter("mouth_open", mo)
	# pupilles qui ballottent avec les mouvements
	var gp := global_position
	if dt > 0.0:
		_vel = _vel.lerp((gp - _last_pos) / dt, 0.3)
	_last_pos = gp
	var force := Vector2(-_vel.x, -_vel.y) * 0.4 + Vector2(randf_range(-1, 1), randf_range(-1, 1)) * (0.6 if _talk > 0.0 else 0.15)
	_wob_v += (force - _wob * 30.0) * dt
	_wob_v *= 0.9
	_wob += _wob_v * dt * 6.0
	_wob = _wob.limit_length(1.0)
	# accessoires vivants
	if spinner != null and is_instance_valid(spinner):
		spinner.rotation.y += dt * (25.0 if (walking or _talk > 0.0) else 6.0) * (0.15 if str(look.get("hat", "")) == "halo" else 1.0)
		if str(look.get("hat", "")) == "halo":
			spinner.position.y = 0.39 + sin(_t * 2.0) * 0.012
	if wings_node != null and is_instance_valid(wings_node):
		wings_node.scale.x = 1.0 + sin(_t * (9.0 if walking else 2.0)) * (0.08 if walking else 0.03)
	# rebond (rire, surprise), sanglots, emotes
	bounce = max(0.0, bounce - dt * 1.5)
	if root_node != null:
		var sq := 0.0
		if emo_name == "laugh":
			sq = abs(sin(_t * 14.0)) * 0.06
		elif emo_name == "cry":
			sq = sin(_t * 20.0) * 0.015
		root_node.position.y = abs(sin(bounce * PI * 3.0)) * bounce * 0.12
		var base_s := float(look.get("height", 1.0))
		root_node.scale = Vector3(base_s * (1.0 + sq * 0.5), base_s * (1.0 - sq), base_s * (1.0 + sq * 0.5))
	if emote_t > 0.0:
		emote_t -= dt
		_play_emote(dt)
		if emote_t <= 0.0:
			cur_emote = ""
			_set_arm_rest()
			if root_node != null:
				root_node.rotation = Vector3.ZERO
			set_emotion("neutral")
	_tick_daze(dt)
	# respiration (pate qui gonfle un peu) + tete
	if torso != null:
		torso.scale = Vector3(1.0 + sin(_t * 1.7) * 0.006, 1.0 + sin(_t * 1.7) * 0.01, 1.0)
	if head != null:
		var want := Vector3(sin(_t * 0.7) * 0.05, sin(_t * 0.43) * 0.12, sin(_t * 0.9) * 0.03 * _gesture)
		var target := look_point
		if look_target != null and is_instance_valid(look_target):
			target = look_target.global_position
		if target != Vector3.ZERO:
			var lp: Vector3 = (head.get_parent() as Node3D).to_local(target) - head.position
			var yaw := atan2(-lp.x, -lp.z)
			var pit := atan2(lp.y, Vector2(lp.x, lp.z).length())
			want.y += clamp(yaw, -1.0, 1.0)
			want.x += clamp(pit, -0.5, 0.5)
		if _talk > 0.0:
			want.x += sin(_t * 6.0) * 0.04
		if daze_t > 0.0:
			want += Vector3(sin(_t * 7.0) * 0.25, sin(_t * 5.0) * 0.4, sin(_t * 6.0) * 0.3)
		if head_spin > 0.0:
			head.rotation.y += dt * 18.0 * head_spin
			head_spin = maxf(0.0, head_spin - dt * 0.9)
		elif not (emote_t > 0.0 and cur_emote in ["laugh", "facepalm", "chicken"]):
			head.rotation = head.rotation.lerp(want, clamp(dt * 4.0, 0.0, 1.0))
		var lk2 := Vector2(clamp(-want.y * 0.6, -1.0, 1.0), clamp(want.x, -1.0, 1.0))
		for em in eye_mats:
			(em as ShaderMaterial).set_shader_parameter("look", lk2)
			(em as ShaderMaterial).set_shader_parameter("wobble", _wob * (0.4 + float(look.get("googly", 0.0))))
	# marche
	if walking:
		_walk += dt * 7.0
		for i in legs.size():
			var lg: Node3D = legs[i]
			lg.rotation.x = sin(_walk + float(i) * PI) * 0.5
			(knees[i] as Node3D).rotation.x = -maxf(0.0, sin(_walk + float(i) * PI + 0.6)) * 0.5
		if torso != null:
			torso.position.y = abs(sin(_walk)) * 0.03
			torso.rotation.z = sin(_walk) * 0.04
	elif not legs.is_empty() and pose == "stand":
		for i in legs.size():
			var lg2: Node3D = legs[i]
			lg2.rotation.x = lerp(lg2.rotation.x, 0.0, clamp(dt * 8.0, 0.0, 1.0))
			(knees[i] as Node3D).rotation.x = lerp((knees[i] as Node3D).rotation.x, 0.0, clamp(dt * 8.0, 0.0, 1.0))
		if torso != null:
			torso.rotation.z = lerpf(torso.rotation.z, 0.0, clampf(dt * 6.0, 0.0, 1.0))
	# bras : frappe au clavier ou gestes en parlant
	for i in (arms.size() if emote_t <= 0.0 else 0):
		var sh: Node3D = arms[i][0]
		var el: Node3D = arms[i][1]
		var sx := -1.0 if i == 0 else 1.0
		if typing:
			sh.rotation.x = -0.95 + sin(_t * 9.0 + float(i) * 1.7) * 0.06
			el.rotation.x = -0.75 + sin(_t * 11.0 + float(i)) * 0.08
		elif walking:
			sh.rotation.x = sin(_walk + float(i) * PI + PI) * 0.45
			sh.rotation.z = sx * 0.1
			el.rotation.x = -0.25
		elif pose == "bust" or pose == "stand":
			var g := _gesture * (0.5 + 0.5 * sin(_t * 2.3 + float(i) * 2.0))
			sh.rotation.x = lerp(0.05, -0.7, g * (1.0 if i == 1 else 0.6))
			sh.rotation.z = sx * (0.12 + g * 0.25)
			var rest_el := -1.2 if (i == 1 and str(look.get("held", "")) != "") else -0.2
			el.rotation.x = lerp(rest_el, -1.2, g)


# ------------------------------------------------------------- slapstick

## Etourdi : etoiles qui tournent autour de la tete, tete qui ballotte.
func daze(secs: float) -> void:
	daze_t = maxf(daze_t, secs)
	set_emotion("dizzy")
	if stars == null and head != null:
		stars = Node3D.new()
		stars.position = Vector3(0, 0.38, 0)
		head.add_child(stars)
		var sm := clay(Color(1.0, 0.88, 0.25), 0.3, {"emit": Color(1.0, 0.85, 0.2), "energy": 1.5, "bumps": 0.0})
		for k in 4:
			var a := TAU * float(k) / 4.0
			_put(stars, "pin_star", sm, Vector3(cos(a) * 0.28, 0.0, sin(a) * 0.28), Vector3.ZERO, Vector3.ONE * 2.0)


## La gifle : la tete fait deux tours sur elle-meme.
func slapped() -> void:
	head_spin = 1.0
	bounce = 1.0
	daze(2.5)


func _tick_daze(dt: float) -> void:
	if daze_t <= 0.0:
		return
	daze_t -= dt
	if stars != null:
		stars.rotation.y += dt * 6.0
		stars.position.y = 0.38 + sin(_t * 4.0) * 0.02
	if daze_t <= 0.0:
		if stars != null:
			stars.queue_free()
			stars = null
		set_emotion("neutral")


## Glissade : on tombe sur le dos, les jambes en l'air, puis on se releve.
func fall() -> void:
	if root_node == null:
		return
	set_emotion("dizzy")
	var tw := create_tween()
	tw.tween_property(root_node, "rotation:x", 1.45, 0.25).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)
	tw.tween_interval(1.4)
	tw.tween_property(root_node, "rotation:x", 0.0, 0.35).set_trans(Tween.TRANS_BACK)
	tw.tween_callback(set_emotion.bind("neutral"))


## Coup de main pour la gifle (bras droit qui balaie).
func swing() -> void:
	if arms.size() < 2:
		return
	var sh: Node3D = arms[1][0]
	cur_emote = "slap"
	emote_t = 0.5
	var tw := create_tween()
	tw.tween_property(sh, "rotation", Vector3(-1.4, 0, 1.6), 0.08)
	tw.tween_property(sh, "rotation", Vector3(-1.4, 0, -0.6), 0.12)


## Recu en pleine face : tarte, beigne, poisson... une tache qui coule.
func splat(col: Color) -> void:
	if head == null:
		return
	var m := clay(col, 0.25, {"bumps": 0.8})
	var blob := Node3D.new()
	blob.position = Vector3(0, 0.0, -0.24)
	head.add_child(blob)
	for k in 8:
		var mi := MeshInstance3D.new()
		var sm := SphereMesh.new()
		var r := randf_range(0.045, 0.09)
		sm.radius = r
		sm.height = r * 1.2
		mi.mesh = sm
		mi.material_override = m
		mi.position = Vector3(randf_range(-0.13, 0.13), randf_range(-0.12, 0.13), randf_range(-0.03, 0.0))
		mi.scale = Vector3(1.0, 1.0, 0.45)
		blob.add_child(mi)
	for k in 3:
		var dr := MeshInstance3D.new()
		var cm := CapsuleMesh.new()
		cm.radius = 0.018
		cm.height = 0.09
		dr.mesh = cm
		dr.material_override = m
		dr.position = Vector3(randf_range(-0.1, 0.1), -0.12, -0.01)
		blob.add_child(dr)
		var tw := dr.create_tween()
		tw.tween_property(dr, "position:y", -0.28, 3.0)
	set_emotion("shock")
	var tw2 := blob.create_tween()
	tw2.tween_interval(6.0)
	tw2.tween_property(blob, "scale", Vector3(0.01, 0.01, 0.01), 0.5)
	tw2.tween_callback(blob.queue_free)


## Le chapeau de la honte (cone de cancre).
func dunce(on: bool) -> void:
	if head == null:
		return
	var old := head.get_node_or_null("Dunce")
	if not on:
		if old != null:
			old.queue_free()
		return
	if old != null:
		return
	var d := Node3D.new()
	d.name = "Dunce"
	d.position = Vector3(0, 0.27, 0)
	head.add_child(d)
	var m := clay(Color(0.97, 0.96, 0.9), 0.8)
	var cone := MeshInstance3D.new()
	var cm := CylinderMesh.new()
	cm.top_radius = 0.0
	cm.bottom_radius = 0.18
	cm.height = 0.62
	cone.mesh = cm
	cone.material_override = m
	cone.position = Vector3(0, 0.28, 0)
	cone.rotation_degrees = Vector3(0, 0, 6)
	d.add_child(cone)
	var l := Label3D.new()
	l.text = "C"
	l.font_size = 64
	l.pixel_size = 0.004
	l.modulate = Color(0.85, 0.05, 0.05)
	l.position = Vector3(0, 0.2, -0.14)
	l.rotation_degrees = Vector3(0, 180, 0)
	d.add_child(l)
	var l2 := l.duplicate()
	l2.position = Vector3(0, 0.2, 0.14)
	l2.rotation_degrees = Vector3.ZERO
	d.add_child(l2)


func set_big_head(on: bool) -> void:
	if head != null:
		var k := 1.8 if on else (1.32 if bool(look.get("kid", false)) else 1.14)
		head.scale = Vector3(k, k, k)


func _play_emote(_dt: float) -> void:
	if arms.size() < 2:
		return
	var l_sh: Node3D = arms[0][0]
	var l_el: Node3D = arms[0][1]
	var r_sh: Node3D = arms[1][0]
	var r_el: Node3D = arms[1][1]
	match cur_emote:
		"wave":
			r_sh.rotation = Vector3(0.0, 0, 2.5)
			r_el.rotation = Vector3(0, 0, sin(_t * 12.0) * 0.6)
		"dance":
			var k := sin(_t * 9.0)
			l_sh.rotation = Vector3(0, 0, -1.2 - k * 0.6)
			r_sh.rotation = Vector3(0, 0, 1.2 - k * 0.6)
			l_el.rotation = Vector3(-1.0, 0, 0)
			r_el.rotation = Vector3(-1.0, 0, 0)
			if root_node != null:
				root_node.rotation.y = sin(_t * 4.5) * 0.6
				root_node.position.y = abs(k) * 0.08
		"laugh":
			l_sh.rotation = Vector3(-0.6, 0, -0.3)
			r_sh.rotation = Vector3(-0.6, 0, 0.3)
			l_el.rotation = Vector3(-1.6, 0, 0)
			r_el.rotation = Vector3(-1.6, 0, 0)
			if head != null:
				head.rotation.x = -0.3 + sin(_t * 16.0) * 0.08
		"facepalm":
			r_sh.rotation = Vector3(-1.5, 0, 0.35)
			r_el.rotation = Vector3(-1.9, 0, 0)
			if head != null:
				head.rotation.x = lerp(head.rotation.x, 0.35, 0.2)
		"pray":
			l_sh.rotation = Vector3(-1.3, 0, 0.45)
			r_sh.rotation = Vector3(-1.3, 0, -0.45)
			l_el.rotation = Vector3(-1.2, 0, 0)
			r_el.rotation = Vector3(-1.2, 0, 0)
		"point":
			r_sh.rotation = Vector3(-1.55, 0, 0)
			r_el.rotation = Vector3(0, 0, 0)
		"flex":
			l_sh.rotation = Vector3(0, 0, -1.5)
			r_sh.rotation = Vector3(0, 0, 1.5)
			l_el.rotation = Vector3(0, 0, -1.7 - sin(_t * 8.0) * 0.2)
			r_el.rotation = Vector3(0, 0, 1.7 + sin(_t * 8.0) * 0.2)
		"tpose":
			l_sh.rotation = Vector3(0, 0, -1.57)
			r_sh.rotation = Vector3(0, 0, 1.57)
			l_el.rotation = Vector3.ZERO
			r_el.rotation = Vector3.ZERO
			if root_node != null:
				root_node.rotation.y += _dt * 2.5
				root_node.position.y = 0.05 + sin(_t * 3.0) * 0.03
		"chicken":
			var fl := sin(_t * 16.0)
			l_sh.rotation = Vector3(0.2, 0, -0.5 - fl * 0.35)
			r_sh.rotation = Vector3(0.2, 0, 0.5 + fl * 0.35)
			l_el.rotation = Vector3(-2.2, 0, 0)
			r_el.rotation = Vector3(-2.2, 0, 0)
			if head != null:
				head.rotation.x = maxf(0.0, sin(_t * 8.0)) * 0.5
			if root_node != null:
				root_node.position.y = absf(sin(_t * 8.0)) * 0.05
