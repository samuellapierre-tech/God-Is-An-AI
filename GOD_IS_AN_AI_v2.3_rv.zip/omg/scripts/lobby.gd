extends PanelContainer
## Salon co-op du menu : heberger ou rejoindre une partie entre amis.

signal closed

const ORANGE := Color(1.0, 0.55, 0.16)
const DIM := Color(0.62, 0.34, 0.12)
const PALE := Color(1.0, 0.86, 0.66)

var name_edit: LineEdit
var ip_edit: LineEdit
var host_btn: Button
var join_btn: Button
var start_btn: Button
var leave_btn: Button
var satan_chk: CheckBox
var list_lbl: Label
var status_lbl: Label
var steam_btn: Button


func _ready() -> void:
	var sb := StyleBoxFlat.new()
	sb.bg_color = Color(0.03, 0.02, 0.015, 0.96)
	sb.border_color = ORANGE
	sb.set_border_width_all(2)
	sb.set_content_margin_all(24)
	add_theme_stylebox_override("panel", sb)
	position = Vector2(90, 120)
	custom_minimum_size = Vector2(720, 0)
	var v := VBoxContainer.new()
	v.add_theme_constant_override("separation", 10)
	add_child(v)
	_lbl(v, Loc.t("lobby_title"), 44, ORANGE, "title")
	_lbl(v, Loc.t("lobby_name"), 16, DIM)
	name_edit = _edit(v, Loc.player_name)
	_lbl(v, Loc.t("lobby_ip"), 16, DIM)
	ip_edit = _edit(v, Loc.last_ip)
	ip_edit.secret = Loc.streamer_mode
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 10)
	v.add_child(row)
	host_btn = _btn(row, Loc.t("lobby_host"), _on_host)
	join_btn = _btn(row, Loc.t("lobby_join"), _on_join)
	steam_btn = _btn(v, Loc.t("lobby_steam_btn"), _on_steam)
	steam_btn.add_theme_color_override("font_color", Color(0.55, 0.8, 1.0))
	steam_btn.visible = SteamNet.available()
	satan_chk = CheckBox.new()
	satan_chk.text = Loc.t("lobby_satan")
	satan_chk.add_theme_font_override("font", Loc.font("mono"))
	satan_chk.add_theme_color_override("font_color", Color(1.0, 0.45, 0.35))
	v.add_child(satan_chk)
	list_lbl = _lbl(v, "", 22, PALE, "title")
	status_lbl = _lbl(v, "", 15, Color(0.6, 1.0, 0.65))
	status_lbl.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	status_lbl.custom_minimum_size = Vector2(670, 0)
	var tip := _lbl(v, Loc.t("lobby_tip"), 13, DIM)
	tip.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	tip.custom_minimum_size = Vector2(670, 0)
	var row2 := HBoxContainer.new()
	row2.add_theme_constant_override("separation", 10)
	v.add_child(row2)
	start_btn = _btn(row2, Loc.t("lobby_start"), _on_start)
	leave_btn = _btn(row2, Loc.t("lobby_back"), _on_back)
	Net.lobby_changed.connect(_refresh)
	Net.status.connect(_on_status)
	SteamNet.changed.connect(_on_steam_changed)
	_refresh()


func _lbl(par: Node, text: String, size: int, col: Color, font := "mono") -> Label:
	var l := Label.new()
	l.text = text
	l.add_theme_font_override("font", Loc.font(font))
	l.add_theme_font_size_override("font_size", size)
	l.add_theme_color_override("font_color", col)
	par.add_child(l)
	return l


func _edit(par: Node, text: String) -> LineEdit:
	var e := LineEdit.new()
	e.text = text
	e.add_theme_font_override("font", Loc.font("bold"))
	e.add_theme_font_size_override("font_size", 20)
	e.custom_minimum_size = Vector2(0, 42)
	par.add_child(e)
	return e


func _btn(par: Node, text: String, cb: Callable) -> Button:
	var b := Button.new()
	b.text = text
	b.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	b.custom_minimum_size = Vector2(0, 46)
	b.add_theme_font_override("font", Loc.font("title"))
	b.add_theme_font_size_override("font_size", 22)
	b.pressed.connect(cb)
	b.pressed.connect(Sfx.play.bind("ui_click", -6.0, 1.0))
	par.add_child(b)
	return b


func _save() -> void:
	Loc.player_name = name_edit.text.strip_edges()
	Loc.last_ip = ip_edit.text.strip_edges()
	Loc.save_settings()


func _on_host() -> void:
	_save()
	Net.host(name_edit.text)
	_refresh()


func _on_join() -> void:
	_save()
	Net.join(name_edit.text, ip_edit.text)
	_refresh()


func _on_steam() -> void:
	_save()
	if SteamNet.lobby_id != 0 and Net.active and multiplayer.is_server():
		SteamNet.invite()
	else:
		SteamNet.host_lobby()


func _on_steam_changed() -> void:
	if SteamNet.status_text != "":
		status_lbl.text = SteamNet.status_text
	_refresh()


func _on_start() -> void:
	Net.start_game(false, satan_chk.button_pressed)


func _on_back() -> void:
	Net.leave()
	SteamNet.leave_lobby()
	closed.emit()
	queue_free()


func _on_status(text: String) -> void:
	status_lbl.text = text


func _refresh() -> void:
	var lines := ""
	for id in Net.players:
		var p: Dictionary = Net.players[id]
		lines += "%s  %s%s\n" % [Loc.f("lobby_desk", [int(p["pod"]) + 1]), str(p["name"]), "  (" + Loc.t("lobby_host_tag") + ")" if int(id) == 1 else ""]
	list_lbl.text = lines.strip_edges() if lines != "" else Loc.t("lobby_empty")
	var hosting := Net.active and multiplayer.is_server()
	start_btn.visible = hosting
	satan_chk.visible = hosting
	host_btn.disabled = Net.active
	join_btn.disabled = Net.active
	name_edit.editable = not Net.active
	ip_edit.editable = not Net.active
	if steam_btn != null:
		steam_btn.disabled = Net.active and not (multiplayer.is_server() and SteamNet.lobby_id != 0)
		steam_btn.text = Loc.t("lobby_steam_invite") if SteamNet.lobby_id != 0 and hosting else Loc.t("lobby_steam_btn")
