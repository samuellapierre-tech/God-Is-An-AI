extends Node
## LES ÉCHOS DIVINS : Dieu enregistre tout ce que vous dites dans le chat vocal.
## Plus tard, un collegue PNJ repete une de vos phrases AVEC VOTRE VOIX
## (parfois ralentie ou acceleree), ou Dieu la rejoue sur ses ecrans
## comme piece a conviction. En fin de semaine : les ARCHIVES DE DIEU.
##
## - Les extraits restent en memoire seulement (jamais sur le disque).
## - Chaque joueur peut refuser (Menu > ÉCHOS DIVINS : NON) : sa voix
##   n'est alors jamais rejouee, chez personne.

const RATE := 11025
const Voice := preload("res://scripts/voice.gd")
const GAP_MS := 650
const MIN_SAMPLES := 8000       # ~0,7 s
const MAX_SAMPLES := 66000      # ~6 s
const MAX_CLIPS := 10

var main: Node
var cur := {}                   # peer -> {"buf", "last", "lvl", "n"}
var clips := {}                 # peer -> [{"data": PackedByteArray, "score": float}]
var next_echo := 0.0
var players := {}               # npc pod -> AudioStreamPlayer3D
var queue := {}                 # player -> PackedVector2Array restant
var god_player: AudioStreamPlayer
var ui_player: AudioStreamPlayer
var played := 0
var crossed_cd := 0
var recorded := 0


func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	next_echo = randf_range(55.0, 80.0)
	if Dev.args.has("autoplay"):
		next_echo = 25.0
	god_player = _gen_player_2d("Radio")
	ui_player = _gen_player_2d("Master")


func _gen_player_2d(bus: String) -> AudioStreamPlayer:
	var p := AudioStreamPlayer.new()
	var gen := AudioStreamGenerator.new()
	gen.mix_rate = RATE
	gen.buffer_length = 0.5
	p.stream = gen
	p.bus = bus
	add_child(p)
	return p


static func allowed(id: int) -> bool:
	return bool(Net.players.get(id, {}).get("echo", true))


# ------------------------------------------------------------- enregistrement

## Appele pour chaque paquet de voix (recu, ou envoye par moi). bytes = mu-law sans l'octet radio.
func feed(id: int, bytes: PackedByteArray, lvl: float) -> void:
	if not allowed(id):
		return
	var now := Time.get_ticks_msec()
	var c: Dictionary = cur.get(id, {})
	if c.is_empty() or now - int(c["last"]) > GAP_MS:
		_finish(id)
		c = {"buf": PackedByteArray(), "last": now, "lvl": 0.0, "n": 0}
		cur[id] = c
	var b: PackedByteArray = c["buf"]
	b.append_array(bytes)
	c["buf"] = b
	c["last"] = now
	c["lvl"] = float(c["lvl"]) + lvl
	c["n"] = int(c["n"]) + 1
	if b.size() >= MAX_SAMPLES:
		_finish(id)


func _finish(id: int) -> void:
	if not cur.has(id):
		return
	var c: Dictionary = cur[id]
	cur.erase(id)
	var b: PackedByteArray = c["buf"]
	if b.size() < MIN_SAMPLES:
		return
	var avg := float(c["lvl"]) / maxf(1.0, float(c["n"]))
	var score := avg * minf(float(b.size()) / RATE, 4.0) + randf() * 0.05
	var list: Array = clips.get(id, [])
	var entry := {"data": b, "score": score}
	if list.size() < MAX_CLIPS:
		list.append(entry)
	else:
		# on remplace un extrait au hasard parmi les plus faibles (garde de la variete)
		var worst := 0
		for i in list.size():
			if float(list[i]["score"]) < float(list[worst]["score"]):
				worst = i
		if score > float(list[worst]["score"]) or randf() < 0.3:
			list[worst] = entry
	clips[id] = list
	recorded += 1


func has_any() -> bool:
	for id in clips:
		if not (clips[id] as Array).is_empty() and allowed(int(id)):
			return true
	return false


func _pick_clip(id: int, best := false) -> PackedByteArray:
	var list: Array = clips.get(id, [])
	if list.is_empty():
		# ce joueur n'a rien dit pres de moi : n'importe qui d'autre fera l'affaire
		for k in clips:
			if not (clips[k] as Array).is_empty() and allowed(int(k)):
				list = clips[k]
				break
	if list.is_empty():
		return PackedByteArray()
	if best:
		var bi := 0
		for i in list.size():
			if float(list[i]["score"]) > float(list[bi]["score"]):
				bi = i
		return list[bi]["data"]
	return list[randi() % list.size()]["data"]


# ------------------------------------------------------------- lecture

func _process(dt: float) -> void:
	var now := Time.get_ticks_msec()
	for id in cur.keys():
		if now - int(cur[id]["last"]) > GAP_MS:
			_finish(int(id))
	_pump()
	if main == null or not Net.active or not Net.is_host() or main.frozen:
		return
	next_echo -= dt
	if next_echo <= 0.0:
		next_echo = randf_range(70.0, 120.0)
		_schedule()


func _schedule() -> void:
	# l'hote choisit qui parle, avec la voix de qui ; chacun joue son propre enregistrement
	var ids := []
	for id in Net.players:
		if allowed(int(id)):
			ids.append(int(id))
	if ids.is_empty():
		return
	var data := {
		"peer": ids[randi() % ids.size()],
		"pitch": [1.0, 1.0, 0.72, 1.45][randi() % 4],
		"god": randf() < 0.3,
		"npc": -1,
		"rec": randi_range(1000, 9999),
	}
	var free := []
	for d in main.npcs:
		if str(d["state"]) == "desk":
			free.append(int(d["pod"]))
	if free.is_empty():
		data["god"] = true
	else:
		data["npc"] = free[randi() % free.size()]
	main.net_fx_event("echo", data)
	main.sync.bcast(&"fx_event", ["echo", data])


func play_echo(data: Dictionary) -> void:
	var clip := _pick_clip(int(data["peer"]))
	if clip.is_empty():
		return
	played += 1
	if int(data["peer"]) == Net.my_id() and clips.has(Net.my_id()):
		Profile.unlock("echo")
	var frames := Voice.decode(clip, clip.size())
	if Dev.args.has("autoplay"):
		print("ECHO joue : voix de ", data["peer"], " par ", ("DIEU" if bool(data["god"]) else "PNJ %d" % int(data["npc"])), " ", frames.size(), " echantillons")
	var secs := float(frames.size()) / RATE / float(data["pitch"])
	if bool(data["god"]):
		god_player.pitch_scale = float(data["pitch"])
		_start(god_player, frames)
		main._god(Loc.f("echo_god_rec", [int(data["rec"])]))
		get_tree().create_timer(secs + 0.6).timeout.connect(_god_after)
		main.viral.highlight("echo")
		return
	var npc: Dictionary = {}
	for d in main.npcs:
		if int(d["pod"]) == int(data["npc"]):
			npc = d
	if npc.is_empty():
		return
	var p := _npc_player(npc)
	p.pitch_scale = float(data["pitch"])
	_start(p, frames)
	var c = npc["char"]
	c.typing = false
	c.look_target = main.player
	c.say(secs)
	var bub: Label3D = npc["bub"]
	bub.text = ""
	get_tree().create_timer(secs + 0.4).timeout.connect(_npc_after.bind(npc))


func _god_after() -> void:
	main._god(Loc.pick("echo_god"))
	Sfx.play("thunder", -14.0, 1.3)


func _npc_after(npc: Dictionary) -> void:
	var bub: Label3D = npc["bub"]
	bub.text = Loc.pick("echo_after")
	npc["say"] = 4.0
	npc["char"].set_emotion("shock")


func _npc_player(npc: Dictionary) -> AudioStreamPlayer3D:
	var pod := int(npc["pod"])
	if players.has(pod) and is_instance_valid(players[pod]):
		return players[pod]
	var p := AudioStreamPlayer3D.new()
	var gen := AudioStreamGenerator.new()
	gen.mix_rate = RATE
	gen.buffer_length = 0.5
	p.stream = gen
	p.unit_size = 4.0
	p.max_distance = 30.0
	p.bus = "Voice"
	p.position = Vector3(0, 1.5, 0)
	(npc["hold"] as Node3D).add_child(p)
	players[pod] = p
	return p


func _start(p: Node, frames: PackedVector2Array) -> void:
	p.stop()
	p.play()
	queue[p] = frames


func _pump() -> void:
	for p in queue.keys():
		if not is_instance_valid(p):
			queue.erase(p)
			continue
		var pb = p.get_stream_playback()
		if pb == null:
			continue
		var rest: PackedVector2Array = queue[p]
		var n := mini(pb.get_frames_available(), rest.size())
		if n > 0:
			pb.push_buffer(rest.slice(0, n))
			rest = rest.slice(n)
		if rest.is_empty():
			queue.erase(p)
		else:
			queue[p] = rest


# ------------------------------------------------------------- archives de Dieu

func archive_ids() -> Array:
	var out := []
	for id in clips:
		if not (clips[id] as Array).is_empty() and allowed(int(id)):
			out.append(int(id))
	return out


func play_archive(id: int) -> void:
	var clip := _pick_clip(id, true)
	if clip.is_empty():
		return
	ui_player.pitch_scale = 1.0
	_start(ui_player, Voice.decode(clip, clip.size()))


# ------------------------------------------------------------- ligne croisee

## Pendant MON appel : la voix d'un ami (enregistree) se glisse dans la ligne du fidele.
func crossed_line() -> void:
	if main == null or not main.in_call:
		return
	var now := Time.get_ticks_msec()
	if now < crossed_cd and not Dev.args.has("crossed"):
		return
	crossed_cd = now + 90000
	var others := []
	for id in clips:
		if int(id) != Net.my_id() and allowed(int(id)) and not (clips[id] as Array).is_empty():
			others.append(int(id))
	if others.is_empty():
		return
	var id: int = others[randi() % others.size()]
	var clip := _pick_clip(id)
	god_player.pitch_scale = 1.0
	_start(god_player, Voice.decode(clip, clip.size()))
	main._log(Loc.t("crossed_tag"), Loc.t("crossed_log"), "#ff7ad9")
	main._say(Loc.t("crossed_say"), 4.0)
	if main.callview != null:
		main.callview.power_fx("dream")
	if not main.busy:
		main._ask_ai(main.EVENT_TAG + Loc.f("mk_event", [Loc.t("crossed_ai")]))
	if Dev.args.has("autoplay"):
		print("LIGNE CROISEE : voix de ", id)
