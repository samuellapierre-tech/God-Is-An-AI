extends SubViewportContainer
## Photo de groupe 3D : les fideles convertis de la semaine, tout sourire,
## devant l'oeil de G.O.D. Sert a la ceremonie du vendredi (et a la carte a partager).

const Character := preload("res://scripts/character.gd")

var vp: SubViewport
var people := []
var t := 0.0
var cam: Camera3D


func setup(list: Array, fired := false) -> void:
	stretch = true
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	vp = SubViewport.new()
	vp.own_world_3d = true
	vp.transparent_bg = true
	vp.msaa_3d = Viewport.MSAA_4X
	add_child(vp)
	var root := Node3D.new()
	vp.add_child(root)
	var we := WorldEnvironment.new()
	var e := Environment.new()
	e.background_mode = Environment.BG_CLEAR_COLOR
	e.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	e.ambient_light_color = Color(0.6, 0.55, 0.5)
	e.ambient_light_energy = 0.5
	e.tonemap_mode = Environment.TONE_MAPPER_ACES
	e.glow_enabled = true
	we.environment = e
	root.add_child(we)
	cam = Camera3D.new()
	cam.fov = 40
	root.add_child(cam)
	var n: int = clamp(list.size(), 1, 7)
	var width := float(n) * 0.62
	cam.position = Vector3(0, 1.05, 2.7)
	cam.look_at(Vector3(0, 0.95, 0), Vector3.UP)
	var key := DirectionalLight3D.new()
	key.rotation_degrees = Vector3(-30, -25, 0)
	key.light_energy = 1.2
	key.shadow_enabled = true
	root.add_child(key)
	var rim := OmniLight3D.new()
	rim.position = Vector3(0, 2.0, -1.5)
	rim.light_color = Color(1.0, 0.1, 0.05) if fired else Color(1.0, 0.6, 0.2)
	rim.light_energy = 3.0
	rim.omni_range = 6.0
	root.add_child(rim)
	var eye := MeshInstance3D.new()
	var qm := QuadMesh.new()
	qm.size = Vector2(width + 5.0, 3.2)
	eye.mesh = qm
	var em := ShaderMaterial.new()
	em.shader = load("res://shaders/god_eye.gdshader")
	em.set_shader_parameter("anger", 1.0 if fired else 0.0)
	eye.material_override = em
	eye.position = Vector3(0, 1.6, -1.6)
	root.add_child(eye)
	for i in n:
		var info: Dictionary = list[i] if i < list.size() else {}
		var rng := RandomNumberGenerator.new()
		rng.seed = int(info.get("look_seed", 77 + i))
		var c := Character.new()
		root.add_child(c)
		c.build(Character.random_look(rng, {"fem": bool(info.get("fem", rng.randf() < 0.5)), "age": int(info.get("age", 40))}), "stand")
		var x := (float(i) - float(n - 1) * 0.5) * 0.62
		c.position = Vector3(x, 0.78, -abs(x) * 0.15)
		c.rotation.y = PI - x * 0.12
		c.set_emotion(["cry", "sad", "dizzy"][i % 3] if fired else ["laugh", "love", "happy", "proud"][i % 4])
		if not fired and i % 3 == 1:
			c.emote(["wave", "flex", "dance"][i % 3])
		c.look_point = cam.position
		c.anim_speed = rng.randf_range(0.8, 1.2)
		people.append(c)


func _process(dt: float) -> void:
	t += dt
	if randf() < dt * 0.8 and not people.is_empty():
		people[randi() % people.size()].say(0.8)
