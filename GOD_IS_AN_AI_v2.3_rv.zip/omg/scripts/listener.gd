extends Node
## L'OREILLE DE LA SIMULATION : transforme ce que tu dis au micro en texte
## (speech-to-text) et le donne a Reality Echo.
##  - co-op : ce que tu dis dans le chat vocal (quand tu transmets)
##  - solo  : le micro est ecoute directement (detection de la voix)
## Transcription : API compatible OpenAI (cle de cle_tts.txt) ou relais.
## Sans transcription disponible, la simulation n'ecoute que le texte
## (ce que tu ecris aux fideles et dans le chat).

const RATE := 11025
const SILENCE := 0.75
const MIN_LEN := 0.9
const MAX_LEN := 12.0

var main: Node
var buf := PackedFloat32Array()
var talking := false
var quiet_t := 0.0
var queue := []                # WAV en attente
var http: HTTPRequest
var busy := false
var mic_player: AudioStreamPlayer = null
var capture: AudioEffectCapture = null
var leak_cd := 0.0
var sent := 0
var fails := 0


var rec_lbl: Label
var stt_t0 := 0


func _ready() -> void:
	var cl := CanvasLayer.new()
	cl.layer = 8
	add_child(cl)
	rec_lbl = Label.new()
	rec_lbl.text = Loc.t("echo_rec_live")
	rec_lbl.add_theme_font_override("font", Loc.font("title"))
	rec_lbl.add_theme_font_size_override("font_size", 22)
	rec_lbl.add_theme_color_override("font_color", Color(1.0, 0.3, 0.3))
	rec_lbl.add_theme_color_override("font_outline_color", Color(0, 0, 0))
	rec_lbl.add_theme_constant_override("outline_size", 6)
	rec_lbl.anchor_left = 1.0
	rec_lbl.anchor_right = 1.0
	rec_lbl.offset_left = -360
	rec_lbl.offset_right = -24
	rec_lbl.offset_top = 120
	rec_lbl.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	rec_lbl.visible = false
	cl.add_child(rec_lbl)
	http = HTTPRequest.new()
	http.timeout = 30.0
	add_child(http)
	http.request_completed.connect(_on_done)
	if main.voice == null and enabled() and DisplayServer.get_name() != "headless":
		_open_mic()


func enabled() -> bool:
	if not Loc.echo_listen or fails >= 4:
		return false
	return _key() != "" or Relay.enabled()


## Le micro est-il vraiment ecoute (solo : micro ouvert ; co-op : chat vocal) ?
func listening() -> bool:
	return enabled() and Loc.voice_mode != 2 and (capture != null or main.voice != null)


func _ptt() -> bool:
	var typing: bool = main.pc_input != null and main.pc_input.has_focus()
	var side := Input.is_mouse_button_pressed(MOUSE_BUTTON_XBUTTON1) or Input.is_mouse_button_pressed(MOUSE_BUTTON_XBUTTON2)
	if typing:
		return side
	return side or Input.is_physical_key_pressed(KEY_V) or Input.is_physical_key_pressed(KEY_B)


func _key() -> String:
	return str(main.tts.key) if main.tts != null else ""


# ------------------------------------------------------------- micro (solo)

func _open_mic() -> void:
	var b := AudioServer.get_bus_index("Listen")
	if b < 0:
		AudioServer.add_bus()
		b = AudioServer.bus_count - 1
		AudioServer.set_bus_name(b, "Listen")
		AudioServer.add_bus_effect(b, AudioEffectCapture.new())
		AudioServer.set_bus_mute(b, true)
	capture = AudioServer.get_bus_effect(b, 0) as AudioEffectCapture
	mic_player = AudioStreamPlayer.new()
	mic_player.stream = AudioStreamMicrophone.new()
	mic_player.bus = "Listen"
	add_child(mic_player)
	mic_player.play()


var fake_t := 6.0


var retry_t := 0.0


func _process(dt: float) -> void:
	leak_cd -= dt
	if fails >= 4:
		# la transcription a lache : on reessaie une fois par minute
		retry_t += dt / maxf(0.01, Engine.time_scale)
		if retry_t > 60.0:
			retry_t = 0.0
			fails = 3
	if Dev.args.has("fakemic") and enabled():
		# test : une « phrase » de bruit toutes les ~8 s (la transcription est simulee par le relais de test)
		fake_t -= dt / Engine.time_scale
		if fake_t <= 0.0:
			fake_t = randf_range(5.0, 10.0)
			var pcm := PackedFloat32Array()
			for i in int(RATE * randf_range(1.0, 2.5)):
				pcm.append(randf_range(-0.2, 0.2))
			feed_pcm(pcm)
			_flush()
	if capture != null:
		var n := capture.get_frames_available()
		if n > 0:
			var data := capture.get_buffer(n)
			var step := AudioServer.get_mix_rate() / RATE
			var out := PackedFloat32Array()
			var pos := 0.0
			while int(pos) < data.size():
				out.append((data[int(pos)].x + data[int(pos)].y) * 0.5)
				pos += step
			match Loc.voice_mode:
				0:
					# APPUYER SUR V : on enregistre tant que la touche est tenue
					if _ptt():
						talking = true
						buf.append_array(out)
						if buf.size() > int(MAX_LEN * RATE):
							_flush()
					elif talking:
						_flush()
				1:
					_vad(out, dt)
				_:
					buf = PackedFloat32Array()
					talking = false

	elif talking:
		quiet_t += dt
		if quiet_t > SILENCE:
			_flush()
	rec_lbl.visible = talking and enabled() and Loc.voice_mode != 2


## Le jeu lui-meme parle (voix du fidele, de Dieu) : on n'ecoute pas les haut-parleurs.
func _game_talking() -> bool:
	if main.tts != null and main.tts.player != null and main.tts.player.playing:
		return true
	return DisplayServer.tts_is_speaking()


func _vad(samples: PackedFloat32Array, dt: float) -> void:
	if _game_talking():
		if talking:
			buf = PackedFloat32Array()
			talking = false
		return
	var sum := 0.0
	for v in samples:
		sum += v * v
	var lvl := sqrt(sum / maxf(1.0, float(samples.size())))
	if lvl > 0.045:
		talking = true
		quiet_t = 0.0
	elif talking:
		quiet_t += dt
	if talking:
		buf.append_array(samples)
		if quiet_t > SILENCE or buf.size() > int(MAX_LEN * RATE):
			_flush()


## Co-op : appele par voice.gd avec ce que JE transmets dans le chat vocal.
func feed_pcm(samples: PackedFloat32Array) -> void:
	if not enabled():
		return
	talking = true
	quiet_t = 0.0
	buf.append_array(samples)
	if buf.size() > int(MAX_LEN * RATE):
		_flush()


func _flush() -> void:
	talking = false
	quiet_t = 0.0
	if buf.size() >= int(MIN_LEN * RATE) and enabled():
		queue.append(_wav(buf))
		if queue.size() > 4:
			queue.pop_front()
		_next()
	buf = PackedFloat32Array()


static func _wav(samples: PackedFloat32Array) -> PackedByteArray:
	var n := samples.size()
	var b := PackedByteArray()
	b.append_array("RIFF".to_ascii_buffer())
	b.resize(44)
	b.encode_u32(4, 36 + n * 2)
	var mid := "WAVEfmt ".to_ascii_buffer()
	for i in 8:
		b[8 + i] = mid[i]
	b.encode_u32(16, 16)
	b.encode_u16(20, 1)
	b.encode_u16(22, 1)
	b.encode_u32(24, RATE)
	b.encode_u32(28, RATE * 2)
	b.encode_u16(32, 2)
	b.encode_u16(34, 16)
	var dt := "data".to_ascii_buffer()
	for i in 4:
		b[36 + i] = dt[i]
	b.encode_u32(40, n * 2)
	var pcm := PackedByteArray()
	pcm.resize(n * 2)
	for i in n:
		pcm.encode_s16(i * 2, int(clampf(samples[i], -1.0, 1.0) * 32767.0))
	b.append_array(pcm)
	return b


# ------------------------------------------------------------- transcription

func _next() -> void:
	if busy or queue.is_empty():
		return
	busy = true
	var wav: PackedByteArray = queue.pop_front()
	var bd := "----godisanai%d" % randi()
	var body := PackedByteArray()
	body.append_array(("--%s\r\nContent-Disposition: form-data; name=\"model\"\r\n\r\n%s\r\n" % [bd, "gpt-4o-mini-transcribe"]).to_utf8_buffer())
	body.append_array(("--%s\r\nContent-Disposition: form-data; name=\"language\"\r\n\r\n%s\r\n" % [bd, Loc.lang]).to_utf8_buffer())
	body.append_array(("--%s\r\nContent-Disposition: form-data; name=\"file\"; filename=\"voix.wav\"\r\nContent-Type: audio/wav\r\n\r\n" % bd).to_utf8_buffer())
	body.append_array(wav)
	body.append_array(("\r\n--%s--\r\n" % bd).to_utf8_buffer())
	var headers := PackedStringArray(["Content-Type: multipart/form-data; boundary=" + bd])
	var url := "https://api.openai.com/v1/audio/transcriptions"
	if _key() != "":
		headers.append("Authorization: Bearer " + _key())
	else:
		url = Relay.url + "/v1/stt"
		headers.append("x-omg-player: " + Relay.player)
		var sig := Relay.sign_bytes(body)
		if sig != "":
			headers.append("x-omg-sig: " + sig)
	sent += 1
	stt_t0 = Time.get_ticks_msec()
	if http.request_raw(url, headers, HTTPClient.METHOD_POST, body) != OK:
		busy = false
		fails += 1


func _on_done(_r: int, code: int, _h: PackedStringArray, bytes: PackedByteArray) -> void:
	busy = false
	if code != 200:
		fails += 1
		push_warning("Transcription : erreur %d" % code)
	else:
		fails = 0
		print("LATENCE TRANSCRIPTION : %d ms" % (Time.get_ticks_msec() - stt_t0))
		var d = Reality.quiet_json(bytes.get_string_from_utf8())
		var txt := str(d.get("text", "")) if typeof(d) == TYPE_DICTIONARY else ""
		if txt.strip_edges() != "":
			heard(txt.strip_edges(), Net.my_id())
	_next()


## Une phrase dite par un joueur (moi ou, en co-op, un ami).
func heard(txt: String, from: int) -> void:
	if Dev.args.has("autoplay"):
		print("ENTENDU (", from, ") : ", txt)
	var who := str(Net.players.get(from, {}).get("name", main.WHO[main.MY_POD])) if Net.active else str(main.WHO[main.MY_POD])
	Reality.hear(txt, who, "voice")
	if from == Net.my_id() and Net.active:
		main.sync.bcast(&"action", ["heard", txt])
	_maybe_leak(txt, from)


## RISQUE D'EXPOSITION : le fidele entend ce qui se dit derriere « Dieu ».
func _maybe_leak(txt: String, from: int) -> void:
	if not main.in_call or main.busy or leak_cd > 0.0:
		return
	var near := from == Net.my_id()
	if not near:
		var d: Dictionary = main.avatars.get(from, {})
		if not d.is_empty():
			near = (d["hold"] as Node3D).global_position.distance_to(main.player.global_position) < 6.0
	if not near or randf() > 0.4:
		return
	leak_cd = 25.0
	main._log(Loc.t("leak_tag"), Loc.f("leak_log", [txt]), "#ff9f43")
	main._ask_ai(main.EVENT_TAG + Loc.f("mk_event", [Loc.f("leak_ai", [txt])]))
