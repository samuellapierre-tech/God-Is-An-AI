extends Node
## COURSE DE CHAISES A ROULETTES : [R] pour monter sur ta chaise de bureau.
## Ca glisse comme sur la glace, ca rebondit sur les murs, et ca fait
## des STRIKES dans les collegues.

const ACCEL := 9.0
const MAX_SPEED := 12.0
const FRICTION := 0.55

var main: Node
var riding := false
var vel := Vector3.ZERO
var chair: Node3D = null
var hit_cd := {}
var bounce_cd := 0.0
var best_speed := 0.0


func toggle() -> void:
	if main.seated or main.frozen:
		return
	riding = not riding
	if riding:
		vel = -main.player.global_transform.basis.z * 2.0
		chair = make_chair()
		main.player.add_child(chair)
		chair.position = Vector3(0, -0.55, 0.1)
		Sfx.loop_at("roll", "roll", main.player, -40.0)
		main._say(Loc.t("chair_on"), 3.0)
		Sfx.play("boing", -6.0, 0.7)
	else:
		_stop()


func _stop() -> void:
	riding = false
	if chair != null:
		chair.queue_free()
	chair = null
	Sfx.stop("roll")


static func make_chair() -> Node3D:
	var n := Node3D.new()
	var dark := StandardMaterial3D.new()
	dark.albedo_color = Color(0.12, 0.12, 0.14)
	dark.roughness = 0.4
	var seat := StandardMaterial3D.new()
	seat.albedo_color = Color(0.55, 0.12, 0.1)
	seat.roughness = 0.7
	var s := MeshInstance3D.new()
	var bm := BoxMesh.new()
	bm.size = Vector3(0.55, 0.09, 0.55)
	s.mesh = bm
	s.material_override = seat
	s.position = Vector3(0, 0.1, 0)
	n.add_child(s)
	var back := MeshInstance3D.new()
	var bb := BoxMesh.new()
	bb.size = Vector3(0.52, 0.6, 0.07)
	back.mesh = bb
	back.material_override = seat
	back.position = Vector3(0, 0.45, 0.27)
	n.add_child(back)
	var pole := MeshInstance3D.new()
	var cm := CylinderMesh.new()
	cm.top_radius = 0.03
	cm.bottom_radius = 0.03
	cm.height = 0.3
	pole.mesh = cm
	pole.material_override = dark
	pole.position = Vector3(0, -0.1, 0)
	n.add_child(pole)
	for k in 5:
		var a := TAU * float(k) / 5.0
		var leg := MeshInstance3D.new()
		var lb := BoxMesh.new()
		lb.size = Vector3(0.05, 0.04, 0.32)
		leg.mesh = lb
		leg.material_override = dark
		leg.position = Vector3(sin(a) * 0.16, -0.24, cos(a) * 0.16)
		leg.rotation.y = a
		n.add_child(leg)
		var wh := MeshInstance3D.new()
		var sm := SphereMesh.new()
		sm.radius = 0.04
		sm.height = 0.08
		wh.mesh = sm
		wh.material_override = dark
		wh.position = Vector3(sin(a) * 0.3, -0.28, cos(a) * 0.3)
		n.add_child(wh)
	return n


## Remplace le deplacement normal quand on roule.
func physics(dt: float) -> void:
	var p: CharacterBody3D = main.player
	var b := p.global_transform.basis
	var dir := Vector3.ZERO
	if Input.is_physical_key_pressed(KEY_W):
		dir -= b.z
	if Input.is_physical_key_pressed(KEY_S):
		dir += b.z * 0.6
	if Input.is_physical_key_pressed(KEY_A):
		dir -= b.x * 0.5
	if Input.is_physical_key_pressed(KEY_D):
		dir += b.x * 0.5
	dir.y = 0.0
	var acc := ACCEL * (1.6 if Input.is_key_pressed(KEY_SHIFT) else 1.0)
	vel += dir * acc * dt
	vel *= exp(-FRICTION * dt)
	if vel.length() > MAX_SPEED:
		vel = vel.normalized() * MAX_SPEED
	p.velocity = Vector3(vel.x, p.velocity.y, vel.z)
	if not p.is_on_floor():
		p.velocity.y -= 22.0 * dt
	elif main.want_jump:
		p.velocity.y = 4.0
		Sfx.play("boing", -8.0, 1.4)
	else:
		p.velocity.y = -0.2
	main.want_jump = false
	var before := vel.length()
	p.move_and_slide()
	bounce_cd -= dt
	for i in p.get_slide_collision_count():
		var col := p.get_slide_collision(i)
		var nrm := col.get_normal()
		if absf(nrm.y) < 0.5 and vel.dot(nrm) < 0.0:
			vel = vel.bounce(Vector3(nrm.x, 0, nrm.z).normalized()) * 0.65
			if before > 3.5 and bounce_cd <= 0.0:
				bounce_cd = 0.3
				Sfx.play("bonk", -4.0, randf_range(0.8, 1.1))
				main.cam_shake = minf(0.8, before * 0.06)
				main.fun.pop(p.global_position + vel.normalized() * 0.8 + Vector3(0, 1.0, 0), Loc.pick("pop_crash"), Color(1.0, 0.6, 0.2), 100)
	var spd := vel.length()
	best_speed = maxf(best_speed, spd)
	Sfx.set_loop_db("roll", lerpf(-40.0, -6.0, clampf(spd / 8.0, 0.0, 1.0)))
	if chair != null:
		chair.rotation.y += dt * spd * 0.3
	main.cam.rotation.z = lerpf(main.cam.rotation.z, -vel.dot(b.x) * 0.02, clampf(dt * 5.0, 0.0, 1.0))
	# STRIKE : on fonce dans les collegues
	for k in hit_cd.keys():
		hit_cd[k] = float(hit_cd[k]) - dt
	if spd > 4.0:
		for tg in main.fun._targets():
			var hp: Vector3 = tg[3]
			var key := str(tg[0]) + str(tg[1])
			if float(hit_cd.get(key, 0.0)) > 0.0:
				continue
			if Vector2(hp.x - p.global_position.x, hp.z - p.global_position.z).length() < 0.95:
				hit_cd[key] = 2.0
				main.fun._bonk_fx(tg)
				main.fun.pop(hp + Vector3(0, 0.6, 0), "STRIKE !", Color(1.0, 0.3, 0.3), 130)
				Sfx.play("cheer", -10.0, 1.2)
				Profile.unlock("strike")
				vel *= 0.6
				if Net.active:
					main.sync.bcast(&"action", ["bonk", {"k": tg[0], "id": tg[1]}])
