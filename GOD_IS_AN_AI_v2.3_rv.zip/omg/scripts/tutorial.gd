extends Node
## TUTORIEL du premier lancement (solo, jour 1). F1 pour le passer.

var main: Node
var step := 0
var box: PanelContainer
var lbl: Label
var head: Label
var done_t := 0.0
var flash := 0.0


func _ready() -> void:
	var cl: CanvasLayer = main.hud_layer
	box = PanelContainer.new()
	var sb := StyleBoxFlat.new()
	sb.bg_color = Color(0.02, 0.05, 0.08, 0.85)
	sb.border_color = Color(0.45, 0.8, 1.0)
	sb.set_border_width_all(2)
	sb.set_content_margin_all(14)
	box.add_theme_stylebox_override("panel", sb)
	box.position = Vector2(26, 150)
	box.custom_minimum_size = Vector2(520, 0)
	box.mouse_filter = Control.MOUSE_FILTER_IGNORE
	cl.add_child(box)
	var v := VBoxContainer.new()
	box.add_child(v)
	head = Label.new()
	head.add_theme_font_override("font", Loc.font("title"))
	head.add_theme_font_size_override("font_size", 22)
	head.add_theme_color_override("font_color", Color(0.55, 0.85, 1.0))
	v.add_child(head)
	lbl = Label.new()
	lbl.add_theme_font_override("font", Loc.font("bold"))
	lbl.add_theme_font_size_override("font_size", 19)
	lbl.add_theme_color_override("font_color", Color(1, 1, 1))
	lbl.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	lbl.custom_minimum_size = Vector2(490, 0)
	v.add_child(lbl)
	var skip := Label.new()
	skip.text = Loc.t("tuto_skip")
	skip.add_theme_font_override("font", Loc.font("mono"))
	skip.add_theme_font_size_override("font_size", 13)
	skip.add_theme_color_override("font_color", Color(0.5, 0.65, 0.75))
	v.add_child(skip)
	_show()


func _steps() -> Array:
	return Loc.list("tuto_steps")


func _show() -> void:
	if Dev.args.has("autoplay"):
		print("TUTO etape ", step)
	var st := _steps()
	head.text = Loc.f("tuto_head", [mini(step + 1, st.size()), st.size()])
	lbl.text = str(st[mini(step, st.size() - 1)])
	flash = 1.0
	Sfx.play("ui_click", -4.0, 1.5)


func _next() -> void:
	step += 1
	if step >= _steps().size() - 1:
		step = _steps().size() - 1
		done_t = 9.0
		Sfx.play("score", -4.0)
	_show()


func _process(dt: float) -> void:
	if main.frozen:
		box.visible = false
		return
	# on ne cache pas le choix de la mission (cartes au centre de l'ecran)
	box.visible = not (main.missions != null and main.missions.state == "choose")
	flash = maxf(0.0, flash - dt * 1.5)
	box.modulate = Color(1, 1, 1).lerp(Color(1.6, 1.6, 2.0), flash)
	# pas de commande de Dieu pendant l'apprentissage
	if step < 5:
		main.next_task = maxf(main.next_task, main.t + 30.0)
	match step:
		0:   # aller a son poste
			main.next_ring = maxf(main.next_ring, main.t + 5.0)
			if main.player.global_position.distance_to(main.seat_pos[main.MY_POD]) < 3.0 or main.seated:
				_next()
		1:   # s'asseoir
			main.next_ring = maxf(main.next_ring, main.t + 5.0)
			if main.seated:
				_next()
				main.next_ring = main.t + 2.5
		2:   # repondre
			if main.in_call:
				_next()
		3:   # parler au fidele
			if main.player_lines >= 2 or (not main.in_call and main.solved > 0):
				_next()
		4:   # un coup de pouce
			if main.used_help or main.solved > 0:
				_next()
		5:   # convertir
			if main.solved > 0:
				_next()
		_:
			done_t -= dt
			if done_t <= 0.0:
				finish()


func finish() -> void:
	Loc.tutorial_done = true
	Loc.save_settings()
	box.queue_free()
	queue_free()


func _input(e: InputEvent) -> void:
	if e is InputEventKey and e.pressed and not e.echo and e.keycode == KEY_F1:
		finish()
