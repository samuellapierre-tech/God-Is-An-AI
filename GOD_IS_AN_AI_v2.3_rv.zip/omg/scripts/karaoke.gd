extends Node
## PRIERE KARAOKE : en plein appel, le fidele exige une chanson.
## Chante dans ton micro (maintiens V) ou ecris des paroles. Les collegues
## brandissent des cartons de 1 a 10, comme au patinage artistique.

const LENGTH := 12.0

var main: Node
var active := false
var left := 0.0
var sing_t := 0.0
var lvl_sum := 0.0
var lvl_n := 0
var lines0 := 0
var plan_for := -1.0
var plan_at := -1.0
var panel: Label
var mic_player: AudioStreamPlayer = null
var capture: AudioEffectCapture = null


func _ready() -> void:
	panel = Label.new()
	panel.add_theme_font_override("font", Loc.font("title"))
	panel.add_theme_font_size_override("font_size", 34)
	panel.add_theme_color_override("font_color", Color(1.0, 0.5, 0.9))
	panel.add_theme_color_override("font_outline_color", Color(0.1, 0, 0.1))
	panel.add_theme_constant_override("outline_size", 10)
	panel.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	panel.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	panel.anchor_left = 0.5
	panel.anchor_right = 0.5
	panel.offset_left = -560
	panel.offset_right = 560
	panel.offset_top = 210
	panel.mouse_filter = Control.MOUSE_FILTER_IGNORE
	panel.visible = false
	main.hud_layer.add_child(panel)


func _process(dt: float) -> void:
	if not active:
		_plan()
		return
	left -= dt
	var lvl := _mic_level()
	if lvl > 0.03:
		sing_t += dt
		lvl_sum += lvl
		lvl_n += 1
	var bars := "|".repeat(int(clampf(lvl * 80.0, 0.0, 20.0)))
	panel.text = Loc.f("kara_now", [str(main.call_human), int(ceil(left))]) + "\n" + (">> " if lvl > 0.03 else "   ") + bars
	panel.modulate = Color.from_hsv(fmod(Time.get_ticks_msec() * 0.0004, 1.0), 0.45, 1.0)
	if left <= 0.0 or not main.in_call:
		_finish()


func _plan() -> void:
	if not main.in_call:
		return
	if main.call_t0 != plan_for:
		plan_for = main.call_t0
		var chance := 0.95 if Dev.args.has("karaoke") else 0.18
		var delay := randf_range(2.0, 4.0) if Dev.args.has("karaoke") else randf_range(12.0, 30.0)
		plan_at = main.t + delay if randf() < chance else -1.0
	if plan_at > 0.0 and main.t > plan_at and not main.busy:
		plan_at = -1.0
		start()


func start() -> void:
	active = true
	left = LENGTH
	sing_t = 0.0
	lvl_sum = 0.0
	lvl_n = 0
	lines0 = main.player_lines
	panel.visible = true
	Sfx.play("kazoo", -6.0)
	Sfx.loop("karaoke", "radio_chip", -12.0, true)
	main._log(Loc.t("kara_tag"), Loc.f("kara_log", [str(main.call_human)]), "#ff7ad9")
	if main.callview != null and not main.callview.people.is_empty():
		main.callview.people[0].emote("dance")
	_open_mic()
	if Dev.args.has("autoplay"):
		print("KARAOKE debut")


func _finish() -> void:
	active = false
	panel.visible = false
	Sfx.stop("karaoke")
	_close_mic()
	if not main.in_call:
		return
	var typed: int = main.player_lines - lines0
	var avg := lvl_sum / maxf(1.0, float(lvl_n))
	var score := clampi(int(round(sing_t / LENGTH * 7.0 + avg * 12.0 + float(typed) * 2.0 + randf_range(-1.0, 2.0))), 0, 10)
	if sing_t < 0.5 and typed == 0:
		score = 0
	var cards := []
	for d in main.npcs:
		if str(d["state"]) == "desk":
			cards.append([int(d["pod"]), clampi(score + randi_range(-2, 2), 0, 10)])
	if score == 0 and not cards.is_empty():
		cards[0][1] = 0
	show_cards(cards)
	if Net.active:
		main.sync.bcast(&"action", ["kara_cards", cards])
	var total := 0
	for c in cards:
		total += int(c[1])
	var mean := float(total) / maxf(1.0, float(cards.size()))
	main.conviction = clampi(main.conviction + int((mean - 4.0) * 7.0), 0, 100)
	if main.callview != null:
		main.callview.set_conviction(main.conviction)
	main._say(Loc.f("kara_result", ["%.1f" % mean]), 5.0)
	if mean >= 9.0:
		Profile.unlock("karaoke")
	main.viral.highlight("karaoke")
	if not main.busy:
		main._ask_ai(main.EVENT_TAG + Loc.f("mk_event", [Loc.f("kara_ai", ["%.1f" % mean])]))
	if Dev.args.has("autoplay"):
		print("KARAOKE note ", mean)


## Les cartons de notes au-dessus des collegues (vus par tout le monde).
func show_cards(cards: Array) -> void:
	var total := 0
	for c in cards:
		total += int(c[1])
		for d in main.npcs:
			if int(d["pod"]) != int(c[0]):
				continue
			var head: Node3D = d["char"].head
			if head == null:
				continue
			var card := Node3D.new()
			head.add_child(card)
			card.position = Vector3(0, 0.75, 0)
			var q := MeshInstance3D.new()
			var qm := QuadMesh.new()
			qm.size = Vector2(0.55, 0.48)
			q.mesh = qm
			var m := StandardMaterial3D.new()
			m.albedo_color = Color(1, 1, 1)
			m.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
			m.billboard_mode = BaseMaterial3D.BILLBOARD_ENABLED
			m.no_depth_test = true
			q.material_override = m
			card.add_child(q)
			var l := Label3D.new()
			l.text = str(int(c[1]))
			l.font = Loc.font("title")
			l.font_size = 150
			l.pixel_size = 0.0028
			l.modulate = Color(0.85, 0.05, 0.05) if int(c[1]) < 5 else Color(0.05, 0.05, 0.05)
			l.billboard = BaseMaterial3D.BILLBOARD_ENABLED
			l.no_depth_test = true
			l.render_priority = 2
			card.add_child(l)
			card.scale = Vector3.ONE * 0.1
			var tw := card.create_tween()
			tw.tween_property(card, "scale", Vector3.ONE, 0.25).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)
			tw.tween_interval(4.5)
			tw.tween_property(card, "scale", Vector3.ONE * 0.01, 0.3)
			tw.tween_callback(card.queue_free)
			d["char"].emote("wave" if int(c[1]) >= 5 else "facepalm")
	var mean := float(total) / maxf(1.0, float(cards.size()))
	if mean >= 6.0:
		Sfx.play("cheer", -4.0)
	else:
		Sfx.play("trombone", -4.0)


# ------------------------------------------------------------- niveau du micro

func _mic_level() -> float:
	if Dev.args.has("autoplay"):
		return 0.12 if randf() < 0.7 else 0.0
	var v = main.voice
	if v != null:
		return float(v.level) if v.transmitting else 0.0
	if capture == null:
		return 0.0
	var n := capture.get_frames_available()
	if n <= 0:
		return 0.0
	var buf := capture.get_buffer(n)
	var sum := 0.0
	for f in buf:
		sum += (f.x + f.y) * (f.x + f.y) * 0.25
	return sqrt(sum / float(buf.size()))


func _open_mic() -> void:
	# en solo, le chat vocal n'existe pas : on ouvre le micro seulement le temps de la chanson
	if main.voice != null or Loc.voice_mode == 2 or DisplayServer.get_name() == "headless":
		return
	var b := AudioServer.get_bus_index("Karaoke")
	if b < 0:
		AudioServer.add_bus()
		b = AudioServer.bus_count - 1
		AudioServer.set_bus_name(b, "Karaoke")
		AudioServer.add_bus_effect(b, AudioEffectCapture.new())
		AudioServer.set_bus_mute(b, true)
	capture = AudioServer.get_bus_effect(b, 0) as AudioEffectCapture
	capture.clear_buffer()
	mic_player = AudioStreamPlayer.new()
	mic_player.stream = AudioStreamMicrophone.new()
	mic_player.bus = "Karaoke"
	add_child(mic_player)
	mic_player.play()


func _close_mic() -> void:
	if mic_player != null:
		mic_player.queue_free()
	mic_player = null
	capture = null
