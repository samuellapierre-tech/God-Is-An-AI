extends Node3D
## MAINS EN PREMIERE PERSONNE (style « RV There Yet? ») : deux grosses mains
## de figurine toujours visibles en bas de l'ecran. Elles se balancent en
## marchant, tapent au clavier assises, attrapent les objets, giflent.

const Character := preload("res://scripts/character.gd")

var main: Node
var hands := []          # [Node3D gauche, Node3D droite]
var base := [Vector3(-0.27, -0.25, -0.42), Vector3(0.27, -0.25, -0.42)]
var t := 0.0
var walk := 0.0
var slap_t := 0.0
var wave_t := 0.0
var look_hash := ""


func _ready() -> void:
	rebuild()


func rebuild() -> void:
	for h in hands:
		(h as Node3D).queue_free()
	hands = []
	var lk: Dictionary = Profile.my_look()
	look_hash = str(lk.hash())
	var skin := Character.clay(lk.get("skin", Character.SKINS[0]), 0.7, {"bumps": 0.2})
	var short := str(lk.get("sleeves", "long")) == "short"
	var sleeve := Character.clay(skin.get_shader_parameter("albedo") if short else lk.get("shirt", Character.SHIRTS[0]), 0.85, {"bumps": 0.1})
	for i in 2:
		var sx := -1.0 if i == 0 else 1.0
		var h := Node3D.new()
		h.position = base[i]
		add_child(h)
		var hand := MeshInstance3D.new()
		hand.mesh = Character.mesh("fp_hand")
		hand.material_override = skin
		hand.scale = Vector3(sx * 1.75, 1.75, 1.75)     # main gauche = miroir
		hand.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
		h.add_child(hand)
		var sl := MeshInstance3D.new()
		sl.mesh = Character.mesh("fp_sleeve")
		sl.material_override = sleeve
		sl.scale = Vector3.ONE * 1.6
		sl.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
		h.add_child(sl)
		hands.append(h)


func punch() -> void:
	slap_t = 0.35


func wave() -> void:
	wave_t = 1.2


func _process(dt: float) -> void:
	t += dt
	slap_t = maxf(0.0, slap_t - dt)
	wave_t = maxf(0.0, wave_t - dt)
	if hands.size() < 2:
		return
	var p: CharacterBody3D = main.player
	var spd := Vector2(p.velocity.x, p.velocity.z).length() if p != null else 0.0
	walk += dt * spd * 2.2
	var moving := clampf(spd / 4.0, 0.0, 1.0)
	var seated: bool = main.seated
	var holding: bool = main.held != null and is_instance_valid(main.held)
	var in_call: bool = main.in_call
	visible = not main.frozen
	for i in 2:
		var h: Node3D = hands[i]
		var sx := -1.0 if i == 0 else 1.0
		var tp: Vector3 = base[i]
		var tr := Vector3(0.22, -sx * 0.18, sx * 0.12)
		# respiration + marche (balancier oppose)
		tp.y += sin(t * 1.6 + float(i)) * 0.006
		tp.y += absf(sin(walk + float(i) * PI)) * 0.03 * moving
		tp.z += sin(walk + float(i) * PI) * 0.04 * moving
		if seated:
			# clavier : les mains tombent devant, les doigts tapotent
			tp = Vector3(sx * 0.2, -0.32, -0.48)
			tr = Vector3(-0.35, -sx * 0.25, 0)
			if in_call:
				tp.y += absf(sin(t * 14.0 + float(i) * 1.7)) * 0.02
		if holding and i == 1:
			tp = Vector3(0.28, -0.2, -0.62)
			tr = Vector3(0.25, 0.1, -0.4)
		if slap_t > 0.0 and i == 1:
			var k := 1.0 - slap_t / 0.35
			tp = Vector3(lerpf(0.5, -0.15, k), -0.12, -0.55)
			tr = Vector3(0.1, 0.9 - k * 1.6, -1.3)
		if wave_t > 0.0 and i == 1:
			tp = Vector3(0.25, -0.05, -0.55)
			tr = Vector3(1.3, 0.0, sin(t * 14.0) * 0.5)
		h.position = h.position.lerp(tp, clampf(dt * (22.0 if slap_t > 0.0 else 10.0), 0.0, 1.0))
		h.rotation = h.rotation.lerp(tr, clampf(dt * 10.0, 0.0, 1.0))
