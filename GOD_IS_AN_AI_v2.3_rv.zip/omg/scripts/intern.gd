extends Node
## LE STAGIAIRE : un PNJ maladroit qui se promene dans le bureau.
## Il renverse du cafe, echappe des piles de papiers, fonce dans les gens
## et demande tout fort aux fideles « c'est quoi une simulation ? ».
## On peut le gifler et lui lancer des objets (il dit merci).
## L'hote le deplace ; les autres recoivent sa position dans l'etat du jeu.

var main: Node
var hold: Node3D
var c = null
var lbl: Label3D
var bub: Label3D
var path := []
var wait := 2.0
var next_event := 18.0
var say_t := 0.0
var net_pos := Vector3.ZERO
var net_yaw := 0.0
var step_t := 0.0
var bump_cd := 0.0


func _ready() -> void:
	hold = Node3D.new()
	main.add_child(hold)
	hold.position = Vector3(0, 0, 8.6)
	var Character = preload("res://scripts/character.gd")
	var rng := RandomNumberGenerator.new()
	rng.seed = 4242
	var lk: Dictionary = Character.preset("ziggy")
	lk["hat"] = "propeller"
	lk["googly"] = 0.8
	c = Character.new()
	hold.add_child(c)
	c.build(lk, "stand")
	c.position = Vector3(0, 0.78, 0)
	lbl = Label3D.new()
	lbl.text = Loc.t("intern_name")
	lbl.font = Loc.font("title")
	lbl.font_size = 40
	lbl.pixel_size = 0.004
	lbl.modulate = Color(0.6, 0.9, 1.0)
	lbl.outline_size = 10
	lbl.billboard = BaseMaterial3D.BILLBOARD_ENABLED
	lbl.position = Vector3(0, 2.25, 0)
	hold.add_child(lbl)
	bub = Label3D.new()
	bub.font = Loc.font("title")
	bub.font_size = 34
	bub.pixel_size = 0.004
	bub.outline_size = 10
	bub.outline_modulate = Color(0, 0, 0, 0.85)
	bub.billboard = BaseMaterial3D.BILLBOARD_ENABLED
	bub.width = 800
	bub.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	bub.position = Vector3(0, 2.6, 0)
	hold.add_child(bub)
	net_pos = hold.position


func say(text: String, secs := 3.5) -> void:
	bub.text = text
	say_t = secs
	c.say(minf(secs, 2.5))


func head_pos() -> Vector3:
	return (c.head as Node3D).global_position if c != null and c.head != null else hold.global_position + Vector3(0, 1.6, 0)


func _process(dt: float) -> void:
	if say_t > 0.0:
		say_t -= dt
		if say_t <= 0.0:
			bub.text = ""
	if not Net.is_host():
		# position recue de l'hote
		var before := hold.position
		hold.position = hold.position.lerp(net_pos, clampf(dt * 8.0, 0.0, 1.0))
		hold.rotation.y = lerp_angle(hold.rotation.y, net_yaw, clampf(dt * 8.0, 0.0, 1.0))
		c.walking = before.distance_to(hold.position) > dt * 0.4
		bump_cd -= dt
		var mp: Vector3 = main.player.global_position
		if bump_cd <= 0.0 and c.walking and Vector2(mp.x - hold.position.x, mp.z - hold.position.z).length() < 0.9:
			bump_cd = 3.0
			bump(Net.my_id())
		return
	if main.frozen:
		c.walking = false
		return
	_walk(dt)
	next_event -= dt
	if next_event <= 0.0:
		next_event = randf_range(14.0, 26.0) if not Dev.args.has("intern") else 5.0
		_event()


func _walk(dt: float) -> void:
	if wait > 0.0:
		wait -= dt
		c.walking = false
		# il regarde le joueur le plus proche, l'air perdu
		c.look_target = main.player
		if wait <= 0.0:
			_new_path()
		return
	if path.is_empty():
		wait = randf_range(1.5, 5.0)
		return
	c.look_target = null
	c.walking = true
	var target: Vector3 = path[0]
	var to := Vector3(target.x - hold.position.x, 0, target.z - hold.position.z)
	var dist := to.length()
	var spd := 1.7 * dt
	if dist <= spd:
		hold.position = Vector3(target.x, 0, target.z)
		path.pop_front()
	else:
		var dir := to / dist
		hold.position += dir * spd
		hold.rotation.y = lerp_angle(hold.rotation.y, atan2(-dir.x, -dir.z), clampf(dt * 8.0, 0.0, 1.0))
	step_t += dt
	if step_t > 0.38:
		step_t = 0.0
		Sfx.play_at("step%d" % (randi() % 4), hold.global_position, -18.0, 1.15)
	# il fonce dans le joueur
	var pp: Vector3 = main.player.global_position
	if Vector2(pp.x - hold.position.x, pp.z - hold.position.z).length() < 0.9 and randf() < dt * 3.0:
		bump(Net.my_id())
		if Net.active:
			main.sync.bcast(&"action", ["intern", {"e": "bump_fx"}])


func _new_path() -> void:
	var a0 := atan2(hold.position.x, hold.position.z)
	var a1 := a0 + randf_range(-2.4, 2.4)
	var r: float = [7.9, 7.9, 10.2][randi() % 3]
	path = main._ring_path(a0, a1, r)


## Ce que l'hote donne aux autres joueurs dans l'etat.
func state() -> Array:
	return [hold.position, hold.rotation.y]


func apply_state(st: Array) -> void:
	if st.size() >= 2:
		net_pos = st[0]
		net_yaw = float(st[1])


# ------------------------------------------------------------- betises

func _event() -> void:
	var e: String = ["spill", "papers", "simulation", "lines", "lines", "spill"][randi() % 6]
	var d := {"e": e, "pos": hold.global_position, "line": Loc.pick("intern_lines")}
	_do(e, d)
	if Net.active:
		main.sync.bcast(&"action", ["intern", d])


## Recu du reseau (ou local).
func net_event(d: Dictionary) -> void:
	_do(str(d.get("e", "")), d)


func _do(e: String, d: Dictionary) -> void:
	var pos: Vector3 = d.get("pos", hold.global_position)
	match e:
		"spill":
			say(Loc.pick("intern_oops"))
			main._make_puddle(Vector3(pos.x + 0.6, 0.02, pos.z))
			main.fun.pop(pos + Vector3(0, 2.0, 0), Loc.pick("pop_slip"), Color(0.6, 0.4, 0.2), 120)
			c.fall()
		"papers":
			say(Loc.pick("intern_oops"))
			Sfx.play_at("paper_hit", pos, 0.0, 0.8)
			for k in 7:
				var pp: RigidBody3D = main._prop(pos + Vector3(randf_range(-0.4, 0.4), 1.3 + randf() * 0.4, randf_range(-0.4, 0.4)), Vector3(0.22, 0.01, 0.3), Color(0.95, 0.95, 0.9), 0.05, Loc.t("prop_paper_sheet"))
				pp.linear_velocity = Vector3(randf_range(-2, 2), randf_range(1, 3), randf_range(-2, 2))
				pp.angular_velocity = Vector3(randf_range(-6, 6), randf_range(-6, 6), randf_range(-6, 6))
				main.get_tree().create_timer(25.0).timeout.connect(pp.queue_free)
			main.fun.pop(pos + Vector3(0, 2.0, 0), Loc.t("pop_papers"), Color(1, 1, 1), 120)
		"simulation":
			say(Loc.t("intern_sim"), 4.0)
			Sfx.play_at("honk", pos, -2.0)
			main.fun.pop(pos + Vector3(0, 2.2, 0), "SIMULATION ?!", Color(1.0, 0.3, 0.3), 140)
			if Net.is_host():
				main._add_expo(4.0)
				main._god_all(Loc.pick("god_intern"))
		"lines":
			say(str(d.get("line", "...")), 4.0)
		"bump_fx":
			say(Loc.pick("intern_sorry"), 2.0)
		"hit":
			say(Loc.pick("intern_hit"), 3.0)


## Il te fonce dedans.
func bump(_who: int) -> void:
	say(Loc.pick("intern_sorry"), 2.0)
	Sfx.play("boing", -6.0, 1.3)
	var away: Vector3 = (main.player.global_position - hold.global_position)
	away.y = 0.0
	main.player.global_position += away.normalized() * 0.7
	main.cam_shake = 0.3
	main.fun.pop(head_pos() + Vector3(0, 0.4, 0), Loc.t("pop_bump"), Color(0.6, 0.9, 1.0), 100)
