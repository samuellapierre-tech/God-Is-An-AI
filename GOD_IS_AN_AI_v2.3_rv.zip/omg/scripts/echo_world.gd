extends Node
## Comment REALITY ECHO se manifeste dans le bureau :
##  niveau 1 : un collegue en parle comme d'une coincidence
##  niveau 2 : le stagiaire et les fideles commencent a agir comme ca
##  niveau 3 : TENDANCE (Gazette, hologramme au-dessus de l'autel)
##  niveau 4 : un MOUVEMENT / une religion apparait (annonce de Dieu)
##  niveau 5 : REECRITURE DE LA REALITE (la Terre devient plate, des
##             pigeons-cameras envahissent le bureau, la gravite flanche...)

var main: Node
var holo: Label3D
var snap_t := 0.0
var dirty := false
var animals := []          # [Node3D, vitesse, cible]
var applied := {}
var fall_node: GPUParticles3D = null
var holo_flash := 0.0


func _ready() -> void:
	holo = Label3D.new()
	holo.font = Loc.font("title")
	holo.font_size = 40
	holo.pixel_size = 0.0045
	holo.modulate = Color(0.45, 1.0, 0.75)
	holo.outline_size = 12
	holo.outline_modulate = Color(0, 0.1, 0.05, 0.9)
	holo.billboard = BaseMaterial3D.BILLBOARD_ENABLED
	holo.width = 1000
	holo.vertical_alignment = VERTICAL_ALIGNMENT_BOTTOM
	holo.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	main.add_child(holo)
	holo.global_position = (main.earth.global_position if main.earth != null else Vector3(0, 3, 0)) + Vector3(0, 1.45, 0)
	holo.no_depth_test = true
	holo.render_priority = 5
	Reality.tier_up.connect(_on_tier)
	Reality.first_heard.connect(_on_first)
	Reality.seeded.connect(_on_seeded)
	Reality.changed.connect(func(): dirty = true)
	_refresh_holo()
	_apply_hooks()
	if Net.active and Net.is_host():
		dirty = true
		snap_t = 3.0


var resync_t := 45.0


func _process(dt: float) -> void:
	snap_t -= dt
	# l'hote renvoie le monde de temps en temps (joueur arrive en retard, paquet perdu)
	if Net.active and Net.is_host():
		resync_t -= dt
		if resync_t <= 0.0:
			resync_t = 45.0
			dirty = true
	if dirty and snap_t <= 0.0:
		dirty = false
		snap_t = 2.0
		_refresh_holo()
		_apply_hooks()
		if Net.active and Net.is_host():
			main.sync.bcast(&"action", ["reality", Reality.snapshot()])
	rec_cd -= dt
	holo_flash = maxf(0.0, holo_flash - dt * 0.8)
	holo.modulate = Color(0.45, 1.0, 0.75).lerp(Color(1.4, 1.4, 1.4), holo_flash)
	holo.modulate.a = 0.75 + 0.25 * sin(Time.get_ticks_msec() * 0.003)
	# la Terre du bureau bouge (elle flotte) : l'hologramme et la cascade la suivent
	if main.earth != null:
		holo.global_position = main.earth.global_position + Vector3(0, 1.45, 0)
		if fall_node != null:
			fall_node.global_position = main.earth.global_position
	_tick_animals(dt)


func _refresh_holo() -> void:
	var tr: Array = Reality.trends()
	if tr.is_empty() and Reality.rules.is_empty():
		holo.text = ""
		return
	var s := Loc.t("echo_holo_head") + "\n"
	for i in mini(3, tr.size()):
		var e: Dictionary = tr[i]
		var label := str(e["movement"]) if int(e["tier"]) >= 4 and str(e["movement"]) != "" else str(e["idea"])
		if str(e["kind"]) == "character" and str(e["name"]) != "":
			label = Loc.f("echo_char_famous", [str(e["name"])])
		s += "> " + label.substr(0, 60) + "\n"
	for r in Reality.rules.slice(-2):
		s += Loc.t("echo_holo_rule") + " " + str(r).substr(0, 60) + "\n"
	holo.text = s.strip_edges()


# ------------------------------------------------------------- « la simulation a entendu »

var rec_cd := 0.0


func _on_first(e: Dictionary) -> void:
	var q := str(e["orig"]).substr(0, 110)
	show_first(q, str(e["who"]))
	if Net.active and Net.is_host():
		main.sync.bcast(&"action", ["echo_first", {"q": q, "who": str(e["who"])}])


## Le moment ou les joueurs comprennent que le micro est dangereux.
func show_first(q: String, who: String) -> void:
	rec_cd = 90.0
	if main.frozen:
		return
	Sfx.play("glitch", -2.0)
	Sfx.play("god_speak", -8.0, 0.6)
	main.cam_shake = 0.25
	main.vignette.color = Color(0.3, 1.0, 0.5, 0.45)
	main.fun.pop(main.cam.global_position - main.cam.global_transform.basis.z * 2.2 + Vector3(0, 0.55, 0), Loc.t("echo_first_pop"), Color(0.45, 1.0, 0.7), 150)
	main._say(Loc.f("echo_first_say", [q, who]), 6.0)
	holo_flash = 1.0


func _on_seeded(e: Dictionary) -> void:
	if e.get("first", false) or rec_cd > 0.0 or main.frozen:
		return
	rec_cd = 90.0
	Sfx.play("ui_click", -10.0, 0.6)
	main._say(Loc.t("echo_rec"), 2.5)
	holo_flash = 0.6


# ------------------------------------------------------------- montee de niveau

func _on_tier(e: Dictionary) -> void:
	dirty = true
	var data := {"tier": int(e["tier"]), "idea": str(e["idea"]), "movement": str(e["movement"]),
		"rewrite": str(e["rewrite"]), "name": str(e["name"]), "kind": str(e["kind"]), "key": str(e["key"])}
	manifest(data)
	if Net.active and Net.is_host():
		main.sync.bcast(&"action", ["echo_tier", data])


func manifest(d: Dictionary) -> void:
	var idea := str(d["idea"])
	match int(d["tier"]):
		1:
			# une coincidence : un collegue en parle, un peu plus tard
			get_tree().create_timer(randf_range(6.0, 25.0)).timeout.connect(_npc_mention.bind(idea, "cw_echo_1"))
		2:
			get_tree().create_timer(randf_range(5.0, 20.0)).timeout.connect(_intern_mention.bind(idea))
		3:
			Game.mission_news.append(Loc.f("echo_gz_trend", [idea]))
			main._say(Loc.f("echo_trend_say", [idea]), 5.0)
			Sfx.play("shimmer", -6.0, 0.8)
			get_tree().create_timer(3.0).timeout.connect(_npc_mention.bind(idea, "cw_echo_3"))
			main.viral.highlight("echo_trend")
		4:
			var mv := str(d["movement"]) if str(d["movement"]) != "" else Loc.f("echo_movement_default", [str(d["key"]).replace("_", " ").to_upper()])
			if str(d["kind"]) == "character" and str(d["name"]) != "":
				mv = Loc.f("echo_char_famous", [str(d["name"])])
			main._god(Loc.f("echo_movement_god", [mv]))
			Game.mission_news.append(Loc.f("echo_gz_movement", [mv, idea]))
			Sfx.play("choir", -6.0)
			main.cam_shake = 0.3
			main.viral.highlight("echo_movement")
		5:
			_rewrite_fx(str(d["rewrite"]) if str(d["rewrite"]) != "" else idea)


func _npc_mention(idea: String, key: String) -> void:
	if main.npcs.is_empty():
		return
	var d: Dictionary = main.npcs[randi() % main.npcs.size()]
	var bub: Label3D = d["bub"]
	bub.text = Loc.f(key, [idea.substr(0, 80)])
	d["say"] = 6.0
	d["char"].say(2.5)


func _intern_mention(idea: String) -> void:
	if main.intern != null:
		main.intern.say(Loc.f("intern_echo", [idea.substr(0, 80)]), 6.0)


func _rewrite_fx(rule: String) -> void:
	Sfx.play("glitch", 0.0)
	Sfx.play("boom", -4.0)
	main.cam_shake = 1.2
	main.vignette.color = Color(0.3, 1.0, 0.5, 0.6)
	main._god(Loc.f("echo_rewrite_god", [rule]))
	main.fun.pop(main.cam.global_position - main.cam.global_transform.basis.z * 2.0 + Vector3(0, 0.4, 0), Loc.t("echo_rewrite_pop"), Color(0.4, 1.0, 0.6), 170)
	Game.mission_news.append(Loc.f("echo_gz_rewrite", [rule]))
	main.viral.highlight("echo_rewrite")
	Profile.unlock("rewrite")
	get_tree().create_timer(1.0).timeout.connect(_apply_hooks)


# ------------------------------------------------------------- reecritures visibles

func _apply_hooks() -> void:
	var h: Dictionary = Reality.hooks
	if h.has("flat") and not applied.has("flat") and main.earth != null:
		applied["flat"] = true
		# la Terre du bureau devient PLATE (l'eau tombe sur les cotes)
		var tw := main.create_tween()
		tw.tween_property(main.earth, "scale", Vector3(1.6, 0.07, 1.6), 2.5).set_trans(Tween.TRANS_ELASTIC)
		var ring := MeshInstance3D.new()
		var tm := TorusMesh.new()
		tm.inner_radius = 0.72
		tm.outer_radius = 0.8
		ring.mesh = tm
		var m := StandardMaterial3D.new()
		m.albedo_color = Color(0.9, 0.95, 1.0)
		m.emission_enabled = true
		m.emission = Color(0.7, 0.85, 1.0)
		ring.material_override = m
		main.earth.add_child(ring)
		var fall := GPUParticles3D.new()
		var pm := ParticleProcessMaterial.new()
		pm.emission_shape = ParticleProcessMaterial.EMISSION_SHAPE_RING
		pm.emission_ring_radius = 1.25
		pm.emission_ring_inner_radius = 1.2
		pm.emission_ring_height = 0.02
		pm.emission_ring_axis = Vector3(0, 1, 0)
		pm.gravity = Vector3(0, -3.0, 0)
		pm.color = Color(0.4, 0.7, 1.0)
		fall.process_material = pm
		var q := QuadMesh.new()
		q.size = Vector2(0.03, 0.08)
		var qm := StandardMaterial3D.new()
		qm.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
		qm.vertex_color_use_as_albedo = true
		qm.billboard_mode = BaseMaterial3D.BILLBOARD_PARTICLES
		q.material = qm
		fall.draw_pass_1 = q
		fall.amount = 160
		fall.lifetime = 1.6
		main.add_child(fall)
		fall.global_position = main.earth.global_position
		fall_node = fall
	if h.has("pigeon") and not applied.has("pigeon"):
		applied["pigeon"] = true
		for k in 6:
			_spawn_animal("pigeon")
	if h.has("cat") and not applied.has("cat"):
		applied["cat"] = true
		for k in 4:
			_spawn_animal("cat")
	if h.has("night") and not applied.has("night"):
		applied["night"] = true      # l'eclairage lit Reality.hooks directement (main._process)
		if main.flashlight != null:
			main.flash_on = true


func gravity_scale() -> float:
	return 0.3 if Reality.hooks.has("gravity") else 1.0


func _spawn_animal(kind: String) -> void:
	var n := Node3D.new()
	main.add_child(n)
	var a := randf() * TAU
	n.position = Vector3(sin(a) * randf_range(4.5, 9.0), 0, cos(a) * randf_range(4.5, 9.0))
	var body := MeshInstance3D.new()
	var sm := SphereMesh.new()
	var m := StandardMaterial3D.new()
	if kind == "pigeon":
		sm.radius = 0.16
		sm.height = 0.28
		m.albedo_color = Color(0.55, 0.57, 0.62)
		body.position.y = 0.2
		var head := MeshInstance3D.new()
		var hs := SphereMesh.new()
		hs.radius = 0.08
		hs.height = 0.16
		head.mesh = hs
		head.material_override = m
		head.position = Vector3(0, 0.38, -0.12)
		n.add_child(head)
		# l'oeil-camera rouge
		var eye := MeshInstance3D.new()
		var es := SphereMesh.new()
		es.radius = 0.025
		es.height = 0.05
		eye.mesh = es
		var em := StandardMaterial3D.new()
		em.albedo_color = Color(1, 0.1, 0.1)
		em.emission_enabled = true
		em.emission = Color(1, 0.1, 0.1)
		em.emission_energy_multiplier = 3.0
		eye.material_override = em
		eye.position = Vector3(0.04, 0.4, -0.19)
		n.add_child(eye)
	else:
		sm.radius = 0.2
		sm.height = 0.45
		m.albedo_color = Color(0.95, 0.55, 0.2)
		body.position.y = 0.22
		for sx in [-1.0, 1.0]:
			var ear := MeshInstance3D.new()
			var pmh := PrismMesh.new()
			pmh.size = Vector3(0.08, 0.1, 0.03)
			ear.mesh = pmh
			ear.material_override = m
			ear.position = Vector3(sx * 0.08, 0.55, -0.05)
			n.add_child(ear)
	body.mesh = sm
	body.material_override = m
	n.add_child(body)
	n.scale = Vector3.ONE * (1.9 if kind == "pigeon" else 1.6)
	animals.append([n, randf_range(0.6, 1.4), n.position, kind])


func _tick_animals(dt: float) -> void:
	for a in animals:
		var n: Node3D = a[0]
		if not is_instance_valid(n):
			continue
		if str(a[3]) == "cat":
			# les chats fixent le plafond (ils voient Dieu)
			n.rotation.y += dt * 0.2
			continue
		var target: Vector3 = a[2]
		if n.position.distance_to(target) < 0.3:
			var ang := randf() * TAU
			a[2] = Vector3(sin(ang) * randf_range(5.0, 12.0), 0, cos(ang) * randf_range(5.0, 12.0))
		var dir := (target - n.position)
		dir.y = 0.0
		n.position += dir.normalized() * float(a[1]) * dt
		# ...mais il te regarde toujours
		var p: Vector3 = main.player.global_position
		var flat := Vector3(p.x, n.global_position.y, p.z)
		if flat.distance_to(n.global_position) > 0.05:
			n.look_at(flat, Vector3.UP)
