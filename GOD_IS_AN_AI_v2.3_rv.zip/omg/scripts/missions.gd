extends Node
## ORDRES DE MISSION DIVINS
## A chaque appel, Dieu tend 3 cartes : facile (+), absurde (++), complement
## fou (+++). La mission est SECRETE : le fidele ne la connait pas. Chaque
## carte a un MOT INTERDIT : l'ecrire = mission ratee. L'IA juge si le fidele
## a fini par accepter. Les missions reussies reviennent en rappel (avec des
## consequences absurdes) et font la une de la Gazette.
##
## Co-op : un collegue (et toujours l'agent de Satan) recoit une mission de
## SABOTAGE : te faire ecrire le mot interdit. Twitch : le chat vote la carte.

const REWARD := [0, 150, 300, 600]
const PICK_TIME := 12.0

var main: Node
var state := ""              # "" / "choose" / "active" / "done" / "failed"
var cards := []              # [{tier, t, ai, w, k, n}]
var cur := {}
var choose_left := 0.0
var panel: PanelContainer
var btns := []
var head_lbl: Label
var vote_lbl: Label
var sabotage := {}           # {by, name, word}
var lines_with_kw := 0


func _ready() -> void:
	panel = PanelContainer.new()
	var sb := StyleBoxFlat.new()
	sb.bg_color = Color(0.05, 0.02, 0.06, 0.96)
	sb.border_color = Color(1.0, 0.75, 0.2)
	sb.set_border_width_all(3)
	sb.set_content_margin_all(18)
	panel.add_theme_stylebox_override("panel", sb)
	panel.set_anchors_preset(Control.PRESET_CENTER)
	panel.offset_left = -640
	panel.offset_right = 640
	panel.offset_top = -250
	panel.offset_bottom = 250
	panel.visible = false
	main.hud_layer.add_child(panel)
	var v := VBoxContainer.new()
	v.add_theme_constant_override("separation", 12)
	panel.add_child(v)
	head_lbl = _l(v, "title", 40, Color(1.0, 0.8, 0.3))
	head_lbl.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 14)
	row.size_flags_vertical = Control.SIZE_EXPAND_FILL
	v.add_child(row)
	for i in 3:
		var b := Button.new()
		b.custom_minimum_size = Vector2(390, 330)
		b.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		b.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		b.add_theme_font_override("font", Loc.font("bold"))
		b.add_theme_font_size_override("font_size", 21)
		b.add_theme_color_override("font_color", Color(1, 0.95, 0.85))
		b.add_theme_color_override("font_hover_color", Color(0.1, 0.05, 0.0))
		var col: Color = [Color(0.2, 0.45, 0.25), Color(0.5, 0.35, 0.1), Color(0.55, 0.12, 0.35)][i]
		var n := StyleBoxFlat.new()
		n.bg_color = col.darkened(0.45)
		n.border_color = col.lightened(0.3)
		n.set_border_width_all(3)
		n.set_corner_radius_all(10)
		n.set_content_margin_all(14)
		b.add_theme_stylebox_override("normal", n)
		var h := n.duplicate()
		h.bg_color = Color(1.0, 0.85, 0.45)
		b.add_theme_stylebox_override("hover", h)
		b.add_theme_stylebox_override("focus", n)
		b.pressed.connect(choose.bind(i))
		b.mouse_entered.connect(Sfx.play.bind("ui_hover", -10.0, 1.0))
		row.add_child(b)
		btns.append(b)
	vote_lbl = _l(v, "mono", 16, Color(0.75, 0.6, 1.0))
	vote_lbl.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER


func _l(par: Node, fk: String, size: int, col: Color) -> Label:
	var l := Label.new()
	l.add_theme_font_override("font", Loc.font(fk))
	l.add_theme_font_size_override("font_size", size)
	l.add_theme_color_override("font_color", col)
	l.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	par.add_child(l)
	return l


# ------------------------------------------------------------- cartes

static func _entry(tier: int) -> Dictionary:
	var pool: Array = Loc.list("missions_%d" % tier)
	var e: Array = pool[randi() % pool.size()]
	return {"tier": tier, "t": str(e[0]), "ai": str(e[1]), "w": str(e[2]), "k": str(e[3]), "n": str(e[4])}


## Debut d'un de MES appels.
func offer() -> void:
	cards = [_entry(1), _entry(2), _entry(3)]
	state = "choose"
	cur = {}
	lines_with_kw = 0
	choose_left = PICK_TIME
	Stream.mission_votes = {}
	head_lbl.text = Loc.t("mis_pick")
	for i in 3:
		var c: Dictionary = cards[i]
		btns[i].text = "%s\n\n%s\n\n%s\n\n+%d $" % ["+".repeat(int(c["tier"])) + "  " + str(Loc.list("mis_tiers")[i]), c["t"], Loc.f("mis_word", [c["w"]]), REWARD[int(c["tier"])]]
	Sfx.play("shimmer", -6.0, 1.2)


func choose(i: int) -> void:
	if state != "choose":
		return
	cur = cards[clampi(i, 0, 2)]
	state = "active"
	panel.visible = false
	Sfx.play("ui_click", -2.0)
	main._log(Loc.t("mis_tag"), Loc.f("mis_log", [cur["t"], cur["w"]]), "#ffd166")
	main._update_status()
	if Net.active:
		main.sync.bcast(&"action", ["mis_start", {"word": cur["w"], "t": cur["t"]}])
	if Dev.args.has("autoplay"):
		print("MISSION choisie : ", cur["t"], " / interdit : ", cur["w"])


func _process(dt: float) -> void:
	if state == "choose":
		if not main.in_call:
			state = ""
			panel.visible = false
			return
		panel.visible = main.seated and not main.frozen
		choose_left -= dt
		var tw := ""
		if Stream.channel != "":
			var v: Array = Stream.mission_tally()
			tw = Loc.f("mis_twitch", [int(v[0]), int(v[1]), int(v[2])]) + "\n"
		vote_lbl.text = tw + Loc.f("mis_auto", [int(ceil(choose_left))])
		if Dev.args.has("autoplay") and choose_left < PICK_TIME - 1.0:
			choose(randi() % 3)
		elif choose_left <= 0.0:
			var pick := 1
			if Stream.channel != "":
				var v2: Array = Stream.mission_tally()
				if int(v2[0]) + int(v2[1]) + int(v2[2]) > 0:
					pick = v2.find(v2.max())
			choose(pick)


# ------------------------------------------------------------- en cours d'appel

func active() -> bool:
	return state == "active"


func _norm(s: String) -> String:
	var out := s.to_lower()
	for pair in [["é", "e"], ["è", "e"], ["ê", "e"], ["ë", "e"], ["à", "a"], ["â", "a"], ["î", "i"], ["ï", "i"], ["ô", "o"], ["ù", "u"], ["û", "u"], ["ç", "c"]]:
		out = out.replace(pair[0], pair[1])
	return out


## Chaque phrase que J'ecris au fidele.
func on_player_line(txt: String) -> void:
	if state != "active":
		return
	var low := _norm(txt)
	var w := _norm(str(cur["w"]))
	if w != "":
		var clean := low
		for ch in [",", ".", "!", "?", ";", ":", "'", "\"", "«", "»", "(", ")", "-"]:
			clean = clean.replace(ch, " ")
		for word in clean.split(" ", false):
			if word.begins_with(w):
				_fail()
				return
	# mode hors ligne : on detecte grossierement si on parle de la mission
	if main.api_key == "" and not Relay.enabled():
		for k in str(cur["k"]).split(",", false):
			if low.contains(_norm(k.strip_edges())):
				lines_with_kw += 1
				break
		if lines_with_kw >= 2 and main.conviction >= 35 and randf() < 0.55:
			success()


## Texte ajoute au role de l'IA (le fidele ne connait PAS la mission).
func ai_prompt() -> String:
	if state != "active":
		return ""
	return Loc.f("ai_mission", [cur["ai"]])


func success() -> void:
	if state != "active":
		return
	state = "done"
	var tier := int(cur["tier"])
	main._money(REWARD[tier])
	Sfx.play("kazoo", -2.0)
	Sfx.play("cheer", -6.0)
	main.fun.confetti(main.pod_pos[main.MY_POD] + Vector3(0, 1.4, 0))
	main.fun.pop(main.cam.global_position - main.cam.global_transform.basis.z * 1.6 + Vector3(0, 0.3, 0), Loc.t("mis_ok_pop"), Color(1.0, 0.85, 0.2), 150)
	main._say(Loc.f("mis_ok", [cur["t"], REWARD[tier]]), 5.0)
	main._log(Loc.t("mis_tag"), Loc.f("mis_ok", [cur["t"], REWARD[tier]]), "#8affc0")
	var news := Loc.f("gz_mission", [str(main.cur_b.get("name", "?")), str(main.cur_b.get("place", "?")), cur["n"]])
	main.cur_b["mission_news"] = cur["n"]
	main.queue_consequence(main.cur_b, cur["n"])
	Game.mission_news.append(news)
	if Net.active:
		main.sync.bcast(&"action", ["mis_done", {"news": news, "ok": true}])
	Profile.unlock("mission")
	if tier == 3:
		Profile.unlock("mission_fou")
	Profile.count("missions")
	main._stat("missions")
	main.viral.highlight("mission")
	main._update_status()
	if Dev.args.has("autoplay"):
		print("MISSION REUSSIE ", cur["t"])


func _fail() -> void:
	state = "failed"
	Sfx.play("error", -2.0)
	Sfx.play("trombone", -6.0)
	main.fun.pop(main.cam.global_position - main.cam.global_transform.basis.z * 1.6, Loc.t("mis_word_pop"), Color(1.0, 0.25, 0.25), 150)
	main._say(Loc.f("mis_fail_word", [cur["w"]]), 5.0)
	main._log(Loc.t("mis_tag"), Loc.f("mis_fail_word", [cur["w"]]), "#ff6666")
	main._god(Loc.pick("god_mis_word"))
	if Net.active:
		main.sync.bcast(&"action", ["mis_done", {"ok": false, "word": true}])
	main._update_status()
	if Dev.args.has("autoplay"):
		print("MISSION RATEE (mot interdit)")


func end_call() -> void:
	if state == "choose":
		panel.visible = false
	if state == "active" and Net.active:
		main.sync.bcast(&"action", ["mis_done", {"ok": false, "word": false}])
	state = ""
	cur = {}


func status_text() -> String:
	match state:
		"active":
			return Loc.f("mis_status", ["+".repeat(int(cur["tier"])), cur["t"], cur["w"]])
		"done":
			return Loc.t("mis_status_ok")
		"failed":
			return Loc.t("mis_status_fail")
	return ""


func hud_text() -> String:
	var out := ""
	if state == "active":
		out = Loc.f("mis_hud", [cur["t"], cur["w"]])
	if not sabotage.is_empty():
		out += ("\n" if out != "" else "") + Loc.f("sab_hud", [sabotage["name"], sabotage["word"]])
	return out


# ------------------------------------------------------------- co-op : sabotage

func net_event(kind: String, from: int, d: Dictionary) -> void:
	var nm := str(Net.players.get(from, {}).get("name", "?"))
	match kind:
		"mis_start":
			if Net.i_am_satan() or randf() < 0.5:
				sabotage = {"by": from, "name": nm, "word": str(d["word"])}
				main._say(Loc.f("sab_new", [nm, str(d["word"])]), 7.0)
				Sfx.play("honk", -6.0)
		"mis_done":
			if d.has("news"):
				Game.mission_news.append(str(d["news"]))
				main._say(Loc.f("mis_other_ok", [nm]), 3.0)
			if not sabotage.is_empty() and int(sabotage["by"]) == from:
				if bool(d.get("word", false)):
					main._money(200)
					main.fun.pop(main.cam.global_position - main.cam.global_transform.basis.z * 1.6, Loc.t("sab_ok_pop"), Color(1.0, 0.3, 0.9), 140)
					main._say(Loc.f("sab_ok", [nm]), 4.0)
					Sfx.play("laugh", -4.0)
					Profile.unlock("saboteur")
				sabotage = {}
