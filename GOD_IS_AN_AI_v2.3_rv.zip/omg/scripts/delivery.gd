extends Node
## LIVRAISON EN PLEINE TRONCHE
## Les collegues (PNJ et amis) commandent des objets. Dieu les fait tomber
## du ciel pres de l'autel. Regle de la maison : on ne REMET rien en main
## propre. On le LANCE AU VISAGE. SMACK.
##
## L'hote decide des commandes ; chacun detecte ses propres lancers.

const ITEMS := {
	# id : [couleur de la tache, son a l'impact, pop]
	"pie": [Color(0.98, 0.97, 0.92), "slap", "pop_pie"],
	"donut": [Color(1.0, 0.55, 0.75), "slap", "pop_smack"],
	"fish": [Color(0.75, 0.85, 0.9), "slap", "pop_fish"],
	"pizza": [Color(0.95, 0.55, 0.15), "slap", "pop_smack"],
	"stapler": [Color(0.0, 0.0, 0.0, 0.0), "bonk", "pop_bonk"],
	"tp": [Color(0.0, 0.0, 0.0, 0.0), "boing", "pop_bonk"],
	"baguette": [Color(0.0, 0.0, 0.0, 0.0), "bonk", "pop_bonk"],
	"file": [Color(0.0, 0.0, 0.0, 0.0), "paper_hit", "pop_smack"],
}
const LIFE := 50.0

var main: Node
var reqs := {}            # id -> {"k", "id", "item", "left", "label": Label3D}
var next_req := 25.0
var next_id := 1
var drops := {}           # id de commande -> RigidBody3D
var splat_layer: CanvasLayer
var splat_rect: TextureRect


func _ready() -> void:
	next_req = 8.0 if Dev.args.has("deliv") else randf_range(20.0, 35.0)
	splat_layer = CanvasLayer.new()
	splat_layer.layer = 7
	add_child(splat_layer)
	splat_rect = TextureRect.new()
	splat_rect.set_anchors_preset(Control.PRESET_FULL_RECT)
	splat_rect.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	splat_rect.stretch_mode = TextureRect.STRETCH_SCALE
	splat_rect.mouse_filter = Control.MOUSE_FILTER_IGNORE
	splat_rect.modulate.a = 0.0
	splat_rect.texture_filter = CanvasItem.TEXTURE_FILTER_LINEAR
	splat_layer.add_child(splat_rect)


# ------------------------------------------------------------- l'hote cree les commandes

func _process(dt: float) -> void:
	for id in reqs.keys():
		var r: Dictionary = reqs[id]
		r["left"] = float(r["left"]) - dt
		_update_label(r)
		if float(r["left"]) <= 0.0 and Net.is_host():
			_expire(int(id))
	if splat_rect.modulate.a > 0.0:
		splat_rect.modulate.a = maxf(0.0, splat_rect.modulate.a - dt * 0.22)
	if main.frozen or not Net.is_host():
		return
	next_req -= dt
	var max_open := 1 + Net.count() / 2
	if next_req <= 0.0 and reqs.size() < max_open:
		next_req = randf_range(30.0, 55.0) if not Dev.args.has("deliv") else 6.0
		_new_request()


func _new_request() -> void:
	var cands := []
	for d in main.npcs:
		if str(d["state"]) == "desk":
			cands.append(["npc", int(d["pod"])])
	if Net.active:
		for pid in Net.players:
			cands.append(["peer", int(pid)])
			cands.append(["peer", int(pid)])   # les amis sont choisis plus souvent : c'est plus drole
	if cands.is_empty():
		return
	var c: Array = cands[randi() % cands.size()]
	var keys := ITEMS.keys()
	var item: String = keys[randi() % keys.size()]
	var ang := randf() * TAU
	var data := {"rid": next_id, "k": c[0], "id": c[1], "item": item, "pos": Vector3(sin(ang) * 4.6, 6.5, cos(ang) * 4.6)}
	next_id += 1
	_send("req_new", data)


func _send(kind: String, data: Variant) -> void:
	handle(kind, data, Net.my_id())
	if Net.active:
		main.sync.bcast(&"action", ["dlv_" + kind, data])


## Point d'entree (local ou reseau).
func handle(kind: String, data: Variant, from: int) -> void:
	match kind:
		"req_new":
			_open(data)
		"req_done":
			_done(data)
		"req_late":
			_late(int(data))
		"taken":
			var rid := int(data)
			if drops.has(rid) and is_instance_valid(drops[rid]) and drops[rid] != main.held:
				drops[rid].queue_free()
			drops.erase(rid)
		"smack":
			_smack_fx(str(data["k"]), int(data["id"]), str(data["item"]), from)
		"deliver":
			if Net.is_host():
				_check_delivery(data, from)


# ------------------------------------------------------------- commandes

func _target_name(k: String, id: int) -> String:
	if k == "peer":
		return str(Net.players.get(id, {}).get("name", "?"))
	return str(main.WHO[id])


func _open(d: Dictionary) -> void:
	var rid := int(d["rid"])
	var r := {"k": str(d["k"]), "id": int(d["id"]), "item": str(d["item"]), "left": LIFE, "label": null}
	reqs[rid] = r
	var nm := _target_name(r["k"], r["id"])
	var it := Loc.t("item_dl_" + str(r["item"]))
	# l'objet tombe du ciel
	var rb := make_item(str(r["item"]), d["pos"])
	rb.set_meta("rid", rid)
	drops[rid] = rb
	Sfx.play_at("whistle_down", d["pos"], -4.0)
	if r["k"] == "peer" and r["id"] == Net.my_id():
		main._say(Loc.f("dl_for_me", [it]), 6.0)
		Sfx.play("honk", -4.0)
	else:
		main._say(Loc.f("dl_new", [nm, it]), 5.0)
	# la bulle au-dessus de la tete
	var tg: Array = main.fun._find(r["k"], r["id"])
	if not tg.is_empty():
		var l := Label3D.new()
		l.font = Loc.font("title")
		l.font_size = 64
		l.pixel_size = 0.004
		l.outline_size = 18
		l.outline_modulate = Color(0, 0, 0)
		l.billboard = BaseMaterial3D.BILLBOARD_ENABLED
		l.no_depth_test = true
		l.modulate = Color(1.0, 0.85, 0.2)
		(tg[2].head as Node3D).add_child(l)
		l.position = Vector3(0, 0.6, 0)
		r["label"] = l
		if r["k"] == "npc":
			for dd in main.npcs:
				if int(dd["pod"]) == int(r["id"]):
					var bub: Label3D = dd["bub"]
					bub.text = Loc.f("dl_shout", [it])
					dd["say"] = 4.0
					dd["char"].emote("wave")
	_update_label(r)


func _update_label(r: Dictionary) -> void:
	var l = r.get("label", null)
	if l == null or not is_instance_valid(l):
		return
	(l as Label3D).text = "! %s !\n%d s" % [Loc.t("item_dl_" + str(r["item"])).to_upper(), int(ceil(float(r["left"])))]
	(l as Label3D).position.y = 0.6 + sin(Time.get_ticks_msec() * 0.006) * 0.05


func _close(rid: int) -> Dictionary:
	if not reqs.has(rid):
		return {}
	var r: Dictionary = reqs[rid]
	reqs.erase(rid)
	var l = r.get("label", null)
	if l != null and is_instance_valid(l):
		l.queue_free()
	return r


func _expire(rid: int) -> void:
	_send("req_late", rid)


func _late(rid: int) -> void:
	var r := _close(rid)
	if r.is_empty():
		return
	var nm := _target_name(r["k"], r["id"])
	main._say(Loc.f("dl_late", [nm]), 4.0)
	Sfx.play("trombone", -8.0)
	if drops.has(rid) and is_instance_valid(drops[rid]) and drops[rid] != main.held:
		drops[rid].queue_free()
	drops.erase(rid)
	if Net.is_host():
		main._add_expo(2.0)


## Texte pour le HUD : commandes ouvertes.
func hud_text() -> String:
	var out := ""
	for rid in reqs:
		var r: Dictionary = reqs[rid]
		var who := Loc.t("dl_you") if (r["k"] == "peer" and r["id"] == Net.my_id()) else _target_name(r["k"], r["id"])
		out += Loc.f("dl_hud", [Loc.t("item_dl_" + str(r["item"])), who, int(ceil(float(r["left"])))]) + "\n"
	return out.strip_edges()


# ------------------------------------------------------------- impact (detecte par le lanceur)

## Appele par fun.gd quand un objet lance touche une tete.
func hit(rb: RigidBody3D, tg: Array, dist: float) -> void:
	var item := str(rb.get_meta("item", "prop"))
	var data := {"k": tg[0], "id": tg[1], "item": item}
	_send("smack", data)
	Profile.unlock("face")
	main._stat("smacks")
	# est-ce une livraison ?
	for rid in reqs:
		var r: Dictionary = reqs[rid]
		if r["k"] == tg[0] and int(r["id"]) == int(tg[1]):
			var dd := {"rid": rid, "item": item, "dist": dist}
			if Net.is_host():
				_check_delivery(dd, Net.my_id())
			else:
				main.sync.bcast(&"action", ["dlv_deliver", dd])
			return


func _check_delivery(d: Dictionary, from: int) -> void:
	var rid := int(d["rid"])
	if not reqs.has(rid):
		return
	var r: Dictionary = reqs[rid]
	if str(r["item"]) != str(d["item"]):
		return
	var dist := float(d["dist"])
	var gain := 90 + int(dist * 18.0) + (150 if dist > 10.0 else 0)
	main._money(gain)
	main._add_expo(-2.0)
	_send("req_done", {"rid": rid, "by": from, "gain": gain, "dist": dist})


func _done(d: Dictionary) -> void:
	var r := _close(int(d["rid"]))
	if r.is_empty():
		return
	var by := int(d["by"])
	var who := Loc.t("dl_you") if by == Net.my_id() else str(Net.players.get(by, {}).get("name", main.WHO[0]))
	var dist := float(d["dist"])
	var msg := Loc.f("dl_done_me", [Loc.t("item_dl_" + str(r["item"])), _target_name(r["k"], r["id"]), int(d["gain"])]) if by == Net.my_id() else Loc.f("dl_done", [who, Loc.t("item_dl_" + str(r["item"])), _target_name(r["k"], r["id"]), int(d["gain"])])
	if dist > 10.0:
		msg = Loc.f("dl_snipe", [int(dist)]) + "  " + msg
		Sfx.play("cheer", -6.0)
	main._say(msg, 4.5)
	Sfx.play("sale", -6.0, 1.2)
	if Dev.args.has("autoplay"):
		print("LIVRAISON ", r["item"], " -> ", r["k"], " ", r["id"], " par ", by, " dist ", int(dist), " gain ", d["gain"])
	if by == Net.my_id():
		Profile.count("deliveries")
		if dist > 10.0:
			Profile.unlock("snipe")
	var tg: Array = main.fun._find(r["k"], r["id"])
	if not tg.is_empty():
		main.fun.pop((tg[3] as Vector3) + Vector3(0, 0.75, 0), Loc.pick("pop_delivered"), Color(0.5, 1.0, 0.45), 110)
		if r["k"] == "npc":
			for dd in main.npcs:
				if int(dd["pod"]) == int(r["id"]):
					var bub: Label3D = dd["bub"]
					bub.text = Loc.pick("dl_thanks")
					dd["say"] = 4.0


## Effet de l'impact, vu par tout le monde.
func _smack_fx(k: String, id: int, item: String, from: int) -> void:
	var info: Array = ITEMS.get(item, [Color(0, 0, 0, 0), "slap", "pop_smack"])
	if k == "peer" and id == Net.my_id():
		_me_hit(item, info, from)
		return
	var tg: Array = main.fun._find(k, id)
	if tg.is_empty():
		return
	var c = tg[2]
	var hp: Vector3 = tg[3]
	if k == "intern":
		main.intern.say(Loc.pick("intern_hit"), 3.0)
	Sfx.play_at(str(info[1]), hp, 3.0, randf_range(0.9, 1.1))
	Sfx.play_at("slap", hp, 0.0, 0.8)
	main.fun.pop(hp + Vector3(0, 0.35, 0), Loc.pick(str(info[2])), Color(1.0, 0.45, 0.2), 130)
	c.daze(2.5)
	c.bounce = 1.0
	if (info[0] as Color).a > 0.0:
		c.splat(info[0])
	if k == "npc":
		var pending := false
		for rid in reqs:
			if reqs[rid]["k"] == "npc" and int(reqs[rid]["id"]) == id:
				pending = true
		if not pending:
			for dd in main.npcs:
				if int(dd["pod"]) == id:
					var bub: Label3D = dd["bub"]
					bub.text = Loc.pick("dl_hey")
					dd["say"] = 3.0
	main.viral.highlight("smack")


func _me_hit(item: String, info: Array, from: int) -> void:
	Sfx.play(str(info[1]), 3.0)
	Sfx.play("slap", 0.0, 0.8)
	main.fun.roll = 0.7
	main.cam_shake = 0.8
	var who := str(Net.players.get(from, {}).get("name", "?"))
	main._say(Loc.f("dl_hit_me", [who, Loc.t("item_dl_" + item)]), 3.5)
	var col: Color = info[0]
	if col.a > 0.0:
		splat_rect.texture = ImageTexture.create_from_image(_splat_image(col))
		splat_rect.modulate.a = 1.0
	main.viral.highlight("smacked")


func _splat_image(col: Color) -> Image:
	var w := 320
	var h := 180
	var img := Image.create(w, h, false, Image.FORMAT_RGBA8)
	img.fill(Color(0, 0, 0, 0))
	var cx := randf_range(110, 210)
	var cy := randf_range(60, 120)
	for k in 26:
		var bx := cx + randf_range(-110, 110)
		var by := cy + randf_range(-70, 70)
		var r := randf_range(10, 38) * (1.0 - Vector2(bx - cx, by - cy).length() / 160.0)
		if r < 4.0:
			continue
		for y in range(maxi(0, int(by - r)), mini(h, int(by + r))):
			for x in range(maxi(0, int(bx - r)), mini(w, int(bx + r))):
				var dd := Vector2(x - bx, y - by).length() / r
				if dd < 1.0:
					var old := img.get_pixel(x, y)
					var a := clampf((1.0 - dd) * 3.0, 0.0, 0.97)
					var shade := 1.0 - dd * 0.18
					if a > old.a:
						img.set_pixel(x, y, Color(col.r * shade, col.g * shade, col.b * shade, a))
	# coulisses
	for k in 9:
		var dx := int(cx + randf_range(-100, 100))
		var len := randi_range(20, 80)
		for y in range(int(cy), mini(h, int(cy) + len)):
			for x in range(maxi(0, dx - 3), mini(w, dx + 3)):
				img.set_pixel(x, y, Color(col.r, col.g, col.b, 0.9))
	return img


# ------------------------------------------------------------- objets

func make_item(id: String, pos: Vector3) -> RigidBody3D:
	var rb: RigidBody3D = main._prop(pos, Vector3(0.24, 0.12, 0.24), Color(1, 1, 1), 0.35, Loc.t("item_dl_" + id))
	for ch in rb.get_children():
		if ch is MeshInstance3D:
			ch.visible = false
	rb.set_meta("item", id)
	rb.continuous_cd = true
	match id:
		"pie":
			_cyl(rb, Vector3.ZERO, 0.13, 0.11, 0.05, Color(0.85, 0.6, 0.3))
			_ball(rb, Vector3(0, 0.04, 0), 0.12, Color(0.98, 0.97, 0.92), Vector3(1, 0.35, 1))
			_ball(rb, Vector3(0, 0.08, 0), 0.025, Color(0.9, 0.1, 0.15))
		"donut":
			var tm := TorusMesh.new()
			tm.inner_radius = 0.04
			tm.outer_radius = 0.11
			_mesh(rb, tm, Vector3.ZERO, Color(0.85, 0.6, 0.3))
			var tm2 := TorusMesh.new()
			tm2.inner_radius = 0.045
			tm2.outer_radius = 0.105
			_mesh(rb, tm2, Vector3(0, 0.02, 0), Color(1.0, 0.5, 0.75))
		"fish":
			_ball(rb, Vector3.ZERO, 0.08, Color(0.6, 0.7, 0.78), Vector3(2.2, 0.8, 0.6))
			var pm := PrismMesh.new()
			pm.size = Vector3(0.12, 0.12, 0.03)
			var tail := _mesh(rb, pm, Vector3(-0.2, 0, 0), Color(0.5, 0.6, 0.7))
			tail.rotation_degrees = Vector3(0, 0, 90)
			_ball(rb, Vector3(0.13, 0.02, 0.04), 0.015, Color(0, 0, 0))
		"pizza":
			var pz := PrismMesh.new()
			pz.size = Vector3(0.22, 0.28, 0.03)
			var sl := _mesh(rb, pz, Vector3.ZERO, Color(1.0, 0.75, 0.3))
			sl.rotation_degrees = Vector3(90, 0, 0)
			for k in 3:
				_ball(rb, Vector3(randf_range(-0.04, 0.04), 0.02, randf_range(-0.06, 0.06)), 0.022, Color(0.75, 0.12, 0.1), Vector3(1, 0.3, 1))
		"stapler":
			_boxi(rb, Vector3.ZERO, Vector3(0.24, 0.06, 0.07), Color(0.12, 0.12, 0.14))
			_boxi(rb, Vector3(0, 0.05, 0), Vector3(0.22, 0.04, 0.06), Color(0.7, 0.1, 0.1))
		"tp":
			_cyl(rb, Vector3.ZERO, 0.07, 0.07, 0.12, Color(0.97, 0.97, 0.97))
			_cyl(rb, Vector3(0, 0.001, 0), 0.025, 0.025, 0.122, Color(0.6, 0.45, 0.3))
		"baguette":
			_ball(rb, Vector3.ZERO, 0.05, Color(0.85, 0.62, 0.3), Vector3(6.0, 1.0, 1.0))
		"file":
			_boxi(rb, Vector3.ZERO, Vector3(0.26, 0.03, 0.2), Color(0.93, 0.78, 0.45))
			_boxi(rb, Vector3(0, 0.018, 0), Vector3(0.24, 0.01, 0.18), Color(0.98, 0.98, 0.95))
	# petit halo pour le reperer
	var om := OmniLight3D.new()
	om.light_color = Color(1.0, 0.85, 0.4)
	om.light_energy = 1.2
	om.omni_range = 1.4
	rb.add_child(om)
	return rb


func _mat(c: Color) -> StandardMaterial3D:
	var m := StandardMaterial3D.new()
	m.albedo_color = c
	m.roughness = 0.5
	m.rim_enabled = true
	m.rim = 0.4
	return m


func _mesh(par: Node3D, mesh: Mesh, pos: Vector3, c: Color) -> MeshInstance3D:
	var mi := MeshInstance3D.new()
	mi.mesh = mesh
	mi.material_override = _mat(c)
	mi.position = pos
	par.add_child(mi)
	return mi


func _ball(par: Node3D, pos: Vector3, r: float, c: Color, sc := Vector3.ONE) -> MeshInstance3D:
	var sm := SphereMesh.new()
	sm.radius = r
	sm.height = r * 2.0
	var mi := _mesh(par, sm, pos, c)
	mi.scale = sc
	return mi


func _cyl(par: Node3D, pos: Vector3, rt: float, rb: float, h: float, c: Color) -> MeshInstance3D:
	var cm := CylinderMesh.new()
	cm.top_radius = rt
	cm.bottom_radius = rb
	cm.height = h
	return _mesh(par, cm, pos, c)


func _boxi(par: Node3D, pos: Vector3, sz: Vector3, c: Color) -> MeshInstance3D:
	var bm := BoxMesh.new()
	bm.size = sz
	return _mesh(par, bm, pos, c)


## Ramasse un objet tombe du ciel : les autres le voient disparaitre.
func picked(rb: RigidBody3D) -> void:
	if rb.has_meta("rid"):
		var rid := int(rb.get_meta("rid"))
		drops.erase(rid)
		if Net.active:
			main.sync.bcast(&"action", ["dlv_taken", rid])
