extends Node
## Synchronisation en partie (enfant de Main, nom "NetSync" : meme chemin chez tous).
## L'hote envoie l'etat de la journee ; chaque joueur envoie sa position,
## ses appels (pour les ecrans des autres) et ses actions qui touchent l'equipe.

var main: Node
var send_t := 0.0
var pose_t := 0.0


func _ready() -> void:
	Net.scene_loaded.call_deferred()


## envoie a tous les joueurs dont le bureau est charge
func bcast(method: StringName, args := []) -> void:
	var me := multiplayer.get_unique_id()
	for id in Net.ready_peers:
		if int(id) != me:
			callv("rpc_id", [int(id), method] + args)


## envoie a l'hote (s'il est pret)
func to_host(method: StringName, args := []) -> void:
	if Net.ready_peers.has(1):
		callv("rpc_id", [1, method] + args)


func _process(dt: float) -> void:
	if not Net.active or main == null:
		return
	pose_t += dt
	if pose_t >= 0.08:
		pose_t = 0.0
		bcast(&"pose", [main.net_my_pose()])
	if multiplayer.is_server():
		send_t += dt
		if send_t >= 0.2:
			send_t = 0.0
			bcast(&"state", [main.net_state()])


# ------------------------------------------------------------- hote -> tous

@rpc("authority", "unreliable_ordered")
func state(st: Dictionary) -> void:
	main.net_apply_state(st)


@rpc("authority", "reliable")
func god(text: String) -> void:
	main._god(text)


@rpc("authority", "reliable")
func fx_event(kind: String, data: Variant) -> void:
	main.net_fx_event(kind, data)


@rpc("authority", "reliable")
func start_shift() -> void:
	main._on_start_shift()


@rpc("authority", "reliable")
func end_shift(info: Dictionary) -> void:
	main.net_end_shift(info)


@rpc("authority", "reliable")
func next_day(info: Dictionary) -> void:
	main.net_next_day(info)


@rpc("authority", "reliable")
func again(seed_in: int) -> void:
	main.net_again(seed_in)


# ------------------------------------------------------------- joueur -> hote

@rpc("any_peer", "reliable")
func add_expo(v: float) -> void:
	if multiplayer.is_server():
		main._add_expo(v)


@rpc("any_peer", "reliable")
func conversion(data: Dictionary) -> void:
	if multiplayer.is_server():
		main.net_conversion(data, multiplayer.get_remote_sender_id())


@rpc("any_peer", "reliable")
func stat(key: String, n: int) -> void:
	if multiplayer.is_server():
		main._stat(key, n)


@rpc("any_peer", "reliable")
func money(v: int) -> void:
	if multiplayer.is_server():
		main._money(v)


@rpc("any_peer", "reliable")
func coffee(sugar: int, milk: bool, big: bool) -> void:
	if multiplayer.is_server():
		main._coffee_delivered(sugar, milk, big, multiplayer.get_remote_sender_id())


@rpc("any_peer", "reliable")
func buy(id: String) -> void:
	if multiplayer.is_server():
		Game.buy(id)


@rpc("any_peer", "reliable")
func rule_broken(why: String) -> void:
	if multiplayer.is_server():
		main._break_rule(why, multiplayer.get_remote_sender_id())


# ------------------------------------------------------------- tous -> tous

@rpc("any_peer", "unreliable_ordered")
func pose(p: Dictionary) -> void:
	main.net_pose(multiplayer.get_remote_sender_id(), p)


@rpc("any_peer", "reliable")
func call_event(kind: String, data: Variant) -> void:
	main.net_call_event(multiplayer.get_remote_sender_id(), kind, data)


@rpc("any_peer", "reliable")
func emote(id: String) -> void:
	main.net_emote(multiplayer.get_remote_sender_id(), id)


@rpc("any_peer", "reliable")
func action(kind: String, data: Variant) -> void:
	main.net_action(multiplayer.get_remote_sender_id(), kind, data)


@rpc("any_peer", "unreliable")
func voice(frame: PackedByteArray, level: float) -> void:
	main.net_voice(multiplayer.get_remote_sender_id(), frame, level)
