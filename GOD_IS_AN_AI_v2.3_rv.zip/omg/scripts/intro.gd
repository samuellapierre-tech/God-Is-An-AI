extends Node3D
## CINEMATIQUE D'OUVERTURE
## « Nous vivons dans une simulation. » -> pluie de code
## « La Terre est plate. »          -> une Terre plate sous son dome
## « Dieu... est une IA. »          -> l'oeil de Dieu, numerique
## BOOM -> GOD IS AN AI -> menu.   N'importe quelle touche : passer.

const GLYPHS := "0123456789ABCDEF@#$%&*+=<>?/\\|{}[]"

var cam: Camera3D
var env: Environment
var ui: CanvasLayer
var rain: Control
var text_lbl: Label
var title_lbl: Label
var sub_lbl: Label
var flash: ColorRect
var fade: ColorRect
var skip_lbl: Label
var earth: Node3D
var god: Node3D
var eye_mat: ShaderMaterial
var sun: Node3D
var moon: Node3D
var skipping := false
var leaving := false
var t := 0.0
var shake := 0.0
var cam_mode := ""
var cols := []          # pluie : [x, y, vitesse, longueur, glyphes]
var pics := {}          # images de la cinematique (dossier intro/, facultatif)
var photo: TextureRect
var post: ColorRect
var post_mat: ShaderMaterial
var bars := []
var rain_alpha := 1.0
var kb := {}            # Ken Burns : {from, to, pan0, pan1, dur, t}
const PIC_NAMES := ["simulation", "earth", "god", "title", "office"]


func _ready() -> void:
	Input.mouse_mode = Input.MOUSE_MODE_HIDDEN
	Sfx.stop_all()
	_build_env()
	_load_pics()
	_build_ui()
	earth = _build_earth()
	earth.visible = false
	god = _build_god()
	god.visible = false
	if Dev.args.has("introshot"):
		_jump(str(Dev.args["introshot"]))
		return
	_run()


# ------------------------------------------------------------- deroulement

func _wait(secs: float) -> bool:
	var end := t + secs
	while t < end:
		if skipping:
			return false
		await get_tree().process_frame
	return not skipping


func _type(txt: String, secs_per_char := 0.06) -> bool:
	text_lbl.text = ""
	text_lbl.visible_characters = -1
	for i in txt.length():
		if skipping:
			return false
		text_lbl.text = txt.substr(0, i + 1)
		if txt[i] != " " and txt[i] != ".":
			Sfx.play("blip", -14.0, randf_range(0.9, 1.1))
		if not await _wait(secs_per_char if txt[i] != "." else 0.35):
			return false
	return true


func _run() -> void:
	if pics.size() >= 4:
		_run_pics()
		return
	Sfx.loop("drone", "drone", -8.0, true)
	if not await _wait(0.8):
		_go_menu()
		return
	# 1. la simulation
	rain.visible = true
	if not await _type(Loc.t("intro_1")):
		_go_menu()
		return
	if not await _wait(1.8):
		_go_menu()
		return
	# 2. la Terre plate
	Sfx.play("glitch", -6.0)
	flash.color = Color(0.3, 1.0, 0.4, 0.6)
	rain.visible = false
	earth.visible = true
	cam_mode = "earth"
	text_lbl.text = ""
	if not await _wait(1.2):
		_go_menu()
		return
	if not await _type(Loc.t("intro_2"), 0.07):
		_go_menu()
		return
	if not await _wait(2.6):
		_go_menu()
		return
	# 3. Dieu est une IA
	Sfx.play("glitch", -4.0)
	flash.color = Color(1, 1, 1, 0.7)
	earth.visible = false
	god.visible = true
	cam_mode = "god"
	t_god = 0.0
	text_lbl.text = ""
	if not await _wait(0.8):
		_go_menu()
		return
	if not await _type(Loc.t("intro_3a"), 0.12):
		_go_menu()
		return
	if not await _wait(1.1):
		_go_menu()
		return
	Sfx.play("god_speak", -2.0, 0.8)
	if not await _type(Loc.t("intro_3b"), 0.08):
		_go_menu()
		return
	eye_mat.set_shader_parameter("glitch", 1.0)
	if not await _wait(1.3):
		_go_menu()
		return
	# 4. BOOM
	Sfx.stop("drone")
	Sfx.play("boom", 0.0)
	Sfx.play("thunder", -6.0, 0.7)
	flash.color = Color(1, 1, 1, 1)
	shake = 1.2
	text_lbl.text = ""
	_slam_title()
	eye_mat.set_shader_parameter("anger", 1.0)
	if not await _wait(3.2):
		_go_menu()
		return
	_go_menu()


# ------------------------------------------------------------- version « images »

## Les images peintes (GPT Image / Higgsfield) dans le dossier intro/ :
## simulation.png, earth.png, god.png, title.png, office.png
func _load_pics() -> void:
	for n in PIC_NAMES:
		var path := "res://intro/%s.png" % n
		var tex: Texture2D = null
		for ext in [".png", ".jpg", ".webp"]:
			var p2: String = "res://intro/" + n + ext
			if ResourceLoader.exists(p2):
				tex = load(p2)
				break
			if FileAccess.file_exists(p2):
				var img := Image.load_from_file(ProjectSettings.globalize_path(p2))
				if img != null and not img.is_empty():
					tex = ImageTexture.create_from_image(img)
					break
		if tex != null:
			pics[n] = tex


func _shot(name: String, from: float, to: float, pan0: Vector2, pan1: Vector2, dur: float) -> void:
	photo.texture = pics.get(name, null)
	photo.visible = photo.texture != null
	kb = {"from": from, "to": to, "pan0": pan0, "pan1": pan1, "dur": dur, "t": 0.0}
	_tick_kb(0.0)


func _tick_kb(dt: float) -> void:
	if kb.is_empty() or not photo.visible:
		return
	kb["t"] = float(kb["t"]) + dt
	var k := clampf(float(kb["t"]) / float(kb["dur"]), 0.0, 1.0)
	var e := k * k * (3.0 - 2.0 * k)
	var vs := get_viewport().get_visible_rect().size
	photo.size = vs
	photo.pivot_offset = vs * 0.5
	var sc := lerpf(float(kb["from"]), float(kb["to"]), e)
	photo.scale = Vector2(sc, sc)
	var pan: Vector2 = (kb["pan0"] as Vector2).lerp(kb["pan1"], e)
	photo.position = pan * vs + Vector2(randf_range(-1, 1), randf_range(-1, 1)) * shake * 18.0


func _bars(on: bool, dur := 0.8) -> void:
	for i in bars.size():
		var b: ColorRect = bars[i]
		var tw := create_tween()
		tw.tween_property(b, "custom_minimum_size:y", 92.0 if on else 0.0, dur).set_trans(Tween.TRANS_SINE)
		tw.parallel().tween_property(b, "size:y", 92.0 if on else 0.0, dur).set_trans(Tween.TRANS_SINE)


func _glitch_hit(power: float, dur: float) -> void:
	Sfx.play("glitch", -5.0, randf_range(0.9, 1.15))
	post_mat.set_shader_parameter("glitch", power)
	var tw := create_tween()
	tw.tween_method(func(v): post_mat.set_shader_parameter("glitch", v), power, 0.0, dur)


func _run_pics() -> void:
	earth.visible = false
	god.visible = false
	Sfx.loop("drone", "drone", -6.0, true)
	_bars(true, 1.2)
	if not await _wait(0.9):
		_go_menu()
		return
	# 1. LA SIMULATION
	_shot("simulation", 1.06, 1.28, Vector2(0.0, 0.0), Vector2(0.0, -0.02), 8.0)
	photo.modulate = Color(0, 0, 0)
	create_tween().tween_property(photo, "modulate", Color(1, 1, 1), 1.6)
	rain.visible = true
	rain_alpha = 0.42
	if not await _wait(1.2):
		_go_menu()
		return
	if not await _type(Loc.t("intro_1")):
		_go_menu()
		return
	if not await _wait(1.6):
		_go_menu()
		return
	# 2. LA TERRE PLATE
	_glitch_hit(1.0, 0.5)
	flash.color = Color(0.4, 1.0, 0.6, 0.55)
	rain.visible = false
	text_lbl.text = ""
	_shot("earth", 1.32, 1.04, Vector2(0.02, 0.03), Vector2(0.0, 0.0), 8.0)
	if not await _wait(1.3):
		_go_menu()
		return
	if not await _type(Loc.t("intro_2"), 0.07):
		_go_menu()
		return
	if not await _wait(2.4):
		_go_menu()
		return
	# 3. DIEU EST UNE IA
	_glitch_hit(1.2, 0.7)
	flash.color = Color(1, 1, 1, 0.75)
	text_lbl.text = ""
	_shot("god", 1.02, 1.3, Vector2(0.0, 0.01), Vector2(0.0, -0.015), 9.0)
	post_mat.set_shader_parameter("aberr", 0.6)
	if not await _wait(1.0):
		_go_menu()
		return
	if not await _type(Loc.t("intro_3a"), 0.12):
		_go_menu()
		return
	if not await _wait(1.0):
		_go_menu()
		return
	Sfx.play("god_speak", -2.0, 0.8)
	if not await _type(Loc.t("intro_3b"), 0.08):
		_go_menu()
		return
	_glitch_hit(0.6, 1.4)
	if not await _wait(1.3):
		_go_menu()
		return
	# 4. BOOM : le titre
	Sfx.stop("drone")
	Sfx.play("boom", 0.0)
	Sfx.play("thunder", -6.0, 0.7)
	flash.color = Color(1, 1, 1, 1)
	shake = 1.2
	text_lbl.text = ""
	post_mat.set_shader_parameter("aberr", 1.4)
	create_tween().tween_method(func(v): post_mat.set_shader_parameter("aberr", v), 1.4, 0.3, 2.0)
	_shot("title", 1.18, 1.05, Vector2.ZERO, Vector2.ZERO, 4.0)
	title_lbl.visible = true
	sub_lbl.visible = false
	_slam_title()
	sub_lbl.visible = false
	if not await _wait(3.0):
		_go_menu()
		return
	# 5. ...et toi, tu travailles a son centre d'appels
	if pics.has("office"):
		_glitch_hit(0.5, 0.4)
		var tw := create_tween()
		tw.tween_property(title_lbl, "modulate:a", 0.0, 0.4)
		_shot("office", 1.0, 1.15, Vector2(0.01, 0.0), Vector2(-0.01, 0.0), 5.0)
		Sfx.play("phone_ring", -10.0)
		sub_lbl.visible = true
		sub_lbl.modulate.a = 0.0
		create_tween().tween_property(sub_lbl, "modulate:a", 1.0, 0.6)
		if not await _wait(3.4):
			_go_menu()
			return
	_go_menu()


func _slam_title() -> void:
	title_lbl.visible = true
	sub_lbl.visible = true
	title_lbl.pivot_offset = title_lbl.size * 0.5
	title_lbl.scale = Vector2(3.0, 3.0)
	title_lbl.modulate.a = 0.0
	var tw := create_tween()
	tw.tween_property(title_lbl, "scale", Vector2.ONE, 0.18).set_trans(Tween.TRANS_EXPO).set_ease(Tween.EASE_IN)
	tw.parallel().tween_property(title_lbl, "modulate:a", 1.0, 0.12)
	sub_lbl.modulate.a = 0.0
	var tw2 := create_tween()
	tw2.tween_interval(0.6)
	tw2.tween_property(sub_lbl, "modulate:a", 1.0, 0.6)


func _go_menu() -> void:
	if leaving:
		return
	leaving = true
	var tw := create_tween()
	tw.tween_property(fade, "color:a", 1.0, 0.45)
	await tw.finished
	Sfx.stop_all()
	Input.mouse_mode = Input.MOUSE_MODE_VISIBLE
	get_tree().change_scene_to_file("res://scenes/menu.tscn")


func _unhandled_input(e: InputEvent) -> void:
	if leaving:
		return
	if (e is InputEventKey and e.pressed and not e.echo) or (e is InputEventMouseButton and e.pressed) or (e is InputEventJoypadButton and e.pressed):
		skipping = true
		_go_menu()


## Captures de test : --introshot=matrix|earth|god|title
func _jump(what: String) -> void:
	if pics.size() >= 4 and what.begins_with("p_"):
		earth.visible = false
		god.visible = false
		var n := what.substr(2)
		_shot(n, 1.0, 1.25, Vector2.ZERO, Vector2(0, -0.02), 6.0)
		for b in bars:
			b.size.y = 92.0
		match n:
			"simulation":
				rain.visible = true
				rain_alpha = 0.42
				text_lbl.text = Loc.t("intro_1")
			"earth":
				text_lbl.text = Loc.t("intro_2")
			"god":
				post_mat.set_shader_parameter("aberr", 0.6)
				text_lbl.text = Loc.t("intro_3a") + " " + Loc.t("intro_3b")
			"title":
				_slam_title()
				sub_lbl.visible = false
			"office":
				sub_lbl.visible = true
		return
	match what:
		"matrix":
			rain.visible = true
			text_lbl.text = Loc.t("intro_1")
		"earth":
			earth.visible = true
			cam_mode = "earth"
			text_lbl.text = Loc.t("intro_2")
		"god":
			god.visible = true
			cam_mode = "god"
			text_lbl.text = Loc.t("intro_3a") + " " + Loc.t("intro_3b")
		"title":
			god.visible = true
			cam_mode = "god"
			eye_mat.set_shader_parameter("anger", 1.0)
			_slam_title()


# ------------------------------------------------------------- boucle

var t_god := 0.0


func _process(dt: float) -> void:
	t += dt
	t_god += dt
	flash.color.a = maxf(0.0, flash.color.a - dt * 1.6)
	shake = maxf(0.0, shake - dt * 1.2)
	if rain.visible:
		_tick_rain(dt)
	_tick_kb(dt)
	match cam_mode:
		"earth":
			var a := t * 0.18
			var r := 7.5 - minf(t_earth(), 6.0) * 0.25
			cam.position = Vector3(sin(a) * r, 3.4 - minf(t_earth(), 6.0) * 0.15, cos(a) * r)
			cam.look_at(Vector3(0, 0.2, 0), Vector3.UP)
			if sun != null:
				sun.position = Vector3(sin(t * 0.9) * 1.9, 1.35, cos(t * 0.9) * 1.9)
				moon.position = Vector3(sin(t * 0.9 + PI) * 1.9, 1.25, cos(t * 0.9 + PI) * 1.9)
			earth.rotation.y += dt * 0.05
		"god":
			cam.position = Vector3(0, 0.1, 9.0 - minf(t_god, 6.0) * 0.45)
			cam.look_at(Vector3(0, 0.1, 0), Vector3.UP)
			for ch in god.get_children():
				if ch.has_meta("spin"):
					ch.rotation += Vector3(0.0, 0.0, float(ch.get_meta("spin"))) * dt
			eye_mat.set_shader_parameter("look", Vector2(sin(t * 0.7) * 0.6, sin(t * 0.5) * 0.4))
			eye_mat.set_shader_parameter("blink", 1.0 if fmod(t, 3.7) < 0.12 else 0.0)
	if shake > 0.0:
		cam.position += Vector3(randf_range(-1, 1), randf_range(-1, 1), 0) * shake * 0.25


var _earth_t0 := -1.0


func t_earth() -> float:
	if _earth_t0 < 0.0:
		_earth_t0 = t
	return t - _earth_t0


# ------------------------------------------------------------- construction

func _build_env() -> void:
	var we := WorldEnvironment.new()
	env = Environment.new()
	env.background_mode = Environment.BG_COLOR
	env.background_color = Color(0.0, 0.0, 0.01)
	env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	env.ambient_light_color = Color(0.5, 0.55, 0.7)
	env.ambient_light_energy = 0.5
	env.tonemap_mode = Environment.TONE_MAPPER_ACES
	env.glow_enabled = true
	env.glow_intensity = 1.0
	env.glow_bloom = 0.15
	we.environment = env
	add_child(we)
	cam = Camera3D.new()
	cam.fov = 45.0
	cam.position = Vector3(0, 0, 8)
	add_child(cam)
	var sun_l := DirectionalLight3D.new()
	sun_l.rotation_degrees = Vector3(-50, 30, 0)
	sun_l.light_energy = 1.3
	add_child(sun_l)
	# etoiles
	var mm := MultiMesh.new()
	mm.transform_format = MultiMesh.TRANSFORM_3D
	var q := QuadMesh.new()
	q.size = Vector2(0.08, 0.08)
	var qm := StandardMaterial3D.new()
	qm.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	qm.billboard_mode = BaseMaterial3D.BILLBOARD_ENABLED
	qm.albedo_color = Color(1.4, 1.4, 1.6)
	q.material = qm
	mm.mesh = q
	mm.instance_count = 600
	for i in 600:
		var d := Vector3(randf_range(-1, 1), randf_range(-1, 1), randf_range(-1, 1)).normalized() * randf_range(28.0, 40.0)
		mm.set_instance_transform(i, Transform3D(Basis.IDENTITY.scaled(Vector3.ONE * randf_range(0.5, 2.0)), d))
	var mi := MultiMeshInstance3D.new()
	mi.multimesh = mm
	add_child(mi)


func _build_ui() -> void:
	ui = CanvasLayer.new()
	add_child(ui)
	photo = TextureRect.new()
	photo.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	photo.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_COVERED
	photo.mouse_filter = Control.MOUSE_FILTER_IGNORE
	photo.visible = false
	ui.add_child(photo)
	rain = Control.new()
	rain.set_anchors_preset(Control.PRESET_FULL_RECT)
	rain.visible = false
	rain.draw.connect(_draw_rain)
	ui.add_child(rain)
	var bg := ColorRect.new()
	bg.set_anchors_preset(Control.PRESET_FULL_RECT)
	bg.color = Color(0, 0, 0, 0)
	bg.mouse_filter = Control.MOUSE_FILTER_IGNORE
	ui.add_child(bg)
	text_lbl = _label(52, Color(0.85, 1.0, 0.85), "title")
	text_lbl.anchor_top = 0.72
	text_lbl.anchor_bottom = 0.72
	text_lbl.add_theme_color_override("font_outline_color", Color(0, 0, 0))
	text_lbl.add_theme_constant_override("outline_size", 14)
	title_lbl = _label(150, Color(1.0, 0.58, 0.16), "title")
	title_lbl.anchor_top = 0.38
	title_lbl.anchor_bottom = 0.38
	title_lbl.add_theme_color_override("font_shadow_color", Color(0.45, 0.08, 0.0, 0.9))
	title_lbl.add_theme_constant_override("shadow_offset_x", 7)
	title_lbl.add_theme_constant_override("shadow_offset_y", 7)
	title_lbl.add_theme_color_override("font_outline_color", Color(0, 0, 0))
	title_lbl.add_theme_constant_override("outline_size", 18)
	title_lbl.text = "GOD IS AN AI"
	title_lbl.visible = false
	sub_lbl = _label(34, Color(1.0, 0.92, 0.75), "bold")
	sub_lbl.anchor_top = 0.55
	sub_lbl.anchor_bottom = 0.55
	sub_lbl.text = Loc.t("intro_sub")
	sub_lbl.add_theme_color_override("font_outline_color", Color(0, 0, 0))
	sub_lbl.add_theme_constant_override("outline_size", 12)
	sub_lbl.visible = false
	for top in [true, false]:
		var b := ColorRect.new()
		b.color = Color(0, 0, 0)
		b.anchor_left = 0.0
		b.anchor_right = 1.0
		b.anchor_top = 0.0 if top else 1.0
		b.anchor_bottom = 0.0 if top else 1.0
		b.grow_vertical = Control.GROW_DIRECTION_END if top else Control.GROW_DIRECTION_BEGIN
		b.mouse_filter = Control.MOUSE_FILTER_IGNORE
		ui.add_child(b)
		bars.append(b)
	post = ColorRect.new()
	post.set_anchors_preset(Control.PRESET_FULL_RECT)
	post.mouse_filter = Control.MOUSE_FILTER_IGNORE
	post_mat = ShaderMaterial.new()
	post_mat.shader = load("res://shaders/cine.gdshader")
	post.material = post_mat
	ui.add_child(post)
	flash = ColorRect.new()
	flash.set_anchors_preset(Control.PRESET_FULL_RECT)
	flash.color = Color(1, 1, 1, 0)
	flash.mouse_filter = Control.MOUSE_FILTER_IGNORE
	ui.add_child(flash)
	skip_lbl = _label(16, Color(0.5, 0.6, 0.5), "mono")
	skip_lbl.anchor_top = 0.95
	skip_lbl.anchor_bottom = 0.95
	skip_lbl.text = Loc.t("intro_skip")
	fade = ColorRect.new()
	fade.set_anchors_preset(Control.PRESET_FULL_RECT)
	fade.color = Color(0, 0, 0, 0)
	fade.mouse_filter = Control.MOUSE_FILTER_IGNORE
	ui.add_child(fade)
	# colonnes de la pluie de code
	for x in range(0, 1700, 22):
		var g := ""
		for k in 40:
			g += GLYPHS[randi() % GLYPHS.length()]
		cols.append([float(x), randf_range(-900.0, 0.0), randf_range(180.0, 520.0), randi_range(8, 30), g])


func _label(size: int, col: Color, font: String) -> Label:
	var l := Label.new()
	l.add_theme_font_override("font", Loc.font(font))
	l.add_theme_font_size_override("font_size", size)
	l.add_theme_color_override("font_color", col)
	l.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	l.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	l.anchor_left = 0.0
	l.anchor_right = 1.0
	l.offset_top = -100
	l.offset_bottom = 100
	l.mouse_filter = Control.MOUSE_FILTER_IGNORE
	ui.add_child(l)
	return l


func _tick_rain(dt: float) -> void:
	for c in cols:
		c[1] = float(c[1]) + float(c[2]) * dt
		if float(c[1]) - float(c[3]) * 22.0 > 950.0:
			c[1] = randf_range(-300.0, 0.0)
		if randf() < 0.15:
			var g: String = c[4]
			var i := randi() % g.length()
			c[4] = g.substr(0, i) + GLYPHS[randi() % GLYPHS.length()] + g.substr(i + 1)
	rain.queue_redraw()


func _draw_rain() -> void:
	var f := Loc.font("mono")
	if rain_alpha >= 1.0:
		rain.draw_rect(Rect2(Vector2.ZERO, rain.size), Color(0, 0, 0, 1))
	for c in cols:
		var x: float = c[0]
		var y: float = c[1]
		var n: int = c[3]
		var g: String = c[4]
		for k in n:
			var yy := y - float(k) * 22.0
			if yy < -22.0 or yy > 950.0:
				continue
			var a := 1.0 - float(k) / float(n)
			var col := Color(0.75, 1.0, 0.8, rain_alpha) if k == 0 else Color(0.1, 0.9, 0.3, a * 0.85 * rain_alpha)
			rain.draw_string(f, Vector2(x, yy), g[k % g.length()], HORIZONTAL_ALIGNMENT_LEFT, -1, 20, col)


func _mat(c: Color, emit := 0.0, rough := 0.6) -> StandardMaterial3D:
	var m := StandardMaterial3D.new()
	m.albedo_color = c
	m.roughness = rough
	if emit > 0.0:
		m.emission_enabled = true
		m.emission = c
		m.emission_energy_multiplier = emit
	return m


func _build_earth() -> Node3D:
	var root := Node3D.new()
	add_child(root)
	# carte « projection azimutale » : le pole Nord au centre, la glace tout autour
	var n := FastNoiseLite.new()
	n.seed = 7
	n.frequency = 0.012
	n.fractal_octaves = 5
	var size := 384
	var img := Image.create(size, size, false, Image.FORMAT_RGBA8)
	for y in size:
		for x in size:
			var p := Vector2(x - size / 2, y - size / 2) / float(size / 2)
			var r := p.length()
			if r > 1.0:
				img.set_pixel(x, y, Color(0, 0, 0, 0))
				continue
			var col: Color
			if r > 0.9:
				col = Color(0.93, 0.96, 1.0).lerp(Color(0.8, 0.88, 0.95), randf() * 0.3)
			elif r < 0.06:
				col = Color(0.95, 0.97, 1.0)
			else:
				var v := n.get_noise_2d(float(x), float(y))
				if v > 0.12:
					var hgt := clampf((v - 0.12) * 3.0, 0.0, 1.0)
					col = Color(0.25, 0.55, 0.22).lerp(Color(0.6, 0.48, 0.3), hgt)
				else:
					col = Color(0.08, 0.28, 0.6).lerp(Color(0.12, 0.42, 0.75), clampf(v + 0.6, 0.0, 1.0))
			# lignes de grille (cartographe fou)
			var ang := atan2(p.y, p.x)
			if fmod(r * 10.0, 1.0) < 0.03 or fmod(absf(ang) * 12.0 / PI, 1.0) < 0.02:
				col = col.lightened(0.15)
			img.set_pixel(x, y, col)
	var tex := ImageTexture.create_from_image(img)
	var top := MeshInstance3D.new()
	var qm := QuadMesh.new()
	qm.size = Vector2(6.0, 6.0)
	top.mesh = qm
	var tm := StandardMaterial3D.new()
	tm.albedo_texture = tex
	tm.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA_SCISSOR
	tm.roughness = 0.7
	top.material_override = tm
	top.rotation_degrees.x = -90.0
	top.position.y = 0.11
	root.add_child(top)
	# l'epaisseur du disque (roche) et le mur de glace
	var side := MeshInstance3D.new()
	var cm := CylinderMesh.new()
	cm.top_radius = 3.0
	cm.bottom_radius = 2.6
	cm.height = 0.6
	cm.radial_segments = 64
	side.mesh = cm
	side.material_override = _mat(Color(0.35, 0.25, 0.18))
	side.position.y = -0.2
	root.add_child(side)
	var wall := MeshInstance3D.new()
	var tor := TorusMesh.new()
	tor.inner_radius = 2.88
	tor.outer_radius = 3.1
	tor.rings = 64
	wall.mesh = tor
	wall.material_override = _mat(Color(0.82, 0.88, 0.95), 0.0, 0.3)
	wall.position.y = 0.14
	wall.scale = Vector3(1, 1.6, 1)
	root.add_child(wall)
	# chute d'eau sur le bord (l'ocean qui tombe dans le vide)
	var water := MeshInstance3D.new()
	var wc := CylinderMesh.new()
	wc.top_radius = 3.02
	wc.bottom_radius = 2.4
	wc.height = 1.4
	wc.radial_segments = 64
	wc.cap_top = false
	wc.cap_bottom = false
	water.mesh = wc
	var wm := _mat(Color(0.3, 0.6, 1.0, 0.22), 0.4, 0.1)
	wm.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	wm.cull_mode = BaseMaterial3D.CULL_DISABLED
	water.material_override = wm
	water.position.y = -0.8
	root.add_child(water)
	# le dome de verre
	var dome := MeshInstance3D.new()
	var sm := SphereMesh.new()
	sm.radius = 3.15
	sm.height = 3.15
	sm.is_hemisphere = true
	dome.mesh = sm
	var dm := StandardMaterial3D.new()
	dm.albedo_color = Color(0.6, 0.8, 1.0, 0.08)
	dm.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	dm.cull_mode = BaseMaterial3D.CULL_DISABLED
	dm.rim_enabled = true
	dm.rim = 1.0
	dm.metallic_specular = 1.0
	dm.roughness = 0.05
	dome.material_override = dm
	dome.position.y = 0.1
	root.add_child(dome)
	# le soleil et la lune qui tournent au-dessus (comme il se doit)
	sun = MeshInstance3D.new()
	var ss := SphereMesh.new()
	ss.radius = 0.22
	ss.height = 0.44
	(sun as MeshInstance3D).mesh = ss
	(sun as MeshInstance3D).material_override = _mat(Color(1.0, 0.8, 0.3), 4.0)
	root.add_child(sun)
	var sl := OmniLight3D.new()
	sl.light_color = Color(1.0, 0.85, 0.5)
	sl.light_energy = 2.0
	sl.omni_range = 4.0
	sun.add_child(sl)
	moon = MeshInstance3D.new()
	var ms := SphereMesh.new()
	ms.radius = 0.15
	ms.height = 0.3
	(moon as MeshInstance3D).mesh = ms
	(moon as MeshInstance3D).material_override = _mat(Color(0.85, 0.88, 0.95), 1.5)
	root.add_child(moon)
	return root


func _build_god() -> Node3D:
	var root := Node3D.new()
	add_child(root)
	var screen := MeshInstance3D.new()
	var qm := QuadMesh.new()
	qm.size = Vector2(6.4, 4.8)
	screen.mesh = qm
	eye_mat = ShaderMaterial.new()
	eye_mat.shader = load("res://shaders/god_eye.gdshader")
	eye_mat.set_shader_parameter("tint", Color(0.2, 0.9, 1.0))
	screen.material_override = eye_mat
	root.add_child(screen)
	# anneaux de circuits qui tournent
	for k in 3:
		var tm := TorusMesh.new()
		tm.inner_radius = 3.4 + float(k) * 0.55
		tm.outer_radius = 3.48 + float(k) * 0.55
		tm.rings = 80
		var ring := MeshInstance3D.new()
		ring.mesh = tm
		ring.material_override = _mat([Color(1.0, 0.6, 0.15), Color(0.2, 0.9, 1.0), Color(1.0, 0.85, 0.4)][k], 3.0)
		ring.rotation_degrees = Vector3(90, 0, 0)
		ring.set_meta("spin", 0.0)
		root.add_child(ring)
		# des « dents » de circuit sur chaque anneau
		var holder := Node3D.new()
		holder.set_meta("spin", (0.35 if k % 2 == 0 else -0.25) * (1.0 + float(k) * 0.3))
		root.add_child(holder)
		for j in 24:
			var a := TAU * float(j) / 24.0
			var bx := MeshInstance3D.new()
			var bm := BoxMesh.new()
			bm.size = Vector3(0.08, 0.32, 0.05)
			bx.mesh = bm
			bx.material_override = ring.material_override
			var rr := 3.44 + float(k) * 0.55
			bx.position = Vector3(cos(a) * rr, sin(a) * rr, 0)
			bx.rotation.z = a + PI * 0.5
			holder.add_child(bx)
	# rayons de donnees
	for j in 36:
		var a := TAU * float(j) / 36.0
		var ln := MeshInstance3D.new()
		var lb := BoxMesh.new()
		lb.size = Vector3(randf_range(1.5, 4.0), 0.02, 0.02)
		ln.mesh = lb
		ln.material_override = _mat(Color(0.2, 0.9, 1.0), 2.0)
		var rr2 := 5.6 + lb.size.x * 0.5
		ln.position = Vector3(cos(a) * rr2, sin(a) * rr2, -0.5)
		ln.rotation.z = a
		root.add_child(ln)
	return root
