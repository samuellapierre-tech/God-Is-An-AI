extends Node
## Voix realistes (facultatif) pour les fideles, via une API de synthese vocale
## compatible OpenAI (/v1/audio/speech). Sans fichier cle_tts.txt : voix de
## Windows / macOS comme avant.
##
## cle_tts.txt (dans le dossier du projet ou user://) :
##   key=sk-...
##   url=https://api.openai.com/v1/audio/speech     (facultatif)
##   model=gpt-4o-mini-tts                          (facultatif)
##   voices=alloy,ash,ballad,coral,echo,fable,nova,onyx,sage,shimmer   (facultatif)
## Developpement seulement : ne jamais distribuer le jeu avec une cle dedans.

const PERS_STYLE := {
	"anxious": "very anxious, breathless, talks fast",
	"angry": "irritated, grumpy, slightly shouting",
	"pious": "solemn, overly reverent, whispering like in church",
	"skeptic": "doubtful, sarcastic",
	"chatty": "extremely talkative, enthusiastic, fast",
	"shy": "very shy, quiet, hesitant",
	"lawyer": "formal, precise, like a lawyer in court",
	"naive": "naive, cheerful, amazed by everything",
	"kid": "a young child, excited",
}

var key := ""
var url := "https://api.openai.com/v1/audio/speech"
var model := "gpt-4o-mini-tts"
var voices := PackedStringArray(["alloy", "ash", "ballad", "coral", "echo", "fable", "nova", "onyx", "sage", "shimmer"])
var http: HTTPRequest
var player: AudioStreamPlayer
var failed := 0
var main: Node
var last_text := ""


func _ready() -> void:
	for p in ["res://cle_tts.txt", "user://cle_tts.txt"]:
		if not FileAccess.file_exists(p):
			continue
		for line in FileAccess.get_file_as_string(p).split("\n", false):
			var i := line.find("=")
			if i < 0:
				if line.strip_edges().begins_with("sk-"):
					key = line.strip_edges()
				continue
			var k := line.substr(0, i).strip_edges().to_lower()
			var v := line.substr(i + 1).strip_edges()
			match k:
				"key": key = v
				"url": url = v
				"model": model = v
				"voices": voices = v.replace(" ", "").split(",", false)
		if key != "":
			break
	http = HTTPRequest.new()
	http.timeout = 20.0
	add_child(http)
	http.request_completed.connect(_on_done)
	player = AudioStreamPlayer.new()
	add_child(player)
	pcm = HttpStream.new()
	pcm.timeout = 20.0
	add_child(pcm)
	pcm.chunk.connect(_on_pcm)
	pcm.finished.connect(_on_pcm_done)
	gen = AudioStreamGenerator.new()
	gen.mix_rate = PCM_RATE
	gen.buffer_length = 1.0


# ------------------------------------------------------------- voix en streaming (PCM)
# OpenAI renvoie de l'audio brut 16 bits / 24 kHz : on le joue des le premier
# morceau recu, au lieu d'attendre le fichier MP3 complet (~1 s de gagnee).

const HttpStream := preload("res://scripts/http_stream.gd")
const PCM_RATE := 24000.0
var pcm = null
var gen: AudioStreamGenerator
var pb: AudioStreamGeneratorPlayback = null
var pcm_rest := PackedByteArray()
var pcm_queue := PackedVector2Array()
var pcm_done := true
var pcm_t0 := 0
var pcm_total := 0
var lat_voice := 0      # ms entre la demande et le premier son


func _on_pcm(data: PackedByteArray) -> void:
	if pcm_total == 0:
		lat_voice = Time.get_ticks_msec() - pcm_t0
		player.stream = gen
		player.play()
		pb = player.get_stream_playback() as AudioStreamGeneratorPlayback
	pcm_rest.append_array(data)
	var n := pcm_rest.size() / 2
	var frames := PackedVector2Array()
	frames.resize(n)
	for i in n:
		var v := float(pcm_rest.decode_s16(i * 2)) / 32768.0
		frames[i] = Vector2(v, v)
	pcm_rest = pcm_rest.slice(n * 2)
	pcm_queue.append_array(frames)
	pcm_total += n
	_feed()


func _on_pcm_done(code: int, ok: bool) -> void:
	pcm_done = true
	if not ok or pcm_total < 2400:
		failed += 1
		fail_at = Time.get_ticks_msec()
		push_warning("Voix en ligne (flux) : erreur %d" % code)
		player.stop()
		if main != null and last_text != "":
			main._speak(last_text, false)
		return
	failed = 0
	print("LATENCE VOIX : premier son %d ms, %.1f s d'audio" % [lat_voice, float(pcm_total) / PCM_RATE])


func _feed() -> void:
	if pb == null or pcm_queue.is_empty():
		return
	var room := pb.get_frames_available()
	if room <= 0:
		return
	var n := mini(room, pcm_queue.size())
	pb.push_buffer(pcm_queue.slice(0, n))
	pcm_queue = pcm_queue.slice(n)


func _process(_dt: float) -> void:
	if pb != null:
		_feed()
		# fin de la replique : tout est joue
		if pcm_done and pcm_queue.is_empty() and player.playing and player.stream == gen:
			var played := (Time.get_ticks_msec() - pcm_t0 - lat_voice) / 1000.0
			if played > float(pcm_total) / PCM_RATE + 0.6:
				player.stop()
				pb = null


func _speak_stream(body: Dictionary) -> bool:
	body["response_format"] = "pcm"
	pcm.cancel()
	player.stop()
	pb = null
	pcm_rest = PackedByteArray()
	pcm_queue = PackedVector2Array()
	pcm_total = 0
	pcm_done = false
	pcm_t0 = Time.get_ticks_msec()
	if key != "":
		return pcm.start(url, PackedStringArray(["Content-Type: application/json", "Authorization: Bearer " + key]), JSON.stringify(body).to_utf8_buffer())
	body["player"] = Relay.player
	var js := JSON.stringify(body)
	return pcm.start(Relay.url + "/v1/tts", Relay.headers(js), js.to_utf8_buffer())


var fail_at := 0


func enabled() -> bool:
	if failed >= 3 and Time.get_ticks_msec() - fail_at > 120000:
		failed = 2        # la voix en ligne a lache il y a 2 min : on reessaie
	return (key != "" or Relay.enabled()) and failed < 3


## Vrai si la voix en ligne prend la replique (sinon : voix du systeme).
func speak(text: String, b: Dictionary) -> bool:
	if not enabled() or text.strip_edges() == "":
		return false
	http.cancel_request()
	last_text = text
	var seed_v := int(b.get("look_seed", 7))
	var voice := voices[absi(seed_v) % voices.size()]
	var style := str(PERS_STYLE.get(str(b.get("pers", "")), "emotional"))
	var lang_hint := "Speak in Quebec French (joual accent)." if Loc.lang == "fr" else "Speak in English."
	var body := {
		"model": model,
		"input": text.substr(0, 600),
		"voice": voice,
		"response_format": "mp3",
		"instructions": "%s You are a guilty person praying to God on the phone. Tone : %s. Comedic, expressive." % [lang_hint, style],
	}
	if Loc.ai_stream and _speak_stream(body.duplicate()):
		return true
	var err: int
	if key != "":
		err = http.request(url, ["Content-Type: application/json", "Authorization: Bearer " + key],
			HTTPClient.METHOD_POST, JSON.stringify(body))
	else:
		body["player"] = Relay.player
		var js := JSON.stringify(body)
		err = http.request(Relay.url + "/v1/tts", Relay.headers(js), HTTPClient.METHOD_POST, js)
	return err == OK


func _on_done(_r: int, code: int, _h: PackedStringArray, bytes: PackedByteArray) -> void:
	if code != 200 or bytes.size() < 200:
		failed += 1
		fail_at = Time.get_ticks_msec()
		push_warning("Voix en ligne : erreur %d" % code)
		if main != null and last_text != "":
			main._speak(last_text, false)
		return
	failed = 0
	var s := AudioStreamMP3.new()
	s.data = bytes
	player.stream = s
	player.play()
	if Dev.args.has("autoplay"):
		print("TTS joue ", bytes.size(), " octets, duree ", s.get_length())


func stop() -> void:
	http.cancel_request()
	if pcm != null:
		pcm.cancel()
	pb = null
	player.stop()
