extends PanelContainer
## Ecran d'OPTIONS (menu principal et pause) : son, video, controles, micro.

signal closed

const ORANGE := Color(1.0, 0.55, 0.16)
const DIM := Color(0.62, 0.34, 0.12)
const PALE := Color(1.0, 0.86, 0.66)

var rows := {}          # id -> Control (pour rafraichir le texte)
var first: Control = null


func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	var sb := StyleBoxFlat.new()
	sb.bg_color = Color(0.03, 0.02, 0.015, 0.97)
	sb.border_color = ORANGE
	sb.set_border_width_all(2)
	sb.set_content_margin_all(22)
	add_theme_stylebox_override("panel", sb)
	set_anchors_preset(Control.PRESET_CENTER)
	custom_minimum_size = Vector2(900, 780)
	offset_left = -450
	offset_right = 450
	offset_top = -390
	offset_bottom = 390
	_build()


func _build() -> void:
	rows = {}
	first = null
	var v := VBoxContainer.new()
	v.add_theme_constant_override("separation", 8)
	add_child(v)
	var t := _lbl(v, Loc.t("opt_title"), 44, ORANGE, "title")
	t.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	var sc := ScrollContainer.new()
	sc.size_flags_vertical = Control.SIZE_EXPAND_FILL
	sc.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	v.add_child(sc)
	var g := GridContainer.new()
	g.columns = 2
	g.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	g.add_theme_constant_override("h_separation", 24)
	g.add_theme_constant_override("v_separation", 8)
	sc.add_child(g)

	_head(g, Loc.t("opt_sec_sound"))
	_slider(g, "vol_master", 0, 100, 5)
	_slider(g, "vol_music", 0, 100, 5)
	_slider(g, "vol_voice", 0, 100, 5)
	_cycle(g, "voice_mode")
	_cycle(g, "echoes")
	_cycle(g, "echo_listen")
	_cycle(g, "ai_stream")
	_head(g, Loc.t("opt_sec_video"))
	_cycle(g, "lang")
	_cycle(g, "quality")
	_cycle(g, "fullscreen")
	_cycle(g, "vsync")
	_slider(g, "fov", 60, 110, 1)
	_head(g, Loc.t("opt_sec_ctrl"))
	_slider(g, "sens", 0.2, 3.0, 0.05)
	_cycle(g, "invert_y")
	var keys := _lbl(g, Loc.t("opt_keys_title"), 18, DIM)
	keys.size_flags_vertical = Control.SIZE_SHRINK_BEGIN
	var kl := _lbl(g, Loc.t("opt_keys"), 15, PALE)
	kl.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	kl.custom_minimum_size = Vector2(470, 0)

	_head(g, Loc.t("opt_sec_world"))
	var wl := _lbl(g, Loc.f("opt_world_info", [Reality.echoes.size(), Reality.rules.size()]), 16, PALE)
	wl.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	wl.custom_minimum_size = Vector2(330, 0)
	var rb := Button.new()
	rb.text = Loc.t("opt_world_reset")
	rb.custom_minimum_size = Vector2(470, 36)
	rb.add_theme_font_override("font", Loc.font("bold"))
	_skin(rb)
	rb.pressed.connect(_reset_world.bind(rb, wl))
	g.add_child(rb)
	_head(g, Loc.t("opt_sec_about"))
	var ab := _lbl(g, "GOD IS AN AI  v" + str(ProjectSettings.get_setting("application/config/version", "")), 18, DIM)
	ab.size_flags_vertical = Control.SIZE_SHRINK_BEGIN
	var cr := _lbl(g, Loc.t("opt_credits"), 14, PALE)
	cr.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	cr.custom_minimum_size = Vector2(470, 0)
	var back := Button.new()
	back.text = Loc.t("tw_close")
	back.custom_minimum_size = Vector2(0, 48)
	back.add_theme_font_override("font", Loc.font("title"))
	back.add_theme_font_size_override("font_size", 26)
	_skin(back)
	back.pressed.connect(_close)
	back.pressed.connect(Sfx.play.bind("ui_click", -6.0, 1.0))
	v.add_child(back)
	_refresh()
	if first != null:
		first.grab_focus.call_deferred()


func _lbl(par: Node, text: String, size: int, col: Color, font := "mono") -> Label:
	var l := Label.new()
	l.text = text
	l.add_theme_font_override("font", Loc.font(font))
	l.add_theme_font_size_override("font_size", size)
	l.add_theme_color_override("font_color", col)
	par.add_child(l)
	return l


func _head(g: GridContainer, text: String) -> void:
	_lbl(g, text, 24, ORANGE, "title")
	g.add_child(Control.new())


func _slider(g: GridContainer, id: String, lo: float, hi: float, step: float) -> void:
	var l := _lbl(g, "", 18, PALE)
	l.custom_minimum_size = Vector2(330, 0)
	var s := HSlider.new()
	s.min_value = lo
	s.max_value = hi
	s.step = step
	s.value = float(Loc.get(id))
	s.custom_minimum_size = Vector2(470, 32)
	s.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	s.value_changed.connect(_on_slider.bind(id))
	g.add_child(s)
	rows[id] = l
	if first == null:
		first = s


func _cycle(g: GridContainer, id: String) -> void:
	var l := _lbl(g, Loc.t("opt_" + id), 18, PALE)
	l.custom_minimum_size = Vector2(330, 0)
	var b := Button.new()
	b.custom_minimum_size = Vector2(470, 36)
	b.add_theme_font_override("font", Loc.font("bold"))
	b.add_theme_font_size_override("font_size", 17)
	_skin(b)
	b.pressed.connect(_on_cycle.bind(id))
	b.pressed.connect(Sfx.play.bind("ui_click", -6.0, 1.0))
	g.add_child(b)
	rows[id] = b


func _box(bg: Color, border: Color) -> StyleBoxFlat:
	var sb := StyleBoxFlat.new()
	sb.bg_color = bg
	sb.border_color = border
	sb.set_border_width_all(2)
	sb.set_content_margin_all(6)
	return sb


func _skin(b: Button) -> void:
	b.focus_mode = Control.FOCUS_ALL
	b.add_theme_color_override("font_color", Color(1.0, 0.7, 0.35))
	b.add_theme_color_override("font_hover_color", Color(0.06, 0.03, 0.01))
	b.add_theme_color_override("font_focus_color", Color(1.0, 0.85, 0.6))
	b.add_theme_stylebox_override("normal", _box(Color(0.08, 0.045, 0.02), Color(0.55, 0.28, 0.08)))
	b.add_theme_stylebox_override("hover", _box(Color(1.0, 0.6, 0.2), Color(1.0, 0.8, 0.5)))
	b.add_theme_stylebox_override("pressed", _box(Color(1.0, 0.85, 0.6), Color(1, 1, 1)))
	b.add_theme_stylebox_override("focus", _box(Color(0, 0, 0, 0), Color(1.0, 0.85, 0.6)))


func _on_slider(v: float, id: String) -> void:
	match id:
		"sens", "fov":
			Loc.set(id, v)
		_:
			Loc.set(id, int(v))
	Loc.changed()
	_refresh()


func _on_cycle(id: String) -> void:
	match id:
		"lang":
			Loc.cycle_lang()
			_rebuild()
			return
		"quality":
			Loc.quality = (Loc.quality + 1) % 3
		"voice_mode":
			Loc.voice_mode = (Loc.voice_mode + 1) % 3
		_:
			Loc.set(id, not bool(Loc.get(id)))
	Loc.changed()
	_refresh()


func _rebuild() -> void:
	# la langue a change : on reconstruit l'ecran
	for c in get_children():
		remove_child(c)
		c.queue_free()
	_build()


var reset_armed := false


func _reset_world(b: Button, l: Label) -> void:
	if not reset_armed:
		reset_armed = true
		b.text = Loc.t("opt_world_confirm")
		return
	Reality.reset_world()
	reset_armed = false
	b.text = Loc.t("opt_world_done")
	l.text = Loc.f("opt_world_info", [0, 0])


func _yn(v: bool) -> String:
	return str(Loc.list("on_off")[1 if v else 0])


func _refresh() -> void:
	for id in rows:
		var c: Control = rows[id]
		if c is Label:
			var val := ""
			match id:
				"sens":
					val = "%.2f" % Loc.sens
				"fov":
					val = "%d°" % int(Loc.fov)
				_:
					val = "%d %%" % int(Loc.get(id))
			(c as Label).text = Loc.t("opt_" + id) + " : " + val
		elif c is Button:
			var txt := ""
			match id:
				"lang":
					txt = "FRANÇAIS" if Loc.lang == "fr" else "ENGLISH"
				"quality":
					txt = str(Loc.list("gfx")[Loc.quality])
				"voice_mode":
					txt = str(Loc.list("voice_modes")[Loc.voice_mode])
				_:
					txt = _yn(bool(Loc.get(id)))
			(c as Button).text = txt


func _close() -> void:
	closed.emit()
	queue_free()


func _unhandled_input(e: InputEvent) -> void:
	if e.is_action_pressed("ui_cancel"):
		get_viewport().set_input_as_handled()
		_close()
