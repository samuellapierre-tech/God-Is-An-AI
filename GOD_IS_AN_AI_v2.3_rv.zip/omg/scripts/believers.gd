extends RefCounted
## Generateur de fideles : personnalite x honte x situation (FR / EN).
## Des milliers de combinaisons : aucune partie ne se ressemble.
##   var B := preload("res://scripts/believers.gd")
##   var b: Dictionary = B.make(Loc.lang, Game.rng)

const DATA := {
"fr": {
	"first_m": ["Martin", "Gilles", "Keven", "Yvon", "Réjean", "Marc-André", "Patrick", "Sylvain", "Normand", "Jean-Guy",
		"Steve", "Mathieu", "Denis", "Gaétan", "Jocelyn", "Maxime", "Rosaire", "Bruno", "Carl", "Dany"],
	"first_f": ["Lise", "Chantal", "Diane", "Sylvie", "Ginette", "Johanne", "Nathalie", "Mélanie", "Carole", "Josée",
		"Linda", "Manon", "Isabelle", "Pierrette", "Karine", "Suzanne", "Véronique", "Lucie", "Jessica", "Francine"],
	"last": ["Tremblay", "Gagnon", "Bouchard", "Lapointe", "Roy", "Pelletier", "Côté", "Blais", "Dumont", "Caron",
		"Bélanger", "Lévesque", "Gauthier", "Morin", "Fortin", "Ouellet", "Paquette", "Simard", "Gravel", "Boivin"],
	"places": ["Québec", "Trois-Rivières", "Saguenay", "Laval", "Gatineau", "Rimouski", "Sherbrooke", "Drummondville",
		"Lévis", "Granby", "Val-d'Or", "Longueuil", "Saint-Hyacinthe", "Victoriaville", "Matane", "Rouyn-Noranda",
		"Shawinigan", "Baie-Comeau", "Joliette", "Sept-Îles"],
	"shames": [
		"de s'être passé un doigt dans le nez pendant son propre mariage",
		"d'avoir levé le majeur à un corbillard",
		"d'avoir appelé son chien Steve-Steve",
		"d'avoir mangé une pizza entière devant sa belle-mère sans lui en offrir",
		"d'avoir répondu à un courriel de son boss en écrivant seulement « non »",
		"d'avoir parlé à son grille-pain tous les matins pendant onze ans",
		"d'avoir tondu le gazon du voisin à 4 h du matin",
		"d'avoir démissionné par message vocal en chantant",
		"d'avoir baptisé son auto et de lui souhaiter bonne nuit",
		"d'avoir mis du ketchup dans la soupe de sa grand-mère",
		"d'avoir volé un cône orange parce qu'il avait l'air seul",
		"d'avoir applaudi tout seul à la fin d'un film au cinéma",
		"d'avoir dit « toi aussi » au serveur qui disait « bon appétit »",
		"d'avoir fait semblant d'être sa propre jumelle au téléphone pour éviter sa mère",
		"d'avoir mangé le gâteau d'anniversaire d'un collègue la veille de sa fête",
		"d'avoir gagné une partie de Monopoly contre un enfant de six ans et d'avoir célébré",
		"d'avoir répondu « je t'aime » au livreur de pizza",
		"d'avoir caché un poisson dans le plafond de son ex",
		"d'avoir appris la danse en ligne en cachette pour humilier sa famille à Noël",
		"d'avoir lu le journal intime de son chat (le chat n'en a pas)",
		"d'avoir crié « BINGO » à des funérailles par réflexe",
		"d'avoir pris la dernière place de stationnement devant une religieuse",
		"d'avoir porté le même chandail 41 jours d'affilée pour voir si quelqu'un remarquerait",
		"d'avoir mis sa face sur la photo de profil de son voisin",
		"d'avoir fait un discours de mariage entièrement en rimes, sans être invité",
		"d'avoir réchauffé du poisson dans le micro-ondes du bureau, volontairement",
		"d'avoir laissé un commentaire 1 étoile à un lac",
		"d'avoir fait ses impôts en vers alexandrins",
		"d'avoir ri pendant une minute de silence parce qu'une mouche est entrée dans le nez du maire",
		"d'avoir vendu le vélo de son frère pour acheter une épée",
		"d'avoir dit à tout le bureau qu'il avait été kidnappé par des extraterrestres pour avoir congé",
		"d'avoir appelé le 9-1-1 pour demander la recette du pâté chinois",
		"d'avoir fait un TikTok dans un salon funéraire",
		"d'avoir donné le nom de son ex à une tumeur bénigne",
		"d'avoir organisé une manifestation contre la pluie",
		"d'avoir léché une batterie neuve devant des enfants",
	],
	"situations": [
		"en conduisant sur l'autoroute 20, à 130 km/h",
		"caché dans un garde-robe pendant un party de bureau",
		"au karaoké, le micro encore ouvert",
		"enfermé dans les toilettes d'un avion",
		"en direct sur TikTok devant 14 000 personnes",
		"pendant une réunion Teams, en pensant que la caméra est fermée",
		"dans la file d'attente à la SAQ",
		"pendant son propre mariage, devant l'autel",
		"dans un spa nordique, entre deux bains froids",
		"chez le dentiste, la bouche grande ouverte",
		"en promenant six chiens en même temps",
		"pendant que sa mère écoute sur l'autre téléphone",
		"dans un sous-sol d'église pendant un bingo",
		"en pleine nuit, en chuchotant pour ne pas réveiller son conjoint",
	],
	"pers": {
		"anxious": ["Angoisse", "Tu paniques facilement, tu poses mille questions et tu t'excuses tout le temps."],
		"angry": ["Colère", "Tu es fâché et sur la défensive. Tu cries parfois (MAJUSCULES) et tu menaces de changer de religion."],
		"pious": ["Piété extrême", "Tu es ultra-pieux. Tu cites des passages bibliques inventés et tu prends tout au pied de la lettre."],
		"skeptic": ["Scepticisme", "Tu doutes que ce soit vraiment Dieu. Tu exiges des preuves et tu poses des pièges."],
		"chatty": ["Moulin à paroles", "Tu parles beaucoup trop et tu dérapes sur des sujets sans rapport (ta belle-sœur, ton char, ton genou)."],
		"shy": ["Timidité", "Tu chuchotes, tu fais des phrases très courtes et tu as peur de déranger Dieu."],
		"lawyer": ["Esprit d'avocat", "Tu argumentes comme un avocat : tu demandes des clauses, des précédents, et tu négocies chaque point."],
		"naive": ["Naïveté totale", "Tu crois absolument tout, mais tu comprends tout de travers."],
		"kid": ["Enfant", "Tu es un enfant. Logique d'enfant, questions bizarres, tu parles de ton toutou."],
	},
	"relations": ["couple marié depuis 31 ans", "voisins qui se détestent", "frère et sœur", "colocataires", "belle-mère et gendre", "meilleurs amis depuis le primaire"],
},
"en": {
	"first_m": ["Brad", "Gary", "Tyler", "Walter", "Rick", "Kyle", "Steve", "Doug", "Chad", "Todd",
		"Randy", "Kevin", "Dale", "Earl", "Bobby", "Travis", "Wayne", "Greg", "Dustin", "Hank"],
	"first_f": ["Linda", "Megan", "Donna", "Ashley", "Barbara", "Karen", "Brenda", "Tammy", "Crystal", "Debbie",
		"Pam", "Kayla", "Sharon", "Wendy", "Trish", "Peggy", "Brittany", "Janet", "Gloria", "Heather"],
	"last": ["Kowalski", "Hayes", "Pruitt", "Brooks", "Doyle", "Finch", "Russo", "Dawson", "Moreno", "Bennett",
		"Quinn", "Harlow", "McAllister", "Jenkins", "Whitaker", "Sullivan", "Barnes", "Holloway", "Pratt", "Dunn"],
	"places": ["Ohio", "Florida", "Nebraska", "New Jersey", "Oregon", "Maine", "Pennsylvania", "Texas", "Arizona",
		"Michigan", "Ontario", "Colorado", "Idaho", "Kentucky", "Manchester", "Alberta", "Wisconsin", "Nevada",
		"Ireland", "Iowa"],
	"shames": [
		"picking their nose during their own wedding",
		"flipping off a hearse in traffic",
		"naming their dog Kevin Kevin",
		"eating an entire pizza in front of their mother-in-law without offering her a slice",
		"replying to their boss's email with only the word \"no\"",
		"talking to their toaster every morning for eleven years",
		"mowing the neighbor's lawn at 4 a.m.",
		"quitting their job by singing a voicemail",
		"naming their car and saying goodnight to it",
		"putting ketchup in grandma's soup",
		"stealing a traffic cone because it looked lonely",
		"clapping alone at the end of a movie",
		"saying \"you too\" when the waiter said \"enjoy your meal\"",
		"pretending to be their own twin on the phone to avoid their mom",
		"eating a coworker's birthday cake the day before the party",
		"beating a six-year-old at Monopoly and celebrating",
		"saying \"love you\" to the pizza delivery guy",
		"hiding a fish in their ex's ceiling",
		"secretly learning line dancing to humiliate the family at Christmas",
		"reading their cat's diary (the cat does not have one)",
		"yelling \"BINGO\" at a funeral out of reflex",
		"stealing the last parking spot from a nun",
		"wearing the same sweater for 41 days to see if anyone would notice",
		"putting their own face on their neighbor's profile picture",
		"giving a wedding speech entirely in rhymes without being invited",
		"microwaving fish at the office, on purpose",
		"leaving a one-star review for a lake",
		"filing their taxes as a sonnet",
		"laughing during a minute of silence because a fly went up the mayor's nose",
		"selling their brother's bike to buy a sword",
		"telling the whole office they'd been abducted by aliens to get a day off",
		"calling 911 to ask for a meatloaf recipe",
		"filming a TikTok dance at a funeral home",
		"naming a benign tumor after their ex",
		"organizing a protest against rain",
		"licking a 9-volt battery in front of children",
	],
	"situations": [
		"while driving on the highway at 80 mph",
		"hiding in a closet during an office party",
		"at karaoke, with the mic still on",
		"locked in an airplane bathroom",
		"live on TikTok in front of 14,000 viewers",
		"during a Zoom meeting, thinking the camera is off",
		"in line at the liquor store",
		"during their own wedding, at the altar",
		"in a hot tub at a sketchy motel",
		"at the dentist, mouth wide open",
		"while walking six dogs at once",
		"while their mom is listening on the other phone",
		"in a church basement during bingo night",
		"in the middle of the night, whispering so their spouse won't wake up",
	],
	"pers": {
		"anxious": ["Anxious", "You panic easily, ask a thousand questions and apologize constantly."],
		"angry": ["Angry", "You are mad and defensive. You sometimes yell (CAPS) and threaten to switch religions."],
		"pious": ["Extremely pious", "You are ultra-religious. You quote made-up bible verses and take everything literally."],
		"skeptic": ["Skeptic", "You doubt this is really God. You demand proof and set little traps."],
		"chatty": ["Chatterbox", "You talk way too much and drift into unrelated topics (your sister-in-law, your truck, your knee)."],
		"shy": ["Shy", "You whisper, use very short sentences and are afraid of bothering God."],
		"lawyer": ["Lawyer brain", "You argue like a lawyer : you ask for clauses, precedents, and negotiate every point."],
		"naive": ["Totally naive", "You believe absolutely everything, but you understand everything wrong."],
		"kid": ["Kid", "You are a kid. Kid logic, weird questions, you keep talking about your stuffed animal."],
	},
	"relations": ["a couple married for 31 years", "neighbors who hate each other", "brother and sister", "roommates", "mother-in-law and son-in-law", "best friends since grade school"],
},
}

# meme ordre que "situations" (FR et EN) : sert au decor de l'appel video
const SIT_IDS := ["car", "closet", "karaoke", "plane", "tiktok", "zoom", "liquor", "wedding", "spa",
	"dentist", "dogs", "mom", "bingo", "night"]

# depart de conviction / gain hors ligne / bonus d'argent
const PERS_STATS := {
	"anxious": [10, 18, 1.0], "angry": [0, 13, 1.3], "pious": [20, 24, 0.9],
	"skeptic": [0, 12, 1.4], "chatty": [15, 20, 1.0], "shy": [10, 20, 1.0],
	"lawyer": [0, 11, 1.5], "naive": [30, 30, 0.7], "kid": [25, 26, 0.6],
}


static var merged := {}
static var mods_count := 0


static func _d(lang: String) -> Dictionary:
	if merged.has(lang):
		return merged[lang]
	return DATA.get(lang, DATA["fr"])


## MODS : chaque fichier user://mods/*.json peut ajouter des listes, par exemple
## {"fr": {"shames": ["d'avoir ..."], "first_m": ["Ti-Guy"], "places": ["Chibougamau"]},
##  "en": {"shames": ["..."]}}
## Listes acceptees : first_m, first_f, last, places, shames, relations.
static func load_mods() -> int:
	merged = {}
	mods_count = 0
	DirAccess.make_dir_recursive_absolute("user://mods")
	var da := DirAccess.open("user://mods")
	if da == null:
		return 0
	var keys := ["first_m", "first_f", "last", "places", "shames", "relations"]
	for fn in da.get_files():
		if not fn.ends_with(".json"):
			continue
		var data = JSON.parse_string(FileAccess.get_file_as_string("user://mods/" + fn))
		if typeof(data) != TYPE_DICTIONARY:
			push_warning("Mod invalide : " + fn)
			continue
		var ok := false
		for lang in data:
			if not DATA.has(lang) or typeof(data[lang]) != TYPE_DICTIONARY:
				continue
			if not merged.has(lang):
				merged[lang] = DATA[lang].duplicate(true)
			for k in keys:
				var add = data[lang].get(k, null)
				if typeof(add) == TYPE_ARRAY:
					for it in add:
						if typeof(it) == TYPE_STRING and str(it).strip_edges() != "":
							(merged[lang][k] as Array).append(str(it).strip_edges().substr(0, 200))
							ok = true
		if ok:
			mods_count += 1
	return mods_count


static func _pick(rng: RandomNumberGenerator, a: Array):
	return a[rng.randi() % a.size()]


static func make(lang: String, rng: RandomNumberGenerator) -> Dictionary:
	var d := _d(lang)
	var fem := rng.randf() < 0.5
	var first: String = _pick(rng, d["first_f"] if fem else d["first_m"])
	var keys: Array = PERS_STATS.keys()
	var pers: String = _pick(rng, keys)
	var age := rng.randi_range(19, 84)
	if pers == "kid":
		age = rng.randi_range(6, 10)
	var st: Array = PERS_STATS[pers]
	var pinfo: Array = d["pers"][pers]
	var sits: Array = d["situations"]
	var si := rng.randi() % sits.size()
	return {
		"name": first + " " + str(_pick(rng, d["last"])),
		"fem": fem,
		"age": age,
		"place": str(_pick(rng, d["places"])),
		"shame": str(_pick(rng, d["shames"])),
		"situation": str(sits[si]),
		"sit_id": SIT_IDS[si % SIT_IDS.size()],
		"look_seed": rng.randi(),
		"pers": pers,
		"pers_label": str(pinfo[0]),
		"pers_prompt": str(pinfo[1]),
		"start": int(st[0]),
		"gain": int(st[1]),
		"bonus": float(st[2]),
		"kind": "normal",
	}


static func make_conference(lang: String, rng: RandomNumberGenerator) -> Dictionary:
	var a := make(lang, rng)
	var b := make(lang, rng)
	while b["pers"] == "kid":
		b = make(lang, rng)
	if a["pers"] == "kid":
		a = make(lang, rng)
	a["kind"] = "conference"
	a["other"] = b
	a["relation"] = str(_pick(rng, _d(lang)["relations"]))
	a["start"] = 0
	a["gain"] = int(min(int(a["gain"]), int(b["gain"])) * 0.7)
	a["bonus"] = float(a["bonus"]) + float(b["bonus"])
	return a


static func make_callback(prev: Dictionary) -> Dictionary:
	var c := prev.duplicate(true)
	c["kind"] = "callback"
	c["start"] = 20
	c["gain"] = int(c["gain"]) + 4
	c["bonus"] = float(c["bonus"]) * 1.3
	return c
