extends Node
## Tout ce qui fait des clips : le chat Twitch joue Dieu, Dieu entend
## ceux qui crient, voix d'helium / voix du diable, echo de cathedrale,
## et les MOMENTS FORTS photographies automatiquement.

const SIGNS := ["sky", "coincidence", "witness", "smite", "frogs", "cat", "jingle"]
const SHOUT_LEVEL := 0.33
const HL_MAX := 12

var main: Node
var feed: PanelContainer
var feed_box: VBoxContainer
var feed_head: Label
var feed_lines := []
var fx_lbl: Label
var vote_t := 0.0
var sign_cd := 0.0
var shout_t := 0.0
var shout_cd := 0.0
var hl_cd := 0.0
var pitch_left := 0.0
var pitch_kind := ""
var gallery: CanvasLayer = null


func _ready() -> void:
	_setup_voice_bus()
	_build_feed()
	Stream.confession_added.connect(_on_confession)
	Profile.unlocked.connect(_on_unlock)
	Stream.echo_idea.connect(_on_echo_idea)
	if Dev.args.has("helium"):
		set_pitch.call_deferred("helium", 30.0)


func _on_echo_idea(u: String, t: String) -> void:
	main.echo_hear(t, "twitch", "@" + u)


# ------------------------------------------------------------- HUD du chat

func _build_feed() -> void:
	var cl: CanvasLayer = main.hud_layer
	feed = PanelContainer.new()
	var sb := StyleBoxFlat.new()
	sb.bg_color = Color(0.06, 0.02, 0.1, 0.72)
	sb.border_color = Color(0.57, 0.27, 1.0)
	sb.set_border_width_all(2)
	sb.set_content_margin_all(8)
	feed.add_theme_stylebox_override("panel", sb)
	feed.anchor_left = 1.0
	feed.anchor_right = 1.0
	feed.offset_left = -330
	feed.offset_right = -14
	feed.offset_top = 150
	feed.clip_contents = true
	feed.mouse_filter = Control.MOUSE_FILTER_IGNORE
	cl.add_child(feed)
	feed_box = VBoxContainer.new()
	feed_box.add_theme_constant_override("separation", 2)
	feed.add_child(feed_box)
	feed_head = _l(feed_box, "bold", 15, Color(0.75, 0.55, 1.0))
	feed_head.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	feed_head.custom_minimum_size = Vector2(300, 0)
	var help := _l(feed_box, "mono", 12, Color(0.8, 0.75, 0.9))
	help.text = Loc.t("tw_help")
	help.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	help.custom_minimum_size = Vector2(300, 0)
	for i in 7:
		var l := RichTextLabel.new()
		l.bbcode_enabled = true
		l.fit_content = true
		l.scroll_active = false
		l.custom_minimum_size = Vector2(300, 0)
		l.add_theme_font_override("normal_font", Loc.font("mono"))
		l.add_theme_font_override("bold_font", Loc.font("bold"))
		l.add_theme_font_size_override("normal_font_size", 13)
		l.add_theme_font_size_override("bold_font_size", 13)
		l.mouse_filter = Control.MOUSE_FILTER_IGNORE
		feed_box.add_child(l)
		feed_lines.append(l)
	feed.visible = false

	fx_lbl = _l(cl, "title", 30, Color(0.75, 0.55, 1.0))
	fx_lbl.anchor_left = 0.5
	fx_lbl.anchor_right = 0.5
	fx_lbl.offset_left = -300
	fx_lbl.offset_right = 300
	fx_lbl.offset_top = 170
	fx_lbl.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER


func _l(par: Node, fk: String, size: int, col: Color) -> Label:
	var l := Label.new()
	l.add_theme_font_override("font", Loc.font(fk))
	l.add_theme_font_size_override("font_size", size)
	l.add_theme_color_override("font_color", col)
	l.add_theme_color_override("font_shadow_color", Color(0, 0, 0, 0.8))
	l.add_theme_constant_override("shadow_offset_x", 2)
	l.add_theme_constant_override("shadow_offset_y", 2)
	l.mouse_filter = Control.MOUSE_FILTER_IGNORE
	par.add_child(l)
	return l


func _refresh_feed() -> void:
	var on := Stream.channel != ""
	feed.visible = on and not main.pc_ui.visible and not main.overlay.is_open()
	if not feed.visible:
		return
	feed_head.text = Loc.f("tw_head", [Stream.channel, Stream.queue.size()]) if Stream.connected else Loc.f("tw_connecting", [Stream.channel])
	for i in feed_lines.size():
		var rl: RichTextLabel = feed_lines[i]
		if i < Stream.recent.size():
			var r: Array = Stream.recent[i]
			var c: Color = r[2]
			rl.text = "[b][color=#%s]%s[/color][/b] %s" % [c.to_html(false), str(r[0]).replace("[", "("), str(r[1]).replace("[", "(")]
		else:
			rl.text = ""


func _on_unlock(kind: String, id: String) -> void:
	if kind == "ach":
		_fx(Loc.f("toast_ach", [Loc.t("ach_" + id)]), 4.0)
		Sfx.play("score", -4.0)
	else:
		_fx(Loc.f("toast_item", [Loc.t("item_" + (id if id != "" else "none"))]), 4.0)
		Sfx.play("shimmer", -6.0)


func _on_confession(user: String) -> void:
	if main.frozen:
		return
	main._log(Loc.t("tw_log"), Loc.f("tw_queued", [user]), "#b48cff")


# ------------------------------------------------------------- fidele du chat

## Appele quand on decroche : remplace parfois le fidele par une confession du chat.
func maybe_viewer(b: Dictionary) -> Dictionary:
	if not Stream.has_confession() or str(b.get("kind", "")) == "conference":
		return b
	var c: Dictionary = Stream.take_confession()
	b["kind"] = "normal"
	b["viewer"] = str(c["user"])
	b["name"] = str(c["user"])
	b["shame"] = Loc.f("tw_shame", [str(c["text"])])
	b["viewer_text"] = str(c["text"])
	b["pers_prompt"] = str(b["pers_prompt"]) + Loc.t("tw_ai")
	b["start"] = int(b["start"]) + 5
	b["bonus"] = float(b["bonus"]) * 1.25
	main._log(Loc.t("tw_log"), Loc.f("tw_calling", [str(c["user"]), str(c["text"])]), "#b48cff")
	Sfx.play("cheer", -10.0, 1.2)
	if Dev.args.has("autoplay"):
		print("VIEWER CALL ", c["user"], " : ", c["text"])
	return b


# ------------------------------------------------------------- boucle

func _process(dt: float) -> void:
	hl_cd -= dt
	sign_cd -= dt
	shout_cd -= dt
	_refresh_feed()
	_tick_pitch(dt)
	if main.frozen:
		return
	_tick_shout(dt)
	if Stream.channel == "":
		return
	vote_t += dt
	if vote_t > 45.0:
		vote_t = 0.0
		_mood_vote()
	if main.in_call and sign_cd <= 0.0:
		var who := Stream.take_sign()
		if who != "":
			sign_cd = 20.0
			_viewer_sign(who)
	if Stream.take_cheer():
		Sfx.play("cheer", -6.0)
		_fx(Loc.t("tw_amen"), 3.0)


func _mood_vote() -> void:
	var r := Stream.take_mood_vote()
	if Dev.args.has("autoplay"):
		print("VIEWER VOTE ", r)
	match str(r[0]):
		"wrath":
			main._god(Loc.f("tw_wrath", [int(r[1]), int(r[2])]))
			main._add_expo(6.0)
			Sfx.play("thunder", -4.0)
			highlight("tw_wrath_hl")
		"joy":
			main._god(Loc.f("tw_joy", [int(r[2]), int(r[1])]))
			main._add_expo(-6.0)
			Sfx.play("choir", -6.0)


func _viewer_sign(who: String) -> void:
	if Dev.args.has("autoplay"):
		print("VIEWER SIGN ", who)
	var id: String = SIGNS[randi() % SIGNS.size()]
	if main.callview != null:
		main.callview.power_fx(id)
	main._call_net("fx", id)
	main._power_sound(id)
	main._log(Loc.t("tw_log"), Loc.f("tw_sign", [who]), "#b48cff")
	_fx(Loc.f("tw_sign", [who]), 3.0)
	main._ask_ai(main.EVENT_TAG + Loc.f("mk_event", [Loc.f("tw_sign_ev", [who])]))


func _fx(text: String, secs: float) -> void:
	fx_lbl.text = text
	var tw := create_tween()
	fx_lbl.modulate.a = 1.0
	tw.tween_interval(secs)
	tw.tween_property(fx_lbl, "modulate:a", 0.0, 0.6)


# ------------------------------------------------------------- Dieu t'entend crier

func _tick_shout(dt: float) -> void:
	var v = main.voice
	if v == null or not v.transmitting or v.radio:
		shout_t = maxf(0.0, shout_t - dt)
		return
	if v.level > SHOUT_LEVEL:
		shout_t += dt
	else:
		shout_t = maxf(0.0, shout_t - dt * 0.5)
	if shout_t > 1.1 and shout_cd <= 0.0:
		shout_t = 0.0
		shout_cd = 25.0
		main._god(Loc.pick("shout_god"))
		main._add_expo(3.0)
		Sfx.play("thunder", -10.0, 1.4)
		main._stat("shouts")
		Profile.unlock("shout")
		if Dev.args.has("autoplay"):
			print("SHOUT detecte niveau=", v.level)
		main.sync.bcast(&"action", ["shout", 0])
		highlight("shout")


# ------------------------------------------------------------- voix modifiees

func _setup_voice_bus() -> void:
	# echo de cathedrale sur les voix des collegues
	if AudioServer.get_bus_index("Voice") < 0:
		AudioServer.add_bus()
		AudioServer.set_bus_name(AudioServer.bus_count - 1, "Voice")
	var vb := AudioServer.get_bus_index("Voice")
	if AudioServer.get_bus_effect_count(vb) == 0:
		var rv := AudioEffectReverb.new()
		rv.room_size = 0.75
		rv.damping = 0.35
		rv.wet = 0.22
		rv.dry = 0.9
		rv.predelay_msec = 40.0
		AudioServer.add_bus_effect(vb, rv)
	# pitch du micro (avant la capture)
	var mb := AudioServer.get_bus_index("Mic")
	if mb >= 0 and _pitch_fx(mb) == null:
		var ps := AudioEffectPitchShift.new()
		ps.pitch_scale = 1.0
		AudioServer.add_bus_effect(mb, ps, 0)
		AudioServer.set_bus_effect_enabled(mb, 0, false)


func _pitch_fx(mb: int) -> AudioEffectPitchShift:
	for i in AudioServer.get_bus_effect_count(mb):
		var e := AudioServer.get_bus_effect(mb, i)
		if e is AudioEffectPitchShift:
			return e
	return null


func set_pitch(kind: String, secs: float) -> void:
	pitch_kind = kind
	pitch_left = secs
	var sc := 1.75 if kind == "helium" else (0.62 if kind == "devil" else 1.0)
	var mb := AudioServer.get_bus_index("Mic")
	if mb >= 0:
		var ps := _pitch_fx(mb)
		if ps != null:
			ps.pitch_scale = sc
			for i in AudioServer.get_bus_effect_count(mb):
				if AudioServer.get_bus_effect(mb, i) == ps:
					AudioServer.set_bus_effect_enabled(mb, i, kind != "")
	if main.voice != null:
		main.voice.pitch = sc


func _tick_pitch(dt: float) -> void:
	if pitch_left <= 0.0:
		return
	pitch_left -= dt
	main.hud_voicefx = Loc.f("vfx_" + pitch_kind, [int(ceil(pitch_left))])
	if pitch_left <= 0.0:
		set_pitch("", 0.0)
		main.hud_voicefx = ""


## Fontaine / machine : chance d'une voix speciale (co-op seulement : il faut des oreilles).
func try_voice_item(source: String) -> bool:
	if main.voice == null or pitch_left > 0.0:
		return false
	if source == "water" and randf() < 0.3:
		set_pitch("helium", 25.0)
		Profile.unlock("helium")
		main._say(Loc.t("helium_drink"), 4.0)
		Sfx.play("whistle_up", -4.0)
		highlight("helium")
		return true
	if source == "vending" and randf() < 0.18:
		set_pitch("devil", 25.0)
		main._say(Loc.t("devil_candy"), 4.0)
		Sfx.play("whistle_down", -4.0)
		return true
	return false


# ------------------------------------------------------------- moments forts

func highlight(key: String, extra := "") -> void:
	if hl_cd > 0.0:
		return
	hl_cd = 4.0
	var list: Array = Game.highlights
	var same := 0
	for h in list:
		if str(h["key"]) == key:
			same += 1
	if same >= 3:
		return
	var cap := Loc.f("hl_" + key, [extra]) if extra != "" else Loc.t("hl_" + key)
	var entry := {"key": key, "cap": cap, "day": Game.day, "img": null}
	if list.size() >= HL_MAX:
		list.pop_front()
	list.append(entry)
	if DisplayServer.get_name() == "headless":
		return
	# photo propre : on cache l'interface le temps d'une image
	var hud: CanvasLayer = main.hud_layer
	var was := hud.visible
	hud.visible = false
	await RenderingServer.frame_post_draw
	hud.visible = was
	var tex := get_viewport().get_texture()
	if tex == null:
		return
	var img := tex.get_image()
	if img == null:
		return
	img.resize(640, int(640.0 * float(img.get_height()) / float(img.get_width())), Image.INTERPOLATE_BILINEAR)
	entry["img"] = img


func open_gallery() -> void:
	if gallery != null:
		return
	gallery = CanvasLayer.new()
	gallery.layer = 30
	add_child(gallery)
	var bg := ColorRect.new()
	bg.color = Color(0, 0, 0, 0.92)
	bg.set_anchors_preset(Control.PRESET_FULL_RECT)
	gallery.add_child(bg)
	var v := VBoxContainer.new()
	v.set_anchors_preset(Control.PRESET_FULL_RECT)
	v.offset_left = 40
	v.offset_right = -40
	v.offset_top = 24
	v.offset_bottom = -24
	v.add_theme_constant_override("separation", 10)
	gallery.add_child(v)
	var title := _l(v, "title", 44, Color(1.0, 0.6, 0.2))
	title.text = Loc.t("hl_title")
	title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	var grid := GridContainer.new()
	grid.columns = 4
	grid.add_theme_constant_override("h_separation", 12)
	grid.add_theme_constant_override("v_separation", 8)
	grid.size_flags_vertical = Control.SIZE_EXPAND_FILL
	v.add_child(grid)
	var list: Array = Game.highlights
	if list.is_empty():
		var none := _l(v, "mono", 20, Color(0.8, 0.7, 0.6))
		none.text = Loc.t("hl_none")
		none.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	for h in list:
		var cell := VBoxContainer.new()
		grid.add_child(cell)
		var tr := TextureRect.new()
		tr.custom_minimum_size = Vector2(370, 208)
		tr.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
		tr.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_COVERED
		if h["img"] != null:
			tr.texture = ImageTexture.create_from_image(h["img"])
		cell.add_child(tr)
		var cap := _l(cell, "bold", 15, Color(1.0, 0.9, 0.75))
		cap.text = Loc.f("hl_day", [int(h["day"])]) + "  " + str(h["cap"])
		cap.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		cap.custom_minimum_size = Vector2(370, 0)
	var ech = main.echoes
	if ech != null and not ech.archive_ids().is_empty():
		var at := _l(v, "bold", 18, Color(1.0, 0.75, 0.4))
		at.text = Loc.t("arch_title")
		at.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		var arow := HBoxContainer.new()
		arow.alignment = BoxContainer.ALIGNMENT_CENTER
		arow.add_theme_constant_override("separation", 12)
		v.add_child(arow)
		for id in ech.archive_ids():
			var nm := str(Net.players.get(id, {}).get("name", "?"))
			var ab: Button = main._btn(arow, "> " + nm)
			ab.custom_minimum_size = Vector2(200, 40)
			ab.pressed.connect(ech.play_archive.bind(int(id)))
	var msg := _l(v, "mono", 15, Color(0.5, 1.0, 0.6))
	msg.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	var row := HBoxContainer.new()
	row.alignment = BoxContainer.ALIGNMENT_CENTER
	row.add_theme_constant_override("separation", 16)
	v.add_child(row)
	var b1: Button = main._btn(row, Loc.t("hl_save"))
	b1.custom_minimum_size = Vector2(300, 44)
	b1.pressed.connect(_save_gallery.bind(msg))
	var b2: Button = main._btn(row, Loc.t("hl_back"))
	b2.custom_minimum_size = Vector2(300, 44)
	b2.pressed.connect(close_gallery)


func close_gallery() -> void:
	if gallery != null:
		gallery.queue_free()
	gallery = null
	if main.overlay != null:
		main.overlay.visible = true


func _save_gallery(msg: Label) -> void:
	var dir := "user://moments/" + Time.get_datetime_string_from_system().replace(":", "-")
	DirAccess.make_dir_recursive_absolute(dir)
	var n := 0
	for h in Game.highlights:
		if h["img"] != null:
			n += 1
			var out: Image = await _stamp(h)
			out.save_png("%s/%02d_%s.png" % [dir, n, str(h["key"])])
	var abs_path := ProjectSettings.globalize_path(dir)
	msg.text = Loc.f("hl_saved", [n, abs_path])
	if n > 0 and DisplayServer.get_name() != "headless":
		OS.shell_show_in_file_manager(abs_path)


## Ajoute le bandeau « OH MY GOD! » + la legende sur la photo (pret a poster).
func _stamp(h: Dictionary) -> Image:
	var src: Image = h["img"]
	if DisplayServer.get_name() == "headless":
		return src
	var w := src.get_width()
	var hh := src.get_height()
	var vp := SubViewport.new()
	vp.size = Vector2i(w, hh + 56)
	vp.transparent_bg = false
	vp.render_target_update_mode = SubViewport.UPDATE_ONCE
	add_child(vp)
	var bg := ColorRect.new()
	bg.color = Color(0.06, 0.03, 0.02)
	bg.size = Vector2(vp.size)
	vp.add_child(bg)
	var tr := TextureRect.new()
	tr.texture = ImageTexture.create_from_image(src)
	tr.size = Vector2(w, hh)
	vp.add_child(tr)
	var logo := Label.new()
	logo.text = "GOD IS AN AI"
	logo.add_theme_font_override("font", Loc.font("title"))
	logo.add_theme_font_size_override("font_size", 34)
	logo.add_theme_color_override("font_color", Color(1.0, 0.58, 0.16))
	logo.add_theme_color_override("font_outline_color", Color(0, 0, 0))
	logo.add_theme_constant_override("outline_size", 8)
	logo.position = Vector2(12, 6)
	vp.add_child(logo)
	var cap := Label.new()
	cap.text = Loc.f("hl_day", [int(h["day"])]) + "  ·  " + str(h["cap"])
	cap.add_theme_font_override("font", Loc.font("bold"))
	cap.add_theme_font_size_override("font_size", 17)
	cap.add_theme_color_override("font_color", Color(1.0, 0.92, 0.78))
	cap.position = Vector2(14, hh + 12)
	cap.size = Vector2(w - 28, 40)
	cap.clip_text = true
	vp.add_child(cap)
	await RenderingServer.frame_post_draw
	await RenderingServer.frame_post_draw
	var img := vp.get_texture().get_image()
	vp.queue_free()
	return img if img != null else src


# ------------------------------------------------------------- archives de Reality Echo

## La revelation de fin de semaine : d'ou vient chaque chose devenue reelle.
func open_archives() -> void:
	if gallery != null:
		return
	gallery = CanvasLayer.new()
	gallery.layer = 30
	add_child(gallery)
	if main.overlay != null:
		main.overlay.visible = false      # le bilan reapparait en fermant les archives
	var bg := ColorRect.new()
	bg.color = Color(0.0, 0.03, 0.02, 1.0)
	bg.set_anchors_preset(Control.PRESET_FULL_RECT)
	gallery.add_child(bg)
	var v := VBoxContainer.new()
	v.set_anchors_preset(Control.PRESET_FULL_RECT)
	v.offset_left = 60
	v.offset_right = -60
	v.offset_top = 30
	v.offset_bottom = -30
	v.add_theme_constant_override("separation", 10)
	gallery.add_child(v)
	var title := _l(v, "title", 44, Color(0.45, 1.0, 0.7))
	title.text = Loc.t("arc_title")
	title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	var sub := _l(v, "mono", 16, Color(0.6, 0.85, 0.7))
	sub.text = Loc.t("arc_sub")
	sub.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	var sc := ScrollContainer.new()
	sc.size_flags_vertical = Control.SIZE_EXPAND_FILL
	sc.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	v.add_child(sc)
	var list := VBoxContainer.new()
	list.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	list.add_theme_constant_override("separation", 14)
	sc.add_child(list)
	var es: Array = Reality.echoes.duplicate()
	es.sort_custom(func(a, b): return int(a["tier"]) * 100 + float(a["strength"]) > int(b["tier"]) * 100 + float(b["strength"]))
	if es.is_empty():
		var none := _l(list, "bold", 20, Color(0.7, 0.8, 0.75))
		none.text = Loc.t("arc_none")
	for e in es:
		var tier := int(e["tier"])
		var col: Color = [Color(0.5, 0.55, 0.5), Color(0.7, 0.85, 0.75), Color(0.6, 1.0, 0.7), Color(1.0, 0.9, 0.4), Color(1.0, 0.6, 0.2), Color(1.0, 0.3, 0.4)][clampi(tier, 0, 5)]
		var head := _l(list, "bold", 21, col)
		head.text = "[%s]  %s" % [Loc.t("echo_tier_%d" % maxi(1, tier)).to_upper(), str(e["movement"]) if tier >= 4 and str(e["movement"]) != "" else str(e["idea"])]
		head.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		var orig := _l(list, "mono", 16, Color(0.95, 0.95, 0.9))
		orig.text = Loc.f("arc_origin", [str(e["orig"]), str(e["who"]), str(e["when"]), int(e["mentions"]), (e["speakers"] as Array).size()])
		orig.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		var hist: Array = e.get("history", [])
		if not hist.is_empty():
			var hl := _l(list, "mono", 14, Color(0.6, 0.75, 0.65))
			hl.text = "   " + "\n   ".join(PackedStringArray(hist.slice(-5)))
			hl.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	var b2: Button = main._btn(v, Loc.t("hl_back"))
	b2.custom_minimum_size = Vector2(300, 44)
	b2.pressed.connect(close_gallery)
