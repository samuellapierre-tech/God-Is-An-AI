extends Control
## Menu principal facon terminal Lethal Company.
## L'oeil de Dieu suit la souris en arriere-plan.

const ORANGE := Color(1.0, 0.55, 0.16)
const ORANGE_DIM := Color(0.55, 0.28, 0.08)

var bg_mat: ShaderMaterial
var title: Label
var sub: Label
var hint: Label
var crash_lbl: Label
var btns := {}
var t := 0.0
var loading := false
var options_page := false
const OPT_IDS := ["lang", "gfx", "sound", "voice", "echo", "back"]

const BG_SHADER := """
shader_type canvas_item;
uniform vec2 eye = vec2(0.5, 0.5);
uniform float blink = 1.0;
uniform vec2 res = vec2(1600.0, 900.0);

float hash(vec2 p) { return fract(sin(dot(p, vec2(12.9898, 78.233))) * 43758.5453); }
float noise(vec2 p) {
	vec2 i = floor(p); vec2 f = fract(p);
	float a = hash(i), b = hash(i + vec2(1.0, 0.0)), c = hash(i + vec2(0.0, 1.0)), d = hash(i + vec2(1.0, 1.0));
	vec2 u = f * f * (3.0 - 2.0 * f);
	return mix(a, b, u.x) + (c - a) * u.y * (1.0 - u.x) + (d - b) * u.x * u.y;
}

void fragment() {
	vec2 px = vec2(480.0, 270.0);
	vec2 uv = floor(UV * px) / px;
	vec2 p = (uv - vec2(0.72, 0.48)) * vec2(res.x / res.y, 1.0);

	// brouillard qui derive
	float fog = noise(uv * 6.0 + vec2(TIME * 0.05, 0.0)) * 0.5 + noise(uv * 13.0 - vec2(0.0, TIME * 0.03)) * 0.25;
	vec3 col = vec3(0.02, 0.022, 0.03) + vec3(0.05, 0.035, 0.02) * fog;

	// oeil de Dieu
	float r = length(p * vec2(1.0, 1.0 / max(blink, 0.05)));
	float lid = 1.0 - smoothstep(0.29, 0.30, r);
	vec2 look = (eye - vec2(0.72, 0.48)) * 0.12;
	float iris = 1.0 - smoothstep(0.12, 0.13, length(p - look));
	float pupil = 1.0 - smoothstep(0.045, 0.05, length(p - look));
	float halo = exp(-length(p) * 4.0) * 0.5;
	col += vec3(1.0, 0.55, 0.16) * halo * 0.35;
	col = mix(col, vec3(0.75, 0.70, 0.62) * (0.6 + fog * 0.4), lid);
	col = mix(col, vec3(1.0, 0.55, 0.12), iris * lid);
	col = mix(col, vec3(0.02), pupil * lid);
	// rayons
	float ang = atan(p.y, p.x);
	float rays = pow(max(0.0, sin(ang * 14.0 + TIME * 0.3)), 18.0) * (1.0 - smoothstep(0.3, 0.9, length(p))) * (1.0 - lid);
	col += vec3(1.0, 0.6, 0.2) * rays * 0.12;

	// lignes de balayage + grain
	col *= 0.9 + 0.1 * step(0.5, fract(UV.y * px.y * 0.5));
	col += (hash(uv * 999.0 + fract(TIME)) - 0.5) * 0.05;
	vec2 d = UV - 0.5;
	col *= 1.0 - dot(d, d) * 1.3;
	COLOR = vec4(col, 1.0);
}
"""


func _ready() -> void:
	Input.mouse_mode = Input.MOUSE_MODE_VISIBLE
	Sfx.stop_all()
	Sfx.loop("music", "music_menu", -4.0, true)
	set_anchors_preset(Control.PRESET_FULL_RECT)

	var bg := ColorRect.new()
	bg.set_anchors_preset(Control.PRESET_FULL_RECT)
	bg.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var sh := Shader.new()
	sh.code = BG_SHADER
	bg_mat = ShaderMaterial.new()
	bg_mat.shader = sh
	bg.material = bg_mat
	add_child(bg)

	_build_stage()

	var box := VBoxContainer.new()
	box.position = Vector2(110, 105)
	box.custom_minimum_size = Vector2(700, 0)
	box.add_theme_constant_override("separation", 10)
	add_child(box)

	title = _label(box, "GOD IS AN AI", 92, ORANGE)
	title.add_theme_font_override("font", Loc.font("title"))
	title.add_theme_color_override("font_shadow_color", Color(0.4, 0.1, 0.0, 0.8))
	title.add_theme_constant_override("shadow_offset_x", 5)
	title.add_theme_constant_override("shadow_offset_y", 5)
	sub = _label(box, "", 22, ORANGE_DIM)
	var gap := Control.new()
	gap.custom_minimum_size = Vector2(0, 28)
	box.add_child(gap)

	for id in ["solo", "weekly", "coop", "career", "stream", "options", "quit"]:
		var b := _button(box, id)
		btns[id] = b

	crash_lbl = _label(box, "", 18, Color(1.0, 0.35, 0.25))
	crash_lbl.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	crash_lbl.custom_minimum_size = Vector2(700, 0)

	hint = _label(self, "", 16, ORANGE_DIM)
	hint.anchor_top = 1.0
	hint.anchor_bottom = 1.0
	hint.offset_left = 110
	hint.offset_top = -42
	hint.offset_right = 1400

	Loc.language_changed.connect(_refresh)
	_refresh()
	menu_box = box
	if Net.active:
		Net.leave()
	SteamNet.leave_lobby()
	SteamNet.presence("menu")
	SteamNet.invite_accepted.connect(_on_invite_accepted)
	_dev_net()


func _label(par: Node, text: String, size: int, col: Color) -> Label:
	var l := Label.new()
	l.text = text
	l.add_theme_font_size_override("font_size", size)
	l.add_theme_color_override("font_color", col)
	par.add_child(l)
	return l


func _button(par: Node, id: String) -> Button:
	var b := Button.new()
	b.alignment = HORIZONTAL_ALIGNMENT_LEFT
	b.flat = true
	b.focus_mode = Control.FOCUS_ALL
	b.add_theme_font_size_override("font_size", 32)
	b.add_theme_font_override("font", Loc.font("title"))
	b.add_theme_color_override("font_color", ORANGE)
	b.add_theme_color_override("font_hover_color", Color(1, 0.85, 0.6))
	b.add_theme_color_override("font_focus_color", Color(1, 0.85, 0.6))
	b.add_theme_color_override("font_disabled_color", Color(0.35, 0.2, 0.08))
	b.pressed.connect(_on_pressed.bind(id))
	b.mouse_entered.connect(Sfx.play.bind("ui_hover", -12.0, 1.0))
	b.pressed.connect(Sfx.play.bind("ui_click", -6.0, 1.0))
	b.mouse_entered.connect(b.grab_focus)
	b.focus_entered.connect(_refresh)
	par.add_child(b)
	return b


func _refresh() -> void:
	if loading:
		return
	sub.text = Loc.t("menu_sub")
	crash_lbl.text = Loc.t("menu_crashed") if Loc.crashed_last else Net.last_message
	hint.text = Loc.t("menu_hint")
	var nm: int = preload("res://scripts/believers.gd").mods_count
	if nm > 0:
		hint.text += "   ·   " + Loc.f("mods_loaded", [nm])
	var labels := {
		"solo": Loc.t("menu_solo"),
		"coop": Loc.t("menu_coop"),
		"lang": Loc.t("menu_lang"),
		"weekly": Loc.f("menu_weekly", [Game.weekly_best()]),
		"gfx": Loc.f("menu_gfx", [str(Loc.list("gfx")[Loc.quality])]),
		"sound": Loc.f("menu_sound", [str(Loc.list("sound_lv")[Loc.sound])]),
		"voice": Loc.f("menu_voice", [str(Loc.list("voice_modes")[Loc.voice_mode])]),
		"quit": Loc.t("menu_quit"),
		"options": Loc.t("menu_options"),
		"career": Loc.t("menu_career") + "  (" + Loc.f("car_lvl_short", [Profile.level()]) + ")",
		"back": Loc.t("tw_close"),
		"echo": Loc.f("menu_echo", [str(Loc.list("on_off")[1 if Loc.echoes else 0])]),
		"stream": Loc.f("menu_stream", [("#" + Loc.twitch_channel) if Loc.twitch_channel != "" else Loc.t("tw_off")]),
	}
	for id in btns:
		var b: Button = btns[id]
		var mark := "> " if b.has_focus() else "  "
		b.text = mark + str(labels[id])


func _on_pressed(id: String) -> void:
	match id:
		"solo":
			_start(false)
		"weekly":
			_start(true)
		"coop":
			_open_lobby()
		"stream":
			_open_stream()
		"echo":
			Loc.echoes = not Loc.echoes
			Loc.save_settings()
			_refresh()
		"tw_connect":
			_tw_connect()
		"tw_disconnect":
			_tw_disconnect()
		"tw_streamer":
			_tw_streamer()
		"tw_close":
			_close_stream()
		"lang":
			Loc.cycle_lang()
		"gfx":
			Loc.cycle_quality()
			_refresh()
		"sound":
			Loc.cycle_sound()
			_refresh()
		"voice":
			Loc.cycle_voice()
			_refresh()
		"quit":
			get_tree().quit()
		"options":
			_open_options()
		"career":
			get_tree().change_scene_to_file("res://scenes/locker.tscn")


const Lobby := preload("res://scripts/lobby.gd")
var lobby = null
var menu_box: VBoxContainer


func _open_lobby() -> void:
	if lobby != null:
		return
	menu_box.visible = false
	lobby = Lobby.new()
	add_child(lobby)
	lobby.closed.connect(_on_lobby_closed)


const Options := preload("res://scripts/options.gd")
var options_panel = null


func _open_options() -> void:
	if options_panel != null:
		return
	menu_box.visible = false
	options_panel = Options.new()
	add_child(options_panel)
	options_panel.closed.connect(_on_options_closed)


var career_panel = null


func _open_career() -> void:
	if career_panel != null:
		return
	menu_box.visible = false
	career_panel = preload("res://scripts/career.gd").new()
	add_child(career_panel)
	career_panel.closed.connect(_on_career_closed)
	career_panel.look_changed.connect(_refresh_me)


func _on_career_closed() -> void:
	career_panel = null
	menu_box.visible = true
	_refresh()
	btns["career"].grab_focus()


## Le personnage du centre, c'est TOI (avec tes accessoires).
func _refresh_me() -> void:
	if crew.size() < 3:
		return
	var old: Node3D = crew[2]
	var c := Character.new()
	old.get_parent().add_child(c)
	c.build(Profile.my_look(), "stand")
	c.position = old.position
	c.rotation = old.rotation
	c.anim_speed = 1.0
	crew[2] = c
	old.queue_free()
	c.emote("dance")


func _on_options_closed() -> void:
	options_panel = null
	menu_box.visible = true
	_refresh()
	btns["options"].grab_focus()


func _on_invite_accepted() -> void:
	if stream_panel != null:
		_close_stream()
	_open_lobby()


func _on_lobby_closed() -> void:
	lobby = null
	menu_box.visible = true


var stream_panel: PanelContainer = null
var tw_edit: LineEdit
var tw_status: Label
var tw_streamer_btn: Button


func _open_stream() -> void:
	if stream_panel != null:
		return
	menu_box.visible = false
	stream_panel = PanelContainer.new()
	var sb := StyleBoxFlat.new()
	sb.bg_color = Color(0.03, 0.015, 0.05, 0.95)
	sb.border_color = Color(0.57, 0.27, 1.0)
	sb.set_border_width_all(2)
	sb.set_content_margin_all(22)
	stream_panel.add_theme_stylebox_override("panel", sb)
	stream_panel.position = Vector2(110, 150)
	stream_panel.custom_minimum_size = Vector2(760, 0)
	add_child(stream_panel)
	var v := VBoxContainer.new()
	v.add_theme_constant_override("separation", 14)
	stream_panel.add_child(v)
	var ttl := _label(v, Loc.t("tw_title"), 52, Color(0.75, 0.55, 1.0))
	ttl.add_theme_font_override("font", Loc.font("title"))
	var ex := _label(v, Loc.t("tw_explain"), 18, Color(0.85, 0.8, 0.95))
	ex.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	ex.custom_minimum_size = Vector2(710, 0)
	tw_edit = LineEdit.new()
	tw_edit.placeholder_text = Loc.t("tw_channel_ph")
	tw_edit.text = Loc.twitch_channel
	tw_edit.add_theme_font_size_override("font_size", 26)
	tw_edit.custom_minimum_size = Vector2(0, 50)
	tw_edit.text_submitted.connect(_tw_connect_text)
	v.add_child(tw_edit)
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 20)
	v.add_child(row)
	var bc := _button(row, "tw_connect")
	bc.text = "  " + Loc.t("tw_connect")
	var bd := _button(row, "tw_disconnect")
	bd.text = "  " + Loc.t("tw_disconnect")
	tw_streamer_btn = _button(v, "tw_streamer")
	tw_status = _label(v, "", 18, Color(0.6, 1.0, 0.7))
	tw_status.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	tw_status.custom_minimum_size = Vector2(710, 0)
	var bb := _button(v, "tw_close")
	bb.text = "  " + Loc.t("tw_close")
	if not Stream.status.is_connected(_tw_status):
		Stream.status.connect(_tw_status)
	_tw_refresh()
	tw_edit.grab_focus.call_deferred()


func _tw_refresh() -> void:
	if tw_streamer_btn != null:
		tw_streamer_btn.text = "  " + Loc.f("tw_streamer", [str(Loc.list("on_off")[1 if Loc.streamer_mode else 0])])
	if tw_status != null:
		if Stream.connected:
			tw_status.text = Loc.f("tw_on", [Stream.channel])
		elif Stream.channel != "":
			tw_status.text = Loc.f("tw_connecting", [Stream.channel])
		else:
			tw_status.text = ""


func _tw_status(text: String) -> void:
	if tw_status != null and is_instance_valid(tw_status):
		tw_status.text = text


func _tw_connect_text(_t: String) -> void:
	_tw_connect()


func _tw_connect() -> void:
	var c := tw_edit.text.strip_edges().to_lower().trim_prefix("#").replace("https://www.twitch.tv/", "").replace("twitch.tv/", "")
	Loc.twitch_channel = c
	Loc.save_settings()
	if c == "":
		Stream.stop()
	else:
		Stream.start(c)
	_tw_refresh()


func _tw_disconnect() -> void:
	Loc.twitch_channel = ""
	Loc.save_settings()
	Stream.stop()
	tw_edit.text = ""
	_tw_refresh()


func _tw_streamer() -> void:
	Loc.streamer_mode = not Loc.streamer_mode
	Loc.save_settings()
	_tw_refresh()


func _close_stream() -> void:
	if stream_panel != null:
		stream_panel.queue_free()
	stream_panel = null
	tw_status = null
	tw_streamer_btn = null
	menu_box.visible = true
	_refresh()


func _dev_net() -> void:
	# tests a plusieurs instances : --host / --join=IP / --name=X / --autostart=N
	var a := {}
	for arg in OS.get_cmdline_user_args():
		var s2 := str(arg).trim_prefix("--")
		var i := s2.find("=")
		a[s2.substr(0, i) if i >= 0 else s2] = s2.substr(i + 1) if i >= 0 else "1"
	if a.has("options"):
		_open_options()
	if a.has("career"):
		_open_career()
	if a.has("locker"):
		get_tree().change_scene_to_file.call_deferred("res://scenes/locker.tscn")
	if a.has("streampanel"):
		_open_stream()
	if a.has("host") or a.has("join"):
		_open_lobby()
		if a.has("name"):
			lobby.name_edit.text = str(a["name"])
		if a.has("host"):
			lobby._on_host()
		else:
			lobby.ip_edit.text = str(a["join"])
			lobby._on_join()
	if a.has("autostart") and Net.active and multiplayer.is_server():
		while Net.players.size() < int(a["autostart"]):
			await get_tree().create_timer(0.3).timeout
		await get_tree().create_timer(0.5).timeout
		Net.start_game(false, a.has("satan"))


func _start(weekly: bool) -> void:
	loading = true
	Game.new_run(weekly)
	Loc.set_loading(true)
	for id in btns:
		btns[id].disabled = true
	sub.text = Loc.t("menu_loading")
	await get_tree().process_frame
	await get_tree().process_frame
	get_tree().change_scene_to_file("res://main.tscn")


const Character := preload("res://scripts/character.gd")
var stage_vp: SubViewport
var stage_cam: Camera3D
var eye_mat: ShaderMaterial
var crew := []


func _build_stage() -> void:
	# l'equipe (pack de personnages) devant l'oeil de G.O.D.
	var svc := SubViewportContainer.new()
	svc.stretch = true
	svc.anchor_left = 0.42
	svc.anchor_right = 1.0
	svc.anchor_bottom = 1.0
	svc.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(svc)
	stage_vp = SubViewport.new()
	stage_vp.own_world_3d = true
	stage_vp.transparent_bg = true
	stage_vp.msaa_3d = Viewport.MSAA_4X
	svc.add_child(stage_vp)
	# fondu entre le menu et la scene 3D
	var fade := TextureRect.new()
	var gt := GradientTexture2D.new()
	var g := Gradient.new()
	g.set_color(0, Color(0.02, 0.018, 0.015, 1.0))
	g.set_color(1, Color(0.02, 0.018, 0.015, 0.0))
	gt.gradient = g
	gt.fill_from = Vector2(0, 0)
	gt.fill_to = Vector2(1, 0)
	gt.width = 256
	gt.height = 4
	fade.texture = gt
	fade.stretch_mode = TextureRect.STRETCH_SCALE
	fade.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	fade.anchor_left = 0.42
	fade.anchor_right = 0.56
	fade.anchor_bottom = 1.0
	fade.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(fade)
	var root := Node3D.new()
	stage_vp.add_child(root)
	var we := WorldEnvironment.new()
	var e := Environment.new()
	e.background_mode = Environment.BG_CLEAR_COLOR
	e.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	e.ambient_light_color = Color(0.5, 0.45, 0.45)
	e.ambient_light_energy = 0.35
	e.tonemap_mode = Environment.TONE_MAPPER_ACES
	e.glow_enabled = true
	e.glow_intensity = 0.8
	we.environment = e
	root.add_child(we)
	stage_cam = Camera3D.new()
	stage_cam.position = Vector3(0.3, 1.45, 6.6)
	stage_cam.fov = 34
	root.add_child(stage_cam)
	stage_cam.look_at(Vector3(0.3, 1.15, 0), Vector3.UP)
	var eye := MeshInstance3D.new()
	var qm := QuadMesh.new()
	qm.size = Vector2(5.2, 3.5)
	eye.mesh = qm
	eye_mat = ShaderMaterial.new()
	eye_mat.shader = load("res://shaders/god_eye.gdshader")
	eye.material_override = eye_mat
	eye.position = Vector3(0, 1.9, -2.4)
	root.add_child(eye)
	var rim := OmniLight3D.new()
	rim.position = Vector3(0, 1.8, -1.6)
	rim.light_color = Color(1.0, 0.5, 0.15)
	rim.light_energy = 2.5
	rim.omni_range = 5.0
	root.add_child(rim)
	var key := SpotLight3D.new()
	key.position = Vector3(-1.8, 3.0, 2.8)
	key.light_energy = 3.0
	key.spot_range = 9.0
	key.spot_angle = 35.0
	key.shadow_enabled = true
	root.add_child(key)
	key.look_at(Vector3(0, 1, 0), Vector3.UP)
	var fl := MeshInstance3D.new()
	var pm := PlaneMesh.new()
	pm.size = Vector2(12, 8)
	fl.mesh = pm
	var fm := StandardMaterial3D.new()
	fm.albedo_color = Color(0.08, 0.06, 0.05)
	fm.roughness = 0.3
	fl.material_override = fm
	root.add_child(fl)
	var rng := RandomNumberGenerator.new()
	rng.randomize()
	for i in 5:
		var c := Character.new()
		root.add_child(c)
		var ids: Array = Character.PRESET_ORDER.duplicate()
		ids.erase(str(Profile.my_look().get("preset", "")))
		c.build(Character.preset(str(ids[(i * 3 + 1) % ids.size()])), "stand")
		c.position = Vector3(-1.5 + float(i) * 0.75, 0.78, -0.2 + abs(float(i) - 2.0) * 0.25)
		c.rotation.y = PI + (float(i) - 2.0) * -0.12
		c.anim_speed = rng.randf_range(0.8, 1.2)
		crew.append(c)
	_refresh_me()


func _tick_stage() -> void:
	if stage_cam == null:
		return
	var vs := get_viewport_rect().size
	var m := get_viewport().get_mouse_position() / vs
	var target := Vector3((m.x - 0.71) * 6.0, 2.2 - m.y * 2.4, 3.0)
	eye_mat.set_shader_parameter("look", Vector2(clamp((m.x - 0.71) * 3.0, -1.0, 1.0), clamp((0.45 - m.y) * 2.0, -1.0, 1.0)))
	eye_mat.set_shader_parameter("blink", 1.0 if fmod(t, 5.3) > 5.15 else 0.0)
	for c in crew:
		c.look_point = target
	if randf() < 0.012 and not crew.is_empty():
		var who = crew[randi() % crew.size()]
		who.say(randf_range(0.8, 2.0))
		if randf() < 0.5:
			who.emote(["wave", "dance", "laugh", "flex", "facepalm"][randi() % 5])
		else:
			who.set_emotion(["happy", "worried", "shock", "love", "fury", "laugh"][randi() % 6])


func _process(dt: float) -> void:
	t += dt
	_tick_stage()
	var vs := get_viewport_rect().size
	var m := get_viewport().get_mouse_position() / vs
	bg_mat.set_shader_parameter("eye", m)
	bg_mat.set_shader_parameter("res", vs)
	# clignement
	var cyc := fmod(t, 5.3)
	bg_mat.set_shader_parameter("blink", 0.05 if cyc > 5.15 else 1.0)
	# titre qui gresille
	title.modulate.a = 0.55 if randf() < 0.03 else 1.0
	if loading:
		sub.modulate.a = 0.5 + 0.5 * sin(t * 10.0)
