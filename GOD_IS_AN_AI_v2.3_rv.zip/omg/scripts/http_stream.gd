extends Node
## Requete HTTP(S) en STREAMING : les octets arrivent au fur et a mesure
## (au lieu d'attendre la reponse complete comme HTTPRequest).
## Sert a : la reponse de l'IA (SSE, le texte s'affiche pendant qu'il s'ecrit)
## et la voix des fideles (PCM qui commence a jouer des le premier morceau).

signal got_headers(code: int)
signal chunk(data: PackedByteArray)
signal finished(code: int, ok: bool)

var client := HTTPClient.new()
var state := 0           # 0 libre, 1 connexion, 2 requete, 3 lecture
var host := ""
var port := 443
var path := "/"
var tls := true
var req_headers := PackedStringArray()
var req_body := PackedByteArray()
var code := 0
var t := 0.0
var timeout := 30.0
var body_all := PackedByteArray()   # garde le corps (pour les messages d'erreur)


func busy() -> bool:
	return state != 0


func start(url: String, headers: PackedStringArray, body: PackedByteArray) -> bool:
	cancel()
	var u := url
	tls = u.begins_with("https://")
	u = u.trim_prefix("https://").trim_prefix("http://")
	var slash := u.find("/")
	var hp := u if slash < 0 else u.substr(0, slash)
	path = "/" if slash < 0 else u.substr(slash)
	port = 443 if tls else 80
	if hp.contains(":"):
		port = int(hp.get_slice(":", 1))
		hp = hp.get_slice(":", 0)
	host = hp
	req_headers = headers
	req_body = body
	code = 0
	t = 0.0
	body_all = PackedByteArray()
	client = HTTPClient.new()
	client.read_chunk_size = 4096
	var err := client.connect_to_host(host, port, TLSOptions.client() if tls else null)
	if err != OK:
		return false
	state = 1
	return true


func cancel() -> void:
	if state != 0:
		client.close()
	state = 0


func _fail(c: int) -> void:
	client.close()
	state = 0
	finished.emit(c, false)


func _process(dt: float) -> void:
	if state == 0:
		return
	t += dt / maxf(0.01, Engine.time_scale)
	if t > timeout:
		_fail(408)
		return
	client.poll()
	var st := client.get_status()
	match state:
		1:
			if st == HTTPClient.STATUS_CONNECTED:
				var err := client.request_raw(HTTPClient.METHOD_POST, path, req_headers, req_body)
				if err != OK:
					_fail(0)
					return
				state = 2
			elif st in [HTTPClient.STATUS_CANT_CONNECT, HTTPClient.STATUS_CANT_RESOLVE, HTTPClient.STATUS_CONNECTION_ERROR, HTTPClient.STATUS_TLS_HANDSHAKE_ERROR]:
				_fail(0)
		2:
			if st == HTTPClient.STATUS_BODY or st == HTTPClient.STATUS_CONNECTED:
				code = client.get_response_code()
				got_headers.emit(code)
				state = 3
				if st == HTTPClient.STATUS_CONNECTED:     # pas de corps
					client.close()
					state = 0
					finished.emit(code, code == 200)
			elif st in [HTTPClient.STATUS_CONNECTION_ERROR, HTTPClient.STATUS_DISCONNECTED]:
				_fail(0)
		3:
			# plusieurs morceaux par image si disponibles
			for i in 16:
				if client.get_status() != HTTPClient.STATUS_BODY:
					break
				var c := client.read_response_body_chunk()
				if c.size() == 0:
					break
				t = 0.0
				if body_all.size() < 4096:
					body_all.append_array(c.slice(0, 4096 - body_all.size()))
				if code == 200:
					chunk.emit(c)
					if state == 0:
						return        # annule par celui qui ecoute
				client.poll()
			if client.get_status() != HTTPClient.STATUS_BODY:
				client.close()
				state = 0
				finished.emit(code, code == 200)
