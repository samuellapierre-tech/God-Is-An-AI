extends PanelContainer
## CARRIERE : niveau, experience et succes. (La tenue se choisit au vestiaire.)

signal closed
signal look_changed

const ORANGE := Color(1.0, 0.55, 0.16)
const DIM := Color(0.5, 0.32, 0.16)
const PALE := Color(1.0, 0.86, 0.66)
const BLUE := Color(0.55, 0.85, 1.0)



func _ready() -> void:
	var sb := StyleBoxFlat.new()
	sb.bg_color = Color(0.03, 0.02, 0.015, 0.95)
	sb.border_color = ORANGE
	sb.set_border_width_all(2)
	sb.set_content_margin_all(22)
	add_theme_stylebox_override("panel", sb)
	position = Vector2(60, 60)
	custom_minimum_size = Vector2(820, 780)
	var v := VBoxContainer.new()
	v.add_theme_constant_override("separation", 8)
	add_child(v)
	_lbl(v, Loc.t("car_title"), 44, ORANGE, "title")
	_lbl(v, Loc.f("car_level", [Profile.level(), Profile.title()]), 24, BLUE, "bold")
	var bar := ProgressBar.new()
	bar.max_value = 1.0
	bar.value = Profile.progress()
	bar.show_percentage = false
	bar.custom_minimum_size = Vector2(0, 16)
	var fill := StyleBoxFlat.new()
	fill.bg_color = Color(0.4, 0.75, 1.0)
	bar.add_theme_stylebox_override("fill", fill)
	var bgs := StyleBoxFlat.new()
	bgs.bg_color = Color(0.1, 0.12, 0.16)
	bar.add_theme_stylebox_override("background", bgs)
	v.add_child(bar)
	var l := Profile.level()
	_lbl(v, Loc.f("car_xp", [Profile.xp, Profile.xp_for(l + 1)]) + "     " + Loc.f("car_stats", [int(Profile.totals.get("conversions", 0)), int(Profile.totals.get("weeks", 0)), int(Profile.totals.get("hoops", 0))]), 15, DIM)

	_lbl(v, Loc.f("car_achs", [Profile.ach.size(), Profile.ACHS.size()]), 22, ORANGE, "title")
	var sc := ScrollContainer.new()
	sc.size_flags_vertical = Control.SIZE_EXPAND_FILL
	sc.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	v.add_child(sc)
	var ag := GridContainer.new()
	ag.columns = 2
	ag.add_theme_constant_override("h_separation", 20)
	sc.add_child(ag)
	for a in Profile.ACHS:
		var got := Profile.ach.has(a)
		var txt := ("[X] " if got else "[ ] ") + Loc.t("ach_" + a)
		var al := _lbl(ag, txt, 14, Color(0.6, 1.0, 0.65) if got else Color(0.45, 0.4, 0.36))
		al.custom_minimum_size = Vector2(380, 0)

	var back := _btn(v, Loc.t("tw_close"))
	back.custom_minimum_size = Vector2(0, 46)
	back.add_theme_font_override("font", Loc.font("title"))
	back.add_theme_font_size_override("font_size", 24)
	back.pressed.connect(_close)
	_refresh()
	back.grab_focus.call_deferred()


func _lbl(par: Node, text: String, size: int, col: Color, font := "mono") -> Label:
	var l := Label.new()
	l.text = text
	l.add_theme_font_override("font", Loc.font(font))
	l.add_theme_font_size_override("font_size", size)
	l.add_theme_color_override("font_color", col)
	par.add_child(l)
	return l


func _btn(par: Node, text: String) -> Button:
	var b := Button.new()
	b.text = text
	b.custom_minimum_size = Vector2(44, 38)
	b.add_theme_font_override("font", Loc.font("bold"))
	b.add_theme_font_size_override("font_size", 16)
	b.add_theme_color_override("font_color", Color(1.0, 0.7, 0.35))
	b.add_theme_color_override("font_disabled_color", Color(0.38, 0.3, 0.24))
	b.pressed.connect(Sfx.play.bind("ui_click", -6.0, 1.0))
	par.add_child(b)
	return b


func _refresh() -> void:
	pass


func _close() -> void:
	closed.emit()
	queue_free()


func _unhandled_input(e: InputEvent) -> void:
	if e.is_action_pressed("ui_cancel"):
		get_viewport().set_input_as_handled()
		_close()
