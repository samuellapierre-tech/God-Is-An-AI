extends Node
## FOUS RIRES : gifles, poulet en caoutchouc, onomatopees de BD, confettis,
## humeurs absurdes (tetes enormes, journee helium). Rien de serieux ici.

const POP_COLORS := [Color(1.0, 0.85, 0.15), Color(1.0, 0.35, 0.3), Color(0.4, 0.9, 1.0), Color(1.0, 0.5, 0.9), Color(0.5, 1.0, 0.45)]

var main: Node
var slap_cd := 0.0
var npc_slaps := {}         # pod -> nombre de gifles recues de moi
var flying := []            # [poulet, temps restant, deja_bonk]
var last_mood := "?"
var danced := false
var disco_on := false
var disco_root: Node3D = null
var disco_pools: Node3D = null
var disco_t := 0.0
var roll := 0.0             # camera qui penche apres une gifle


func _process(dt: float) -> void:
	slap_cd -= dt
	if Game.mood != last_mood:
		last_mood = Game.mood
		_apply_mood()
	_tick_flying(dt)
	_tick_disco(dt)
	_tick_shame(dt)
	_tick_gags()
	if roll != 0.0 and main.cam != null:
		roll = move_toward(roll, 0.0, dt * 0.8)
		main.cam.rotation.z = sin(roll * 9.0) * roll * 0.35


# ------------------------------------------------------------- gags de webcam pendant les appels

const GAGS := ["upside", "nose", "filter", "freeze", "sneeze"]
var gag_for := -1.0
var gag_at := -1.0


func _tick_gags() -> void:
	if not main.in_call:
		return
	if main.call_t0 != gag_for:
		gag_for = main.call_t0
		var chance := 0.9 if Dev.args.has("gags") else 0.45
		gag_at = main.t + randf_range(7.0, 22.0) if randf() < chance else -1.0
	if gag_at > 0.0 and main.t > gag_at:
		gag_at = -1.0
		var id: String = GAGS[randi() % GAGS.size()]
		if main.callview != null:
			main.callview.gag(id)
		main._call_net("fx", "gag_" + id)
		main._log(Loc.t("gag_tag"), Loc.t("gag_" + id), "#ffd166")
		if not main.busy:
			main._ask_ai(main.EVENT_TAG + Loc.f("mk_event", [Loc.t("gag_ai_" + id)]))
		if Dev.args.has("autoplay"):
			print("GAG ", id)


# ------------------------------------------------------------- onomatopees

## « PAF ! » « BONK ! » « PROUT ! » en 3D, facon bande dessinee.
func pop(pos: Vector3, text: String, col := Color(-1, 0, 0), size := 120) -> void:
	var l := Label3D.new()
	l.text = text
	l.font = Loc.font("title")
	l.font_size = size
	var cam: Camera3D = main.cam
	var dist := cam.global_position.distance_to(pos) if cam != null else 4.0
	l.pixel_size = 0.0032 * clampf(dist / 4.0, 0.3, 1.2)
	l.modulate = col if col.r >= 0.0 else POP_COLORS[randi() % POP_COLORS.size()]
	l.outline_size = 28
	l.outline_modulate = Color(0.08, 0.02, 0.0)
	l.billboard = BaseMaterial3D.BILLBOARD_ENABLED
	l.no_depth_test = true
	l.render_priority = 10
	l.outline_render_priority = 9
	main.add_child(l)
	l.global_position = pos
	l.rotation_degrees.z = randf_range(-14.0, 14.0)
	l.scale = Vector3.ONE * 0.2
	var tw := l.create_tween()
	tw.tween_property(l, "scale", Vector3.ONE * 1.25, 0.12).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)
	tw.tween_property(l, "scale", Vector3.ONE, 0.1)
	tw.parallel().tween_property(l, "position:y", l.position.y + 0.5, 1.1)
	tw.tween_property(l, "modulate:a", 0.0, 0.35)
	tw.tween_callback(l.queue_free)


# ------------------------------------------------------------- cibles (collegues et amis)

## Toutes les tetes du bureau : [kind, id, Character, position de la tete]
func _targets() -> Array:
	var out := []
	for id in main.avatars:
		var d: Dictionary = main.avatars[id]
		var c = d["char"]
		if c != null and is_instance_valid(c) and c.head != null:
			out.append(["peer", int(id), c, (c.head as Node3D).global_position])
	for d in main.npcs:
		var c2 = d["char"]
		if c2 != null and is_instance_valid(c2) and c2.head != null:
			out.append(["npc", int(d["pod"]), c2, (c2.head as Node3D).global_position])
	if main.intern != null and main.intern.c != null:
		out.append(["intern", 0, main.intern.c, main.intern.head_pos()])
	return out


func _find(kind: String, id: int) -> Array:
	for tg in _targets():
		if str(tg[0]) == kind and int(tg[1]) == id:
			return tg
	return []


# ------------------------------------------------------------- la gifle [X]

func try_slap() -> void:
	if slap_cd > 0.0 or main.seated or main.frozen:
		return
	slap_cd = 0.7
	var cam: Camera3D = main.cam
	var fwd := -cam.global_transform.basis.z
	var best: Array = []
	var best_d := 2.3
	for tg in _targets():
		var to: Vector3 = (tg[3] as Vector3) - cam.global_position
		var dist := to.length()
		if dist < best_d and fwd.dot(to.normalized()) > 0.45:
			best = tg
			best_d = dist
	Sfx.play("swish", -6.0, 1.6)
	if best.is_empty():
		main._say(Loc.pick("slap_air"), 1.5)
		return
	do_slap(best)


func do_slap(best: Array) -> void:
	if main.fp_hands != null:
		main.fp_hands.punch()
	_slap_fx(best)
	if randf() < 0.25:
		main._god(Loc.pick("god_slap"))
	Profile.unlock("slap")
	main._stat("slaps")
	if Net.active:
		main.sync.bcast(&"action", ["slap", {"k": best[0], "id": best[1]}])
	if str(best[0]) == "npc":
		var pod := int(best[1])
		npc_slaps[pod] = int(npc_slaps.get(pod, 0)) + 1
		for d in main.npcs:
			if int(d["pod"]) == pod:
				var bub: Label3D = d["bub"]
				bub.text = Loc.pick("cw_slapped")
				d["say"] = 3.5
		if int(npc_slaps[pod]) >= 3:
			# le collegue en a assez : il riposte !
			npc_slaps[pod] = 0
			get_tree().create_timer(0.9).timeout.connect(_get_slapped.bind(Loc.f("slap_back", [str(main.WHO[pod])])))


func _slap_fx(tg: Array) -> void:
	var c = tg[2]
	if str(tg[0]) == "intern":
		main.intern.say(Loc.pick("intern_hit"), 3.0)
	var hp: Vector3 = tg[3]
	c.slapped()
	Sfx.play_at("slap", hp, 2.0)
	pop(hp + Vector3(0, 0.35, 0), Loc.pick("pop_slap"), Color(1.0, 0.3, 0.25))
	main.cam_shake = maxf(main.cam_shake, 0.25)
	main.viral.highlight("slap")


## Recu du reseau : quelqu'un a gifle quelqu'un.
func net_slap(from: int, data: Dictionary) -> void:
	var k := str(data.get("k", ""))
	var id := int(data.get("id", 0))
	var who := str(Net.players.get(from, {}).get("name", "?"))
	if k == "peer" and id == Net.my_id():
		_get_slapped(Loc.f("slap_you", [who]))
		return
	var tg := _find(k, id)
	if not tg.is_empty():
		var c = tg[2]
		c.slapped()
		Sfx.play_at("slap", tg[3], 2.0)
		pop((tg[3] as Vector3) + Vector3(0, 0.35, 0), Loc.pick("pop_slap"), Color(1.0, 0.3, 0.25))


func _get_slapped(msg: String) -> void:
	Sfx.play("slap", 2.0)
	Sfx.play("boing", -6.0, 0.8)
	roll = 1.0
	main.cam_shake = 0.9
	main.vignette.color = Color(1, 1, 1, 0.55)
	main._say(msg, 3.0)
	var cam: Camera3D = main.cam
	pop(cam.global_position - cam.global_transform.basis.z * 1.2, Loc.pick("pop_slap"), Color(1.0, 0.3, 0.25), 160)
	main.viral.highlight("slapped")


# ------------------------------------------------------------- poulet en caoutchouc

func make_chicken(pos: Vector3) -> RigidBody3D:
	var rb: RigidBody3D = main._prop(pos, Vector3(0.3, 0.12, 0.12), Color(1, 0.85, 0.2), 0.25, Loc.t("prop_chicken"))
	for ch in rb.get_children():
		if ch is MeshInstance3D:
			ch.visible = false
	var yel := StandardMaterial3D.new()
	yel.albedo_color = Color(1.0, 0.86, 0.15)
	yel.roughness = 0.3
	yel.rim_enabled = true
	var red := StandardMaterial3D.new()
	red.albedo_color = Color(0.95, 0.15, 0.1)
	var ora := StandardMaterial3D.new()
	ora.albedo_color = Color(1.0, 0.5, 0.1)
	var blk := StandardMaterial3D.new()
	blk.albedo_color = Color(0.05, 0.05, 0.05)
	var body := MeshInstance3D.new()
	var cap := CapsuleMesh.new()
	cap.radius = 0.05
	cap.height = 0.3
	body.mesh = cap
	body.material_override = yel
	body.rotation_degrees = Vector3(0, 0, 90)
	rb.add_child(body)
	var head := MeshInstance3D.new()
	var hs := SphereMesh.new()
	hs.radius = 0.045
	hs.height = 0.09
	head.mesh = hs
	head.material_override = yel
	head.position = Vector3(0.16, 0.04, 0)
	rb.add_child(head)
	var comb := MeshInstance3D.new()
	var cb := BoxMesh.new()
	cb.size = Vector3(0.05, 0.035, 0.012)
	comb.mesh = cb
	comb.material_override = red
	comb.position = Vector3(0.16, 0.09, 0)
	rb.add_child(comb)
	var beak := MeshInstance3D.new()
	var bk := PrismMesh.new()
	bk.size = Vector3(0.03, 0.04, 0.03)
	beak.mesh = bk
	beak.material_override = ora
	beak.position = Vector3(0.21, 0.035, 0)
	beak.rotation_degrees = Vector3(0, 0, -90)
	rb.add_child(beak)
	for sz in [-1.0, 1.0]:
		var eye := MeshInstance3D.new()
		var es := SphereMesh.new()
		es.radius = 0.008
		es.height = 0.016
		eye.mesh = es
		eye.material_override = blk
		eye.position = Vector3(0.18, 0.06, sz * 0.03)
		rb.add_child(eye)
	rb.set_meta("chicken", true)
	return rb


## Clic droit en tenant le poulet.
func squeeze(at: Vector3) -> void:
	Sfx.play_at("squeak", at, 0.0, randf_range(0.85, 1.25))
	pop(at + Vector3(0, 0.3, 0), Loc.pick("pop_squeak"), Color(1.0, 0.9, 0.2), 90)
	if Net.active:
		main.sync.bcast(&"action", ["squeak", at])


func net_squeak(at: Vector3) -> void:
	Sfx.play_at("squeak", at, 0.0, randf_range(0.85, 1.25))
	pop(at + Vector3(0, 0.3, 0), Loc.pick("pop_squeak"), Color(1.0, 0.9, 0.2), 90)


## Appele quand on lance le poulet : on surveille s'il touche une tete.
func thrown(rb: RigidBody3D) -> void:
	flying.append([rb, 2.5, false, rb.global_position])


## Aide a la visee : si une tete est presque dans la mire, le lancer fait une
## belle courbe jusqu'a elle (sinon : lancer normal). Renvoie la vitesse.
func aim_velocity(from: Vector3, dir: Vector3, power: float) -> Vector3:
	var best: Array = []
	var best_dot := 0.975
	for tg in _targets():
		var to: Vector3 = (tg[3] as Vector3) - from
		var dist := to.length()
		if dist < 1.0 or dist > 22.0:
			continue
		var d := dir.dot(to.normalized())
		if d > best_dot:
			best_dot = d
			best = tg
	if best.is_empty():
		return Vector3.ZERO
	var target: Vector3 = (best[3] as Vector3) + Vector3(0, 0.05, 0)
	var delta := target - from
	var flat := Vector2(delta.x, delta.z).length()
	var tt := clampf(flat / maxf(power, 6.0), 0.15, 1.6)
	var g := 9.8
	var v := Vector3(delta.x / tt, delta.y / tt + 0.5 * g * tt, delta.z / tt)
	return v


func _tick_flying(dt: float) -> void:
	var keep := []
	for f in flying:
		if not is_instance_valid(f[0]):
			continue
		var rb: RigidBody3D = f[0]
		f[1] = float(f[1]) - dt
		if float(f[1]) <= 0.0 or bool(f[2]):
			continue
		for tg in _targets():
			if rb.global_position.distance_to(tg[3]) < 0.5:
				f[2] = true
				if rb.has_meta("chicken"):
					_bonk_fx(tg)
					Profile.unlock("bonk")
					if Net.active:
						main.sync.bcast(&"action", ["bonk", {"k": tg[0], "id": tg[1]}])
				else:
					main.delivery.hit(rb, tg, (f[3] as Vector3).distance_to(rb.global_position))
				rb.linear_velocity = Vector3(randf_range(-2, 2), 2.5, randf_range(-2, 2))
				break
		keep.append(f)
	flying = keep


func _bonk_fx(tg: Array) -> void:
	var c = tg[2]
	if str(tg[0]) == "intern":
		main.intern.say(Loc.pick("intern_hit"), 3.0)
	c.daze(3.0)
	c.bounce = 1.0
	Sfx.play_at("bonk", tg[3], 2.0)
	Sfx.play_at("squeak", tg[3], -2.0, 0.8)
	pop((tg[3] as Vector3) + Vector3(0, 0.4, 0), Loc.pick("pop_bonk"), Color(0.4, 0.9, 1.0))
	main.viral.highlight("bonk")


func net_bonk(data: Dictionary) -> void:
	var k := str(data.get("k", ""))
	var id := int(data.get("id", 0))
	if k == "peer" and id == Net.my_id():
		Sfx.play("bonk", 2.0)
		roll = 0.6
		main.cam_shake = 0.6
		main._say(Loc.t("bonk_you"), 2.5)
		return
	var tg := _find(k, id)
	if not tg.is_empty():
		_bonk_fx(tg)


# ------------------------------------------------------------- confettis

func confetti(at: Vector3) -> void:
	var p := GPUParticles3D.new()
	p.amount = 140
	p.lifetime = 2.6
	p.one_shot = true
	p.explosiveness = 0.95
	var pm := ParticleProcessMaterial.new()
	pm.direction = Vector3(0, 1, 0)
	pm.spread = 55.0
	pm.initial_velocity_min = 3.5
	pm.initial_velocity_max = 7.0
	pm.gravity = Vector3(0, -5.5, 0)
	pm.damping_min = 1.5
	pm.damping_max = 3.0
	pm.angular_velocity_min = -720.0
	pm.angular_velocity_max = 720.0
	pm.color = Color(1.0, 0.35, 0.35)
	pm.hue_variation_min = -1.0
	pm.hue_variation_max = 1.0
	pm.scale_min = 0.6
	pm.scale_max = 1.3
	p.process_material = pm
	var q := QuadMesh.new()
	q.size = Vector2(0.06, 0.035)
	var qm := StandardMaterial3D.new()
	qm.vertex_color_use_as_albedo = true
	qm.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	qm.cull_mode = BaseMaterial3D.CULL_DISABLED
	qm.billboard_mode = BaseMaterial3D.BILLBOARD_PARTICLES
	q.material = qm
	p.draw_pass_1 = q
	main.add_child(p)
	p.global_position = at
	p.emitting = true
	get_tree().create_timer(3.5).timeout.connect(p.queue_free)


## Conversion reussie : confettis, kazoo, ALLELUIA !
func celebrate(pod: int, me: bool) -> void:
	var at: Vector3 = main.pod_pos[pod] + Vector3(0, 1.4, 0)
	confetti(at)
	Sfx.play_at("kazoo", at, -2.0 if me else -6.0)
	pop(at + Vector3(0, 0.8, 0), Loc.pick("pop_conv"), Color(1.0, 0.85, 0.2), 140)
	for d in main.npcs:
		if (d["hold"] as Node3D).global_position.distance_to(at) < 9.0:
			d["char"].emote(["dance", "chicken", "wave"][randi() % 3])


# ------------------------------------------------------------- chapeau de la honte

var shame := {}
var shame_t := 0.0
var mock_t := 20.0


func apply_shame(sh: Dictionary) -> void:
	for tg in _targets():
		tg[2].dunce(false)
	shame = sh
	main.shamed = false
	if sh.is_empty():
		return
	if str(sh["k"]) == "peer" and int(sh["id"]) == Net.my_id():
		main.shamed = true
		main._say(Loc.t("shame_today"), 6.0)
		Sfx.play("trombone", -6.0)


func _tick_shame(dt: float) -> void:
	if shame.is_empty():
		return
	shame_t -= dt
	if shame_t <= 0.0:
		shame_t = 1.0
		var tg := _find(str(shame["k"]), int(shame["id"]))
		if not tg.is_empty():
			tg[2].dunce(true)
	if main.shamed and not main.frozen:
		mock_t -= dt
		if mock_t <= 0.0:
			mock_t = randf_range(25.0, 45.0)
			for d in main.npcs:
				if (d["hold"] as Node3D).global_position.distance_to(main.player.global_position) < 7.0 and float(d["say"]) <= 0.0:
					var bub: Label3D = d["bub"]
					bub.text = Loc.pick("cw_mock")
					d["say"] = 3.5
					d["char"].set_emotion("laugh")
					break


# ------------------------------------------------------------- messe disco

func _tick_disco(dt: float) -> void:
	var want: bool = main.mass_left > 0.0 and main.mass_disco
	if want and not disco_on:
		_disco_start()
	elif disco_on and not want:
		_disco_stop()
	if not disco_on or disco_root == null:
		return
	disco_t += dt
	disco_root.rotation.y += dt * 1.2
	var pools := disco_pools
	if pools != null:
		pools.rotation.y -= dt * 0.7
		for q in pools.get_children():
			var pm := (q as MeshInstance3D).material_override as StandardMaterial3D
			pm.albedo_color = Color.from_hsv(fmod(disco_t * 0.3 + q.position.x * 0.05, 1.0), 0.9, 1.0)
	var k := 0
	for ch in disco_root.get_children():
		if ch is SpotLight3D:
			(ch as SpotLight3D).light_color = Color.from_hsv(fmod(disco_t * 0.35 + float(k) * 0.25, 1.0), 0.9, 1.0)
			k += 1
	if fmod(disco_t, 2.6) < dt:
		for d in main.npcs:
			if str(d["state"]) == "desk":
				d["char"].emote(["dance", "chicken", "tpose", "dance"][randi() % 4])


func _disco_start() -> void:
	disco_on = true
	disco_t = 0.0
	disco_root = Node3D.new()
	main.add_child(disco_root)
	disco_root.position = Vector3(0, 4.6, 3.4)
	var ball := MeshInstance3D.new()
	var sm := SphereMesh.new()
	sm.radius = 0.6
	sm.height = 1.2
	sm.radial_segments = 16
	sm.rings = 8
	ball.mesh = sm
	var bm := StandardMaterial3D.new()
	bm.albedo_color = Color(0.85, 0.85, 0.9)
	bm.metallic = 1.0
	bm.roughness = 0.08
	bm.emission_enabled = true
	bm.emission = Color(0.6, 0.6, 0.7)
	bm.emission_energy_multiplier = 0.8
	ball.material_override = bm
	disco_root.add_child(ball)
	for k in 4:
		var sp := SpotLight3D.new()
		sp.light_energy = 14.0
		sp.spot_range = 16.0
		sp.spot_angle = 22.0
		disco_root.add_child(sp)
		var a := TAU * float(k) / 4.0
		sp.look_at_from_position(Vector3.ZERO, Vector3(sin(a) * 6.0, -4.5, cos(a) * 6.0), Vector3.UP)
	# facettes de miroir qui scintillent
	for k in 40:
		var f := MeshInstance3D.new()
		var bx := BoxMesh.new()
		bx.size = Vector3(0.09, 0.09, 0.01)
		f.mesh = bx
		var fm := StandardMaterial3D.new()
		fm.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
		fm.albedo_color = Color.from_hsv(randf(), 0.4, 1.0)
		f.material_override = fm
		var dir := Vector3(randf_range(-1, 1), randf_range(-1, 1), randf_range(-1, 1)).normalized()
		ball.add_child(f)
		f.transform = Transform3D(Basis.looking_at(dir, Vector3.UP if absf(dir.y) < 0.95 else Vector3.RIGHT), dir * 0.61)
	# taches de lumiere coloree qui tournent sur le plancher
	var pools := Node3D.new()
	disco_pools = pools
	main.add_child(pools)
	pools.position = Vector3(0, 0.05, 0)
	for k in 7:
		var q := MeshInstance3D.new()
		var qm := QuadMesh.new()
		qm.size = Vector2(1.8, 1.8)
		q.mesh = qm
		var pm := StandardMaterial3D.new()
		pm.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
		pm.blend_mode = BaseMaterial3D.BLEND_MODE_ADD
		pm.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
		var gt := GradientTexture2D.new()
		var g := Gradient.new()
		g.set_color(0, Color(1, 1, 1, 0.9))
		g.set_color(1, Color(1, 1, 1, 0.0))
		gt.gradient = g
		gt.fill = GradientTexture2D.FILL_RADIAL
		gt.fill_from = Vector2(0.5, 0.5)
		gt.fill_to = Vector2(1.0, 0.5)
		pm.albedo_texture = gt
		pm.albedo_color = Color.from_hsv(float(k) / 7.0, 0.9, 1.0)
		q.material_override = pm
		q.rotation_degrees.x = -90.0
		var a := TAU * float(k) / 7.0
		q.position = Vector3(sin(a) * 6.3, 0, cos(a) * 6.3)
		pools.add_child(q)
	Sfx.loop("disco", "disco", -3.0, true)
	pop(Vector3(0, 4.0, 0), "DISCO !", Color(1.0, 0.4, 0.9), 200)
	main.viral.highlight("disco")


func _disco_stop() -> void:
	disco_on = false
	Sfx.stop("disco")
	if disco_root != null:
		disco_root.queue_free()
	disco_root = null
	if disco_pools != null:
		disco_pools.queue_free()
	disco_pools = null


# ------------------------------------------------------------- humeurs absurdes

func _apply_mood() -> void:
	var big := Game.mood == "bighead"
	preload("res://scripts/character.gd").big_heads = big
	for tg in _targets():
		tg[2].set_big_head(big)
	# journee helium : toutes les voix (collegues, echos, talkie) deviennent aigues
	for bn in ["Voice", "Radio"]:
		var b := AudioServer.get_bus_index(bn)
		if b < 0:
			continue
		var idx := -1
		for i in AudioServer.get_bus_effect_count(b):
			if AudioServer.get_bus_effect(b, i) is AudioEffectPitchShift:
				idx = i
		if idx < 0:
			var ps := AudioEffectPitchShift.new()
			ps.pitch_scale = 1.6
			AudioServer.add_bus_effect(b, ps)
			idx = AudioServer.get_bus_effect_count(b) - 1
		AudioServer.set_bus_effect_enabled(b, idx, Game.mood == "squeaky")
